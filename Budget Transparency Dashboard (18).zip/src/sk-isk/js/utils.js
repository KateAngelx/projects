// SK Admin Panel Utility Functions
const Utils = {
    // DOM helpers
    $(selector) {
        return document.querySelector(selector);
    },
    
    $$(selector) {
        return document.querySelectorAll(selector);
    },
    
    createElement(tag, className = '', innerHTML = '') {
        const element = document.createElement(tag);
        if (className) element.className = className;
        if (innerHTML) element.innerHTML = innerHTML;
        return element;
    },
    
    // Formatting helpers
    formatCurrency(amount) {
        return new Intl.NumberFormat('en-PH', {
            style: 'currency',
            currency: 'PHP',
            minimumFractionDigits: 0,
            maximumFractionDigits: 0
        }).format(amount);
    },
    
    formatNumber(number) {
        return new Intl.NumberFormat('en-US').format(number);
    },
    
    formatDate(date) {
        const d = new Date(date);
        return d.toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'short',
            day: 'numeric'
        });
    },
    
    formatDateTime(date) {
        const d = new Date(date);
        return d.toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'short',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
    },
    
    formatTimeAgo(date) {
        const now = new Date();
        const diffMs = now - new Date(date);
        const diffMins = Math.floor(diffMs / (1000 * 60));
        const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
        const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));
        
        if (diffMins < 1) return 'Just now';
        if (diffMins < 60) return `${diffMins} minute${diffMins > 1 ? 's' : ''} ago`;
        if (diffHours < 24) return `${diffHours} hour${diffHours > 1 ? 's' : ''} ago`;
        if (diffDays < 7) return `${diffDays} day${diffDays > 1 ? 's' : ''} ago`;
        
        return this.formatDate(date);
    },
    
    // String helpers
    capitalizeFirst(str) {
        return str.charAt(0).toUpperCase() + str.slice(1);
    },
    
    truncateText(text, maxLength) {
        if (text.length <= maxLength) return text;
        return text.substring(0, maxLength).trim() + '...';
    },
    
    slugify(text) {
        return text
            .toLowerCase()
            .replace(/[^\w ]+/g, '')
            .replace(/ +/g, '-');
    },
    
    // Array helpers
    searchItems(items, searchTerm, fields) {
        const term = searchTerm.toLowerCase();
        return items.filter(item => {
            return fields.some(field => {
                const value = this.getNestedProperty(item, field);
                return value && value.toString().toLowerCase().includes(term);
            });
        });
    },
    
    sortItems(items, field, direction = 'asc') {
        return [...items].sort((a, b) => {
            const aVal = this.getNestedProperty(a, field);
            const bVal = this.getNestedProperty(b, field);
            
            if (direction === 'asc') {
                return aVal > bVal ? 1 : -1;
            } else {
                return aVal < bVal ? 1 : -1;
            }
        });
    },
    
    getNestedProperty(obj, path) {
        return path.split('.').reduce((current, key) => current?.[key], obj);
    },
    
    // Color helpers
    getStatusColor(status) {
        const colors = {
            'ongoing': 'primary',
            'completed': 'success',
            'planning': 'warning',
            'cancelled': 'danger',
            'pending': 'warning',
            'approved': 'success',
            'rejected': 'danger'
        };
        return colors[status] || 'secondary';
    },
    
    getCategoryColor(category) {
        const colors = {
            'Sports': 'primary',
            'Education': 'success',
            'Health': 'danger',
            'Livelihood': 'warning',
            'Environment': 'info'
        };
        return colors[category] || 'secondary';
    },
    
    getProgressColor(percentage) {
        if (percentage >= 80) return 'danger';
        if (percentage >= 60) return 'warning';
        return 'success';
    },
    
    // Progress calculations
    calculateProgress(expenses, budget) {
        if (budget === 0) return 0;
        return Math.round((expenses / budget) * 100);
    },
    
    calculateRemaining(expenses, budget) {
        return Math.max(0, budget - expenses);
    },
    
    // Modal helpers
    openModal(selector) {
        const modal = this.$(selector);
        if (modal) {
            modal.classList.add('active');
            document.body.style.overflow = 'hidden';
        }
    },
    
    closeModal(selector) {
        const modal = this.$(selector);
        if (modal) {
            modal.classList.remove('active');
            document.body.style.overflow = '';
        }
    },
    
    // Notification system
    showNotification(message, type = 'info', duration = 5000) {
        // Remove existing notifications
        const existing = this.$('.notification');
        if (existing) {
            existing.remove();
        }
        
        // Create notification
        const notification = this.createElement('div', `notification ${type}`);
        
        const iconMap = {
            success: 'check-circle',
            error: 'alert-circle',
            warning: 'alert-triangle',
            info: 'info'
        };
        
        notification.innerHTML = `
            <div class="notification-content">
                <i data-lucide="${iconMap[type] || 'info'}" class="notification-icon ${type}"></i>
                <div class="notification-message">
                    <div class="notification-title">${this.capitalizeFirst(type)}</div>
                    <div class="notification-text">${message}</div>
                </div>
            </div>
        `;
        
        document.body.appendChild(notification);
        
        // Initialize Lucide icons for the notification
        if (typeof lucide !== 'undefined') {
            lucide.createIcons();
        }
        
        // Show notification
        setTimeout(() => {
            notification.classList.add('show');
        }, 100);
        
        // Auto-hide notification
        if (duration > 0) {
            setTimeout(() => {
                notification.classList.remove('show');
                setTimeout(() => {
                    notification.remove();
                }, 300);
            }, duration);
        }
        
        return notification;
    },
    
    // Loading states
    showLoading(message = 'Loading...') {
        const existing = this.$('.loading-overlay');
        if (existing) return;
        
        const overlay = this.createElement('div', 'loading-overlay');
        overlay.innerHTML = `
            <div style="text-align: center; color: var(--gray-600);">
                <div class="loading-spinner"></div>
                <p style="margin-top: 1rem; font-weight: 500;">${message}</p>
            </div>
        `;
        
        document.body.appendChild(overlay);
        document.body.style.overflow = 'hidden';
    },
    
    hideLoading() {
        const overlay = this.$('.loading-overlay');
        if (overlay) {
            overlay.remove();
            document.body.style.overflow = '';
        }
    },
    
    // Form helpers
    getFormData(formSelector) {
        const form = this.$(formSelector);
        if (!form) return {};
        
        const formData = new FormData(form);
        const data = {};
        
        for (let [key, value] of formData.entries()) {
            // Handle multiple checkboxes with same name
            if (data[key]) {
                if (!Array.isArray(data[key])) {
                    data[key] = [data[key]];
                }
                data[key].push(value);
            } else {
                data[key] = value;
            }
        }
        
        return data;
    },
    
    resetForm(formSelector) {
        const form = this.$(formSelector);
        if (form) {
            form.reset();
        }
    },
    
    validateForm(formSelector, rules = {}) {
        const form = this.$(formSelector);
        if (!form) return false;
        
        let isValid = true;
        const errors = {};
        
        // Clear previous errors
        form.querySelectorAll('.error-message').forEach(el => el.remove());
        form.querySelectorAll('.error').forEach(el => el.classList.remove('error'));
        
        // Validate each field
        Object.keys(rules).forEach(fieldName => {
            const field = form.querySelector(`[name="${fieldName}"]`);
            const rule = rules[fieldName];
            
            if (!field) return;
            
            let fieldValid = true;
            let errorMessage = '';
            
            // Required validation
            if (rule.required && !field.value.trim()) {
                fieldValid = false;
                errorMessage = rule.requiredMessage || 'This field is required';
            }
            
            // Min length validation
            if (fieldValid && rule.minLength && field.value.length < rule.minLength) {
                fieldValid = false;
                errorMessage = rule.minLengthMessage || `Minimum ${rule.minLength} characters required`;
            }
            
            // Email validation
            if (fieldValid && rule.email && field.value) {
                const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                if (!emailRegex.test(field.value)) {
                    fieldValid = false;
                    errorMessage = rule.emailMessage || 'Please enter a valid email address';
                }
            }
            
            // Custom validation
            if (fieldValid && rule.custom && typeof rule.custom === 'function') {
                const customResult = rule.custom(field.value);
                if (customResult !== true) {
                    fieldValid = false;
                    errorMessage = customResult || 'Invalid value';
                }
            }
            
            if (!fieldValid) {
                isValid = false;
                errors[fieldName] = errorMessage;
                
                // Add error styling
                field.classList.add('error');
                
                // Add error message
                const errorEl = this.createElement('div', 'error-message');
                errorEl.style.cssText = 'color: var(--red-500); font-size: 0.875rem; margin-top: 0.25rem;';
                errorEl.textContent = errorMessage;
                field.parentNode.appendChild(errorEl);
            }
        });
        
        return { isValid, errors };
    },
    
    // Debounce helper
    debounce(func, wait) {
        let timeout;
        return function(...args) {
            clearTimeout(timeout);
            timeout = setTimeout(() => func.apply(this, args), wait);
        };
    },
    
    // Throttle helper
    throttle(func, limit) {
        let inThrottle;
        return function(...args) {
            const context = this;
            if (!inThrottle) {
                func.apply(context, args);
                inThrottle = true;
                setTimeout(() => inThrottle = false, limit);
            }
        };
    },
    
    // Animation helpers
    fadeIn(element, duration = 300) {
        element.style.opacity = '0';
        element.style.display = 'block';
        
        let start = null;
        function animate(timestamp) {
            if (!start) start = timestamp;
            const progress = (timestamp - start) / duration;
            
            element.style.opacity = Math.min(progress, 1);
            
            if (progress < 1) {
                requestAnimationFrame(animate);
            }
        }
        
        requestAnimationFrame(animate);
    },
    
    fadeOut(element, duration = 300) {
        let start = null;
        const initialOpacity = parseFloat(getComputedStyle(element).opacity);
        
        function animate(timestamp) {
            if (!start) start = timestamp;
            const progress = (timestamp - start) / duration;
            
            element.style.opacity = initialOpacity * (1 - Math.min(progress, 1));
            
            if (progress < 1) {
                requestAnimationFrame(animate);
            } else {
                element.style.display = 'none';
            }
        }
        
        requestAnimationFrame(animate);
    },
    
    // Local storage helpers
    saveToStorage(key, data) {
        try {
            localStorage.setItem(key, JSON.stringify(data));
            return true;
        } catch (error) {
            console.error('Error saving to storage:', error);
            return false;
        }
    },
    
    loadFromStorage(key, defaultValue = null) {
        try {
            const item = localStorage.getItem(key);
            return item ? JSON.parse(item) : defaultValue;
        } catch (error) {
            console.error('Error loading from storage:', error);
            return defaultValue;
        }
    },
    
    removeFromStorage(key) {
        try {
            localStorage.removeItem(key);
            return true;
        } catch (error) {
            console.error('Error removing from storage:', error);
            return false;
        }
    }
};

// Make Utils available globally
if (typeof window !== 'undefined') {
    window.Utils = Utils;
}