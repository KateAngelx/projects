// Youth Summary Page JavaScript
document.addEventListener('DOMContentLoaded', function() {
    // Initialize data
    AppData.init();
    
    // Initialize icons
    if (typeof lucide !== 'undefined') {
        lucide.createIcons();
    }
    
    // Update statistics
    updateYouthStats();
    
    // Initialize charts
    setTimeout(() => {
        initializeCharts();
    }, 100);
    
    console.log('Youth summary page initialized');
});

function updateYouthStats() {
    const youthData = AppData.youthData;
    
    // Update stat numbers with animation
    const totalYouthEl = Utils.$('#totalYouth');
    const studentsCountEl = Utils.$('#studentsCount');
    const workingYouthEl = Utils.$('#workingYouth');
    const specialGroupsEl = Utils.$('#specialGroups');
    
    if (totalYouthEl) {
        animateNumber(totalYouthEl, youthData.totalYouth);
    }
    
    if (studentsCountEl) {
        animateNumber(studentsCountEl, youthData.byStatus.student);
    }
    
    if (workingYouthEl) {
        animateNumber(workingYouthEl, youthData.byStatus.working);
    }
    
    if (specialGroupsEl) {
        animateNumber(specialGroupsEl, 320); // Mock data for special groups
    }
}

function initializeCharts() {
    try {
        // Initialize age distribution chart
        initAgeChart();
        
        // Initialize education chart
        initEducationChart();
    } catch (error) {
        console.error('Error initializing charts:', error);
    }
}

function initAgeChart() {
    const canvas = Utils.$('#ageChart');
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    const youthData = AppData.youthData;
    
    const ageLabels = Object.keys(youthData.byAge);
    const ageValues = Object.values(youthData.byAge);
    const ageColors = ['#2563eb', '#16a34a', '#f59e0b', '#ef4444'];
    
    new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ageLabels,
            datasets: [{
                data: ageValues,
                backgroundColor: ageColors,
                borderWidth: 2,
                borderColor: '#ffffff',
                hoverBorderWidth: 3
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: {
                        padding: 20,
                        usePointStyle: true,
                        font: { size: 12 }
                    }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const total = context.dataset.data.reduce((a, b) => a + b, 0);
                            const percentage = Math.round((context.parsed / total) * 100);
                            return `${context.label}: ${context.parsed} (${percentage}%)`;
                        }
                    }
                }
            },
            animation: {
                animateRotate: true,
                duration: 1500,
                easing: 'easeInOutQuart'
            }
        }
    });
}

function initEducationChart() {
    const canvas = Utils.$('#educationChart');
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    const youthData = AppData.youthData;
    
    const educationLabels = [
        'Elementary',
        'High School',
        'College',
        'Graduate',
        'Post Graduate'
    ];
    const educationValues = [
        youthData.byEducation.elementary,
        youthData.byEducation.highschool,
        youthData.byEducation.college,
        youthData.byEducation.graduate,
        youthData.byEducation.postgrad
    ];
    const educationColors = [
        '#ef4444',
        '#f59e0b', 
        '#10b981',
        '#3b82f6',
        '#8b5cf6'
    ];
    
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: educationLabels,
            datasets: [{
                label: 'Number of Youth',
                data: educationValues,
                backgroundColor: educationColors,
                borderRadius: 6,
                borderSkipped: false
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const total = context.dataset.data.reduce((a, b) => a + b, 0);
                            const percentage = Math.round((context.parsed.y / total) * 100);
                            return `${context.label}: ${context.parsed.y} (${percentage}%)`;
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: { stepSize: 100 },
                    grid: { color: '#f3f4f6' }
                },
                x: {
                    grid: { display: false }
                }
            },
            animation: {
                duration: 1500,
                easing: 'easeInOutQuart'
            }
        }
    });
}

function animateNumber(element, targetNumber) {
    const duration = 2000; // 2 seconds
    const startTime = performance.now();
    const startNumber = 0;
    
    function updateNumber(currentTime) {
        const elapsed = currentTime - startTime;
        const progress = Math.min(elapsed / duration, 1);
        
        // Easing function (easeOutCubic)
        const easedProgress = 1 - Math.pow(1 - progress, 3);
        
        const currentNumber = Math.floor(startNumber + (targetNumber - startNumber) * easedProgress);
        
        element.textContent = Utils.formatNumber(currentNumber);
        
        if (progress < 1) {
            requestAnimationFrame(updateNumber);
        }
    }
    
    requestAnimationFrame(updateNumber);
}

// Add scroll animations
function addScrollAnimations() {
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('fade-in');
            }
        });
    }, observerOptions);
    
    // Observe cards
    document.querySelectorAll('.card').forEach(card => {
        observer.observe(card);
    });
}

// Initialize scroll animations when page loads
window.addEventListener('load', addScrollAnimations);