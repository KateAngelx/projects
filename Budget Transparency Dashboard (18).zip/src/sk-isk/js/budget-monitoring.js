// Budget Monitoring JavaScript
let budgetVsExpensesChart = null;
let expensesByCategoryChart = null;
let currentExpenses = [];

document.addEventListener('DOMContentLoaded', function() {
    // Initialize data
    AppData.init();
    
    // Check authentication
    checkAuthentication();
    
    // Initialize icons
    if (typeof lucide !== 'undefined') {
        lucide.createIcons();
    }
    
    // Setup event listeners
    setupEventListeners();
    
    // Load budget monitoring data
    loadBudgetMonitoring();
    
    // Initialize charts
    setTimeout(() => {
        initializeCharts();
    }, 100);
    
    console.log('Budget Monitoring initialized');
});

function checkAuthentication() {
    if (!AppData.isLoggedIn || !AppData.currentUser) {
        Utils.showNotification('Please login to access the admin panel', 'warning');
        setTimeout(() => {
            window.location.href = 'login.html';
        }, 2000);
        return;
    }
    
    updateUserInfo();
}

function updateUserInfo() {
    const userNameEl = Utils.$('#currentUserName');
    const userRoleEl = Utils.$('#currentUserRole');
    
    if (userNameEl && AppData.currentUser) {
        userNameEl.textContent = AppData.currentUser.fullName;
    }
    
    if (userRoleEl && AppData.currentUser) {
        userRoleEl.textContent = AppData.currentUser.position;
    }
}

function setupEventListeners() {
    // Logout button
    const logoutBtn = Utils.$('#logoutBtn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', handleLogout);
    }
    
    // Expense form
    const expenseForm = Utils.$('#expenseForm');
    if (expenseForm) {
        expenseForm.addEventListener('submit', handleExpenseSubmit);
    }
    
    // Project filter
    const projectFilter = Utils.$('#projectFilterSelect');
    if (projectFilter) {
        projectFilter.addEventListener('change', filterExpenses);
    }
    
    // Receipt upload
    const receiptInput = Utils.$('#expenseReceipt');
    if (receiptInput) {
        receiptInput.addEventListener('change', handleReceiptUpload);
    }
    
    // Set current date for expense form
    const expenseDate = Utils.$('#expenseDate');
    if (expenseDate) {
        expenseDate.value = new Date().toISOString().split('T')[0];
    }
}

function loadBudgetMonitoring() {
    // Generate mock expense data
    generateMockExpenses();
    
    // Update budget statistics
    updateBudgetStats();
    
    // Load project budget status
    loadProjectBudgetStatus();
    
    // Load expenses table
    loadExpensesTable();
    
    // Populate project filter
    populateProjectFilter();
}

function generateMockExpenses() {
    // Generate mock expense data for demonstration
    const projects = AppData.projects;
    currentExpenses = [];
    
    projects.forEach(project => {
        const expenseCount = Math.floor(Math.random() * 5) + 1;
        
        for (let i = 0; i < expenseCount; i++) {
            const expense = {
                id: Date.now() + Math.random(),
                projectId: project.id,
                projectName: project.title,
                category: getRandomExpenseCategory(),
                description: getRandomExpenseDescription(),
                amount: Math.floor(Math.random() * 10000) + 1000,
                date: getRandomDate(),
                receipt: Math.random() > 0.3 ? 'receipt.pdf' : null,
                addedBy: AppData.currentUser.fullName,
                timestamp: new Date()
            };
            currentExpenses.push(expense);
        }
    });
    
    // Sort by date (newest first)
    currentExpenses.sort((a, b) => new Date(b.date) - new Date(a.date));
}

function getRandomExpenseCategory() {
    const categories = ['Materials', 'Equipment', 'Transportation', 'Food & Refreshments', 'Professional Fees', 'Supplies', 'Venue'];
    return categories[Math.floor(Math.random() * categories.length)];
}

function getRandomExpenseDescription() {
    const descriptions = [
        'Purchase of sports equipment',
        'Transportation allowance for participants',
        'Venue rental for training',
        'Materials for workshop',
        'Professional fees for trainer',
        'Food and refreshments for event',
        'Office supplies procurement',
        'Equipment maintenance'
    ];
    return descriptions[Math.floor(Math.random() * descriptions.length)];
}

function getRandomDate() {
    const start = new Date();
    start.setMonth(start.getMonth() - 3);
    const end = new Date();
    
    return new Date(start.getTime() + Math.random() * (end.getTime() - start.getTime()))
        .toISOString().split('T')[0];
}

function updateBudgetStats() {
    const projects = AppData.projects;
    const totalBudget = projects.reduce((sum, p) => sum + p.budget, 0);
    const totalExpenses = projects.reduce((sum, p) => sum + p.expenses, 0);
    const remainingBalance = totalBudget - totalExpenses;
    const ongoingProjects = projects.filter(p => p.status === 'ongoing').length;
    const completedProjects = projects.filter(p => p.status === 'completed').length;
    
    // Update stat cards with animation
    animateStatValue('#totalBudgetAmount', totalBudget, true);
    animateStatValue('#totalExpensesAmount', totalExpenses, true);
    animateStatValue('#remainingBalance', remainingBalance, true);
    animateStatValue('#ongoingProjectsCount', ongoingProjects);
    
    // Update percentages and subtitles
    const expensePercentage = totalBudget > 0 ? Math.round((totalExpenses / totalBudget) * 100) : 0;
    const remainingPercentage = 100 - expensePercentage;
    
    setTimeout(() => {
        const expensePercentageEl = Utils.$('#expensePercentage');
        const remainingPercentageEl = Utils.$('#remainingPercentage');
        const completedProjectsCountEl = Utils.$('#completedProjectsCount');
        
        if (expensePercentageEl) {
            expensePercentageEl.textContent = `${expensePercentage}% of budget used`;
        }
        
        if (remainingPercentageEl) {
            remainingPercentageEl.textContent = `${remainingPercentage}% remaining`;
        }
        
        if (completedProjectsCountEl) {
            completedProjectsCountEl.textContent = `${completedProjects} successfully finished`;
        }
    }, 1000);
    
    // Check for budget overruns
    checkBudgetOverruns();
}

function checkBudgetOverruns() {
    const overrunProjects = AppData.projects.filter(p => p.expenses > p.budget);
    const alertCard = Utils.$('#budgetAlerts');
    
    if (overrunProjects.length === 0) {
        if (alertCard) {
            alertCard.style.display = 'none';
        }
    } else {
        if (alertCard) {
            alertCard.style.display = 'block';
            const alertText = alertCard.querySelector('p');
            if (alertText) {
                alertText.textContent = `${overrunProjects.length} project${overrunProjects.length > 1 ? 's have' : ' has'} exceeded ${overrunProjects.length > 1 ? 'their' : 'its'} allocated budget. Immediate attention required.`;
            }
        }
    }
}

function loadProjectBudgetStatus() {
    const container = Utils.$('#projectBudgetList');
    if (!container) return;
    
    const projects = AppData.projects;
    container.innerHTML = '';
    
    projects.forEach((project, index) => {
        const budgetUtilization = Utils.calculateProgress(project.expenses, project.budget);
        const isOverrun = project.expenses > project.budget;
        const remaining = project.budget - project.expenses;
        
        const projectItem = Utils.createElement('div', 'project-budget-item');
        projectItem.style.cssText = `
            padding: 1.5rem;
            border: 1px solid var(--gray-200);
            border-radius: var(--radius-lg);
            margin-bottom: 1rem;
            ${isOverrun ? 'border-left: 4px solid var(--red-500);' : ''}
        `;
        
        projectItem.innerHTML = `
            <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 1rem;">
                <div>
                    <h4 style="margin-bottom: 0.5rem; display: flex; align-items: center; gap: 0.5rem;">
                        ${project.title}
                        ${isOverrun ? '<span class="badge badge-danger">Overrun</span>' : ''}
                    </h4>
                    <div style="display: flex; gap: 1rem; font-size: 0.875rem; color: var(--gray-600);">
                        <span>Category: ${project.category}</span>
                        <span>Status: ${Utils.capitalizeFirst(project.status)}</span>
                    </div>
                </div>
                <button class="btn btn-outline btn-sm" onclick="viewProjectBudgetDetails(${project.id})">
                    <i data-lucide="eye"></i>
                    Details
                </button>
            </div>
            
            <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 1rem; margin-bottom: 1rem;">
                <div>
                    <div style="font-size: 0.75rem; color: var(--gray-500); text-transform: uppercase; margin-bottom: 0.25rem;">Budget</div>
                    <div style="font-weight: 600;">${Utils.formatCurrency(project.budget)}</div>
                </div>
                <div>
                    <div style="font-size: 0.75rem; color: var(--gray-500); text-transform: uppercase; margin-bottom: 0.25rem;">Expenses</div>
                    <div style="font-weight: 600; color: ${isOverrun ? 'var(--red-500)' : 'var(--gray-900)'};">${Utils.formatCurrency(project.expenses)}</div>
                </div>
                <div>
                    <div style="font-size: 0.75rem; color: var(--gray-500); text-transform: uppercase; margin-bottom: 0.25rem;">Remaining</div>
                    <div style="font-weight: 600; color: ${remaining >= 0 ? 'var(--green-500)' : 'var(--red-500)'};">${Utils.formatCurrency(remaining)}</div>
                </div>
            </div>
            
            <div>
                <div style="display: flex; justify-content: space-between; margin-bottom: 0.5rem;">
                    <span style="font-size: 0.875rem;">Budget Utilization</span>
                    <span style="font-size: 0.875rem; font-weight: 600;">${budgetUtilization}%</span>
                </div>
                <div class="progress-bar">
                    <div class="progress-fill ${isOverrun ? 'danger' : Utils.getProgressColor(budgetUtilization)}" style="width: ${Math.min(budgetUtilization, 100)}%;"></div>
                </div>
            </div>
        `;
        
        container.appendChild(projectItem);
        
        // Add animation delay
        setTimeout(() => {
            projectItem.style.opacity = '1';
            projectItem.style.transform = 'translateY(0)';
        }, index * 100);
        
        projectItem.style.opacity = '0';
        projectItem.style.transform = 'translateY(20px)';
        projectItem.style.transition = 'all 0.3s ease';
    });
    
    lucide.createIcons();
}

function loadExpensesTable() {
    const tbody = Utils.$('#expensesTableBody');
    if (!tbody) return;
    
    tbody.innerHTML = '';
    
    currentExpenses.forEach(expense => {
        const row = createExpenseTableRow(expense);
        tbody.appendChild(row);
    });
    
    lucide.createIcons();
}

function createExpenseTableRow(expense) {
    const row = Utils.createElement('tr');
    
    row.innerHTML = `
        <td style="font-size: 0.875rem;">${Utils.formatDate(expense.date)}</td>
        <td>
            <div style="font-weight: 600; font-size: 0.875rem; margin-bottom: 0.25rem;">${expense.projectName}</div>
            <div style="font-size: 0.75rem; color: var(--gray-500);">Project ID: #${expense.projectId}</div>
        </td>
        <td>
            <span class="badge badge-info">${expense.category}</span>
        </td>
        <td style="font-size: 0.875rem;">${Utils.truncateText(expense.description, 50)}</td>
        <td>
            <div style="font-weight: 600; font-size: 0.875rem;">${Utils.formatCurrency(expense.amount)}</div>
        </td>
        <td>
            ${expense.receipt ? 
                `<button class="btn btn-outline btn-sm" onclick="viewReceipt('${expense.receipt}')" title="View Receipt">
                    <i data-lucide="file-text" style="width: 0.75rem; height: 0.75rem;"></i>
                </button>` :
                '<span style="color: var(--gray-400); font-size: 0.875rem;">No receipt</span>'
            }
        </td>
        <td style="font-size: 0.875rem;">${expense.addedBy}</td>
        <td>
            <div style="display: flex; gap: 0.25rem;">
                <button class="btn btn-outline btn-sm" onclick="editExpense('${expense.id}')" title="Edit">
                    <i data-lucide="edit" style="width: 0.75rem; height: 0.75rem;"></i>
                </button>
                <button class="btn btn-outline btn-sm" onclick="deleteExpense('${expense.id}')" title="Delete" style="color: var(--red-500); border-color: var(--red-500);">
                    <i data-lucide="trash-2" style="width: 0.75rem; height: 0.75rem;"></i>
                </button>
            </div>
        </td>
    `;
    
    return row;
}

function populateProjectFilter() {
    const select = Utils.$('#projectFilterSelect');
    if (!select) return;
    
    select.innerHTML = '<option value="all">All Projects</option>';
    
    AppData.projects.forEach(project => {
        const option = Utils.createElement('option', '', project.title);
        option.value = project.id;
        select.appendChild(option);
    });
    
    // Also populate expense form project select
    const expenseProjectSelect = Utils.$('#expenseProject');
    if (expenseProjectSelect) {
        expenseProjectSelect.innerHTML = '<option value="">Select Project</option>';
        
        AppData.projects.forEach(project => {
            const option = Utils.createElement('option', '', project.title);
            option.value = project.id;
            expenseProjectSelect.appendChild(option);
        });
    }
}

function filterExpenses() {
    const projectFilter = Utils.$('#projectFilterSelect').value;
    
    let filteredExpenses = currentExpenses;
    
    if (projectFilter !== 'all') {
        filteredExpenses = currentExpenses.filter(expense => 
            expense.projectId.toString() === projectFilter
        );
    }
    
    renderFilteredExpenses(filteredExpenses);
}

function renderFilteredExpenses(expenses) {
    const tbody = Utils.$('#expensesTableBody');
    if (!tbody) return;
    
    tbody.innerHTML = '';
    
    expenses.forEach(expense => {
        const row = createExpenseTableRow(expense);
        tbody.appendChild(row);
    });
    
    lucide.createIcons();
}

function initializeCharts() {
    try {
        initBudgetVsExpensesChart();
        initExpensesByCategoryChart();
    } catch (error) {
        console.error('Error initializing charts:', error);
    }
}

function initBudgetVsExpensesChart() {
    const canvas = Utils.$('#budgetVsExpensesChart');
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    const projects = AppData.projects;
    const totalBudget = projects.reduce((sum, p) => sum + p.budget, 0);
    const totalExpenses = projects.reduce((sum, p) => sum + p.expenses, 0);
    const remaining = totalBudget - totalExpenses;
    
    budgetVsExpensesChart = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ['Used Budget', 'Remaining Budget'],
            datasets: [{
                data: [totalExpenses, Math.max(0, remaining)],
                backgroundColor: ['#2563eb', '#e5e7eb'],
                borderWidth: 0,
                cutout: '70%'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: {
                        padding: 20,
                        usePointStyle: true,
                        font: { size: 12 }
                    }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const value = context.parsed;
                            const total = totalBudget;
                            const percentage = Math.round((value / total) * 100);
                            return `${context.label}: ${Utils.formatCurrency(value)} (${percentage}%)`;
                        }
                    }
                }
            },
            animation: {
                animateRotate: true,
                duration: 1500,
                easing: 'easeInOutQuart'
            }
        }
    });
}

function initExpensesByCategoryChart() {
    const canvas = Utils.$('#expensesByCategoryChart');
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    
    // Calculate expenses by project category
    const categoryExpenses = {};
    AppData.projects.forEach(project => {
        if (!categoryExpenses[project.category]) {
            categoryExpenses[project.category] = 0;
        }
        categoryExpenses[project.category] += project.expenses;
    });
    
    const labels = Object.keys(categoryExpenses);
    const data = Object.values(categoryExpenses);
    const colors = ['#2563eb', '#16a34a', '#f59e0b', '#ef4444', '#8b5cf6'];
    
    expensesByCategoryChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [{
                label: 'Expenses',
                data: data,
                backgroundColor: colors.slice(0, labels.length),
                borderRadius: 6,
                borderSkipped: false
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return `${context.label}: ${Utils.formatCurrency(context.parsed.y)}`;
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: function(value) {
                            return Utils.formatCurrency(value);
                        }
                    },
                    grid: { color: '#f3f4f6' }
                },
                x: {
                    grid: { display: false }
                }
            },
            animation: {
                duration: 1500,
                easing: 'easeInOutQuart'
            }
        }
    });
}

// Modal Functions
function openAddExpenseModal() {
    const modal = Utils.$('#expenseModal');
    const form = Utils.$('#expenseForm');
    
    if (form) form.reset();
    
    // Set current date
    const dateInput = Utils.$('#expenseDate');
    if (dateInput) {
        dateInput.value = new Date().toISOString().split('T')[0];
    }
    
    Utils.openModal('#expenseModal');
    
    // Focus first input
    setTimeout(() => {
        const firstSelect = modal.querySelector('select');
        if (firstSelect) firstSelect.focus();
    }, 300);
    
    lucide.createIcons();
}

function closeExpenseModal() {
    Utils.closeModal('#expenseModal');
}

function handleExpenseSubmit(event) {
    event.preventDefault();
    
    const formData = Utils.getFormData('#expenseForm');
    
    // Validate form
    const validation = Utils.validateForm('#expenseForm', {
        project: { required: true },
        date: { required: true },
        category: { required: true },
        amount: { required: true },
        description: { required: true }
    });
    
    if (!validation.isValid) {
        return;
    }
    
    Utils.showLoading('Adding expense...');
    
    setTimeout(() => {
        // Create new expense
        const project = AppData.projects.find(p => p.id.toString() === formData.project);
        const newExpense = {
            id: Date.now() + Math.random(),
            projectId: parseInt(formData.project),
            projectName: project ? project.title : 'Unknown Project',
            category: formData.category,
            description: formData.description,
            amount: parseFloat(formData.amount),
            date: formData.date,
            receipt: formData.receipt ? 'receipt.pdf' : null,
            addedBy: AppData.currentUser.fullName,
            timestamp: new Date()
        };
        
        // Add to expenses list
        currentExpenses.unshift(newExpense);
        
        // Update project expenses
        if (project) {
            project.expenses += newExpense.amount;
            AppData.saveToStorage();
        }
        
        // Add audit log
        AppData.addAuditLog(
            AppData.currentUser.fullName,
            'Create',
            `Added expense: ${formData.description} - ${Utils.formatCurrency(parseFloat(formData.amount))}`
        );
        
        // Refresh data
        loadBudgetMonitoring();
        updateCharts();
        closeExpenseModal();
        
        Utils.hideLoading();
        Utils.showNotification('Expense added successfully', 'success');
    }, 1000);
}

function handleReceiptUpload(event) {
    const file = event.target.files[0];
    if (!file) return;
    
    const preview = Utils.$('#receiptPreview');
    if (!preview) return;
    
    preview.innerHTML = `
        <div style="display: flex; align-items: center; gap: 0.75rem; padding: 0.75rem; background-color: var(--gray-50); border-radius: var(--radius-lg); margin-top: 0.5rem;">
            <div style="width: 2rem; height: 2rem; background-color: var(--primary-blue); border-radius: 0.25rem; display: flex; align-items: center; justify-content: center; color: var(--white);">
                <i data-lucide="file" style="width: 1rem; height: 1rem;"></i>
            </div>
            <div style="flex: 1;">
                <div style="font-weight: 600; font-size: 0.875rem;">${file.name}</div>
                <div style="font-size: 0.75rem; color: var(--gray-500);">${Utils.formatFileSize(file.size)}</div>
            </div>
            <button type="button" onclick="removeReceipt()" style="background: none; border: none; color: var(--gray-400); cursor: pointer;">
                <i data-lucide="x" style="width: 1rem; height: 1rem;"></i>
            </button>
        </div>
    `;
    
    lucide.createIcons();
}

function removeReceipt() {
    const receiptInput = Utils.$('#expenseReceipt');
    const preview = Utils.$('#receiptPreview');
    
    if (receiptInput) receiptInput.value = '';
    if (preview) preview.innerHTML = '';
}

function updateCharts() {
    if (budgetVsExpensesChart) {
        const projects = AppData.projects;
        const totalBudget = projects.reduce((sum, p) => sum + p.budget, 0);
        const totalExpenses = projects.reduce((sum, p) => sum + p.expenses, 0);
        const remaining = totalBudget - totalExpenses;
        
        budgetVsExpensesChart.data.datasets[0].data = [totalExpenses, Math.max(0, remaining)];
        budgetVsExpensesChart.update();
    }
    
    if (expensesByCategoryChart) {
        const categoryExpenses = {};
        AppData.projects.forEach(project => {
            if (!categoryExpenses[project.category]) {
                categoryExpenses[project.category] = 0;
            }
            categoryExpenses[project.category] += project.expenses;
        });
        
        expensesByCategoryChart.data.labels = Object.keys(categoryExpenses);
        expensesByCategoryChart.data.datasets[0].data = Object.values(categoryExpenses);
        expensesByCategoryChart.update();
    }
}

// Utility Functions
function animateStatValue(selector, targetValue, isCurrency = false) {
    const element = Utils.$(selector);
    if (!element) return;
    
    const duration = 2000;
    const startTime = performance.now();
    const startValue = 0;
    
    function updateValue(currentTime) {
        const elapsed = currentTime - startTime;
        const progress = Math.min(elapsed / duration, 1);
        
        const easedProgress = 1 - Math.pow(1 - progress, 3);
        const currentValue = Math.floor(startValue + (targetValue - startValue) * easedProgress);
        
        element.textContent = isCurrency ? Utils.formatCurrency(currentValue) : currentValue;
        
        if (progress < 1) {
            requestAnimationFrame(updateValue);
        }
    }
    
    requestAnimationFrame(updateValue);
}

// Action Functions
function viewOverrunProjects() {
    const overrunProjects = AppData.projects.filter(p => p.expenses > p.budget);
    
    const modal = Utils.$('#overrunModal');
    const container = Utils.$('#overrunProjectsList');
    
    if (!container) return;
    
    container.innerHTML = '';
    
    overrunProjects.forEach(project => {
        const overrun = project.expenses - project.budget;
        const overrunPercentage = Math.round((overrun / project.budget) * 100);
        
        const projectItem = Utils.createElement('div');
        projectItem.style.cssText = `
            padding: 1.5rem;
            border: 1px solid var(--red-200);
            border-left: 4px solid var(--red-500);
            border-radius: var(--radius-lg);
            margin-bottom: 1rem;
            background-color: var(--red-50);
        `;
        
        projectItem.innerHTML = `
            <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 1rem;">
                <div>
                    <h4 style="margin-bottom: 0.5rem; color: var(--red-500);">${project.title}</h4>
                    <div style="font-size: 0.875rem; color: var(--gray-600);">Category: ${project.category}</div>
                </div>
                <span class="badge badge-danger">+${overrunPercentage}% over budget</span>
            </div>
            <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 1rem;">
                <div>
                    <div style="font-size: 0.75rem; color: var(--gray-500); margin-bottom: 0.25rem;">BUDGET</div>
                    <div style="font-weight: 600;">${Utils.formatCurrency(project.budget)}</div>
                </div>
                <div>
                    <div style="font-size: 0.75rem; color: var(--gray-500); margin-bottom: 0.25rem;">EXPENSES</div>
                    <div style="font-weight: 600; color: var(--red-500);">${Utils.formatCurrency(project.expenses)}</div>
                </div>
                <div>
                    <div style="font-size: 0.75rem; color: var(--gray-500); margin-bottom: 0.25rem;">OVERRUN</div>
                    <div style="font-weight: 600; color: var(--red-500);">${Utils.formatCurrency(overrun)}</div>
                </div>
            </div>
        `;
        
        container.appendChild(projectItem);
    });
    
    Utils.openModal('#overrunModal');
}

function closeOverrunModal() {
    Utils.closeModal('#overrunModal');
}

function dismissAlert(type) {
    const alert = Utils.$('#budgetAlerts');
    if (alert) {
        alert.style.display = 'none';
    }
}

function exportExpenses() {
    Utils.showNotification('Exporting expenses data...', 'info');
    // Implementation for export functionality
}

function generateOverrunReport() {
    Utils.showNotification('Generating budget overrun report...', 'info');
    closeOverrunModal();
}

function viewProjectBudgetDetails(projectId) {
    const project = AppData.projects.find(p => p.id === projectId);
    if (!project) return;
    
    Utils.showNotification(`Viewing budget details for: ${project.title}`, 'info');
}

function viewReceipt(filename) {
    Utils.showNotification(`Viewing receipt: ${filename}`, 'info');
}

function editExpense(expenseId) {
    Utils.showNotification('Edit expense functionality would be implemented here', 'info');
}

function deleteExpense(expenseId) {
    if (confirm('Are you sure you want to delete this expense?')) {
        const index = currentExpenses.findIndex(e => e.id.toString() === expenseId.toString());
        if (index > -1) {
            currentExpenses.splice(index, 1);
            loadExpensesTable();
            Utils.showNotification('Expense deleted successfully', 'success');
        }
    }
}

function handleLogout() {
    if (confirm('Are you sure you want to logout?')) {
        AppData.logout();
        Utils.showNotification('Logged out successfully', 'success');
        setTimeout(() => {
            window.location.href = 'index.html';
        }, 1000);
    }
}