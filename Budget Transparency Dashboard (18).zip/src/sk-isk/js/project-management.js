// Project Management JavaScript
let currentEditingProject = null;
let projectToDelete = null;
let selectedProjects = new Set();

document.addEventListener('DOMContentLoaded', function() {
    // Initialize data
    AppData.init();
    
    // Check authentication
    checkAuthentication();
    
    // Initialize icons
    if (typeof lucide !== 'undefined') {
        lucide.createIcons();
    }
    
    // Setup event listeners
    setupEventListeners();
    
    // Load project data
    loadProjectManagement();
    
    console.log('Project Management initialized');
});

function checkAuthentication() {
    if (!AppData.isLoggedIn || !AppData.currentUser) {
        Utils.showNotification('Please login to access the admin panel', 'warning');
        setTimeout(() => {
            window.location.href = 'login.html';
        }, 2000);
        return;
    }
    
    // Update user info in UI
    updateUserInfo();
}

function updateUserInfo() {
    const userNameEl = Utils.$('#currentUserName');
    const userRoleEl = Utils.$('#currentUserRole');
    
    if (userNameEl && AppData.currentUser) {
        userNameEl.textContent = AppData.currentUser.fullName;
    }
    
    if (userRoleEl && AppData.currentUser) {
        userRoleEl.textContent = AppData.currentUser.position;
    }
}

function setupEventListeners() {
    // Logout button
    const logoutBtn = Utils.$('#logoutBtn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', handleLogout);
    }
    
    // Search and filters
    const searchInput = Utils.$('#projectSearchInput');
    const categoryFilter = Utils.$('#categoryFilterSelect');
    const statusFilter = Utils.$('#statusFilterSelect');
    const visibilityFilter = Utils.$('#visibilityFilterSelect');
    const clearFilters = Utils.$('#clearProjectFilters');
    
    if (searchInput) {
        searchInput.addEventListener('input', Utils.debounce(filterProjects, 300));
    }
    
    if (categoryFilter) {
        categoryFilter.addEventListener('change', filterProjects);
    }
    
    if (statusFilter) {
        statusFilter.addEventListener('change', filterProjects);
    }
    
    if (visibilityFilter) {
        visibilityFilter.addEventListener('change', filterProjects);
    }
    
    if (clearFilters) {
        clearFilters.addEventListener('click', clearProjectFilters);
    }
    
    // Project form
    const projectForm = Utils.$('#projectForm');
    if (projectForm) {
        projectForm.addEventListener('submit', handleProjectSubmit);
    }
    
    // File upload
    const fileInput = Utils.$('#projectFiles');
    if (fileInput) {
        fileInput.addEventListener('change', handleFileUpload);
    }
    
    // File drop zone
    const dropZone = Utils.$('#fileDropZone');
    if (dropZone) {
        dropZone.addEventListener('dragover', handleDragOver);
        dropZone.addEventListener('drop', handleFileDrop);
        dropZone.addEventListener('click', () => fileInput.click());
    }
}

function loadProjectManagement() {
    // Update statistics
    updateProjectStats();
    
    // Load projects table
    loadProjectsTable();
    
    // Load project filters
    loadProjectFilters();
}

function updateProjectStats() {
    const projects = AppData.projects;
    const publicProjects = projects.filter(p => p.isPublic);
    const activeProjects = projects.filter(p => p.status === 'ongoing');
    const totalBudget = projects.reduce((sum, p) => sum + p.budget, 0);
    const totalExpenses = projects.reduce((sum, p) => sum + p.expenses, 0);
    const totalParticipants = projects.reduce((sum, p) => sum + (p.participants || 0), 0);
    
    // Update stat cards
    animateStatNumber('#totalProjectsCount', projects.length);
    animateStatNumber('#activeProjectsCount', activeProjects.length);
    animateStatNumber('#totalParticipants', totalParticipants);
    
    const publicProjectsCount = Utils.$('#publicProjectsCount');
    const ongoingProjectsCount = Utils.$('#ongoingProjectsCount');
    const totalBudgetAmount = Utils.$('#totalBudgetAmount');
    const budgetUtilization = Utils.$('#budgetUtilization');
    const avgParticipants = Utils.$('#avgParticipants');
    
    if (publicProjectsCount) {
        publicProjectsCount.textContent = `${publicProjects.length} public`;
    }
    
    if (ongoingProjectsCount) {
        ongoingProjectsCount.textContent = `${activeProjects.length} ongoing`;
    }
    
    if (totalBudgetAmount) {
        totalBudgetAmount.textContent = Utils.formatCurrency(totalBudget);
    }
    
    if (budgetUtilization) {
        const utilization = totalBudget > 0 ? Math.round((totalExpenses / totalBudget) * 100) : 0;
        budgetUtilization.textContent = `${utilization}% utilized`;
    }
    
    if (avgParticipants) {
        const avg = projects.length > 0 ? Math.round(totalParticipants / projects.length) : 0;
        avgParticipants.textContent = `${avg} avg per project`;
    }
}

function loadProjectsTable() {
    const tbody = Utils.$('#projectsTableBody');
    if (!tbody) return;
    
    const projects = AppData.projects;
    tbody.innerHTML = '';
    
    if (projects.length === 0) {
        showEmptyState();
        return;
    }
    
    hideEmptyState();
    
    projects.forEach(project => {
        const row = createProjectTableRow(project);
        tbody.appendChild(row);
    });
    
    // Re-initialize icons
    lucide.createIcons();
}

function createProjectTableRow(project) {
    const row = Utils.createElement('tr');
    
    const budgetUtilization = Utils.calculateProgress(project.expenses, project.budget);
    const statusColor = Utils.getStatusColor(project.status);
    const categoryColor = Utils.getCategoryColor(project.category);
    
    row.innerHTML = `
        <td>
            <input type="checkbox" class="project-checkbox" value="${project.id}" onchange="updateSelectedProjects()">
        </td>
        <td>
            <div style="display: flex; align-items: flex-start; gap: 1rem;">
                <div style="width: 2.5rem; height: 2.5rem; background-color: var(--${getCategoryColor(project.category)}); border-radius: 0.5rem; display: flex; align-items: center; justify-content: center; color: var(--white); flex-shrink: 0;">
                    <i data-lucide="${getCategoryIcon(project.category)}" style="width: 1.25rem; height: 1.25rem;"></i>
                </div>
                <div>
                    <h4 style="margin-bottom: 0.25rem; font-size: 0.875rem;">${project.title}</h4>
                    <p style="font-size: 0.75rem; color: var(--gray-500); margin-bottom: 0.5rem;">${Utils.truncateText(project.description, 60)}</p>
                    <div style="font-size: 0.75rem; color: var(--gray-500);">
                        <span>${project.participants || 0} participants</span>
                        <span style="margin-left: 1rem;">by ${project.createdBy}</span>
                    </div>
                </div>
            </div>
        </td>
        <td>
            <span class="badge badge-${categoryColor}">${project.category}</span>
        </td>
        <td>
            <div style="font-size: 0.875rem; font-weight: 600;">${Utils.formatCurrency(project.budget)}</div>
            <div style="font-size: 0.75rem; color: var(--gray-500);">
                ${Utils.formatCurrency(project.expenses)} spent (${budgetUtilization}%)
            </div>
            <div class="progress-bar" style="margin-top: 0.25rem; height: 4px;">
                <div class="progress-fill ${Utils.getProgressColor(budgetUtilization)}" style="width: ${budgetUtilization}%;"></div>
            </div>
        </td>
        <td>
            <span class="badge badge-${statusColor}">${Utils.capitalizeFirst(project.status)}</span>
        </td>
        <td>
            <div style="display: flex; align-items: center; gap: 0.5rem;">
                <div style="width: 8px; height: 8px; border-radius: 50%; background-color: ${project.isPublic ? 'var(--green-500)' : 'var(--gray-400)'};"></div>
                <span style="font-size: 0.875rem;">${project.isPublic ? 'Public' : 'Private'}</span>
            </div>
        </td>
        <td style="font-size: 0.875rem;">${Utils.formatDate(project.date)}</td>
        <td>
            <div style="display: flex; gap: 0.25rem;">
                <button class="btn btn-outline btn-sm" onclick="editProject(${project.id})" title="Edit">
                    <i data-lucide="edit" style="width: 0.875rem; height: 0.875rem;"></i>
                </button>
                <button class="btn btn-outline btn-sm" onclick="viewProject(${project.id})" title="View">
                    <i data-lucide="eye" style="width: 0.875rem; height: 0.875rem;"></i>
                </button>
                <button class="btn btn-outline btn-sm" onclick="deleteProject(${project.id})" title="Delete" style="color: var(--red-500); border-color: var(--red-500);">
                    <i data-lucide="trash-2" style="width: 0.875rem; height: 0.875rem;"></i>
                </button>
            </div>
        </td>
    `;
    
    return row;
}

function filterProjects() {
    const searchTerm = Utils.$('#projectSearchInput').value.toLowerCase();
    const categoryFilter = Utils.$('#categoryFilterSelect').value;
    const statusFilter = Utils.$('#statusFilterSelect').value;
    const visibilityFilter = Utils.$('#visibilityFilterSelect').value;
    
    let filteredProjects = AppData.projects;
    
    // Apply search filter
    if (searchTerm) {
        filteredProjects = filteredProjects.filter(project => 
            project.title.toLowerCase().includes(searchTerm) ||
            project.description.toLowerCase().includes(searchTerm) ||
            project.createdBy.toLowerCase().includes(searchTerm)
        );
    }
    
    // Apply category filter
    if (categoryFilter !== 'all') {
        filteredProjects = filteredProjects.filter(project => project.category === categoryFilter);
    }
    
    // Apply status filter
    if (statusFilter !== 'all') {
        filteredProjects = filteredProjects.filter(project => project.status === statusFilter);
    }
    
    // Apply visibility filter
    if (visibilityFilter !== 'all') {
        const isPublic = visibilityFilter === 'public';
        filteredProjects = filteredProjects.filter(project => project.isPublic === isPublic);
    }
    
    renderFilteredProjects(filteredProjects);
}

function renderFilteredProjects(projects) {
    const tbody = Utils.$('#projectsTableBody');
    if (!tbody) return;
    
    tbody.innerHTML = '';
    
    if (projects.length === 0) {
        showEmptyState();
        return;
    }
    
    hideEmptyState();
    
    projects.forEach(project => {
        const row = createProjectTableRow(project);
        tbody.appendChild(row);
    });
    
    // Re-initialize icons
    lucide.createIcons();
}

function clearProjectFilters() {
    Utils.$('#projectSearchInput').value = '';
    Utils.$('#categoryFilterSelect').value = 'all';
    Utils.$('#statusFilterSelect').value = 'all';
    Utils.$('#visibilityFilterSelect').value = 'all';
    
    loadProjectsTable();
}

function loadProjectFilters() {
    // Load project options for associated project dropdown in other modals
    const projectSelects = Utils.$$('select[name="project"]');
    
    projectSelects.forEach(select => {
        if (select.id === 'associatedProject') {
            select.innerHTML = '<option value="">No associated project</option>';
            AppData.projects.forEach(project => {
                const option = Utils.createElement('option', '', project.title);
                option.value = project.id;
                select.appendChild(option);
            });
        }
    });
}

// Modal Functions
function openAddProjectModal() {
    currentEditingProject = null;
    
    const modal = Utils.$('#projectModal');
    const title = Utils.$('#projectModalTitle');
    const saveText = Utils.$('#projectSaveText');
    const form = Utils.$('#projectForm');
    
    if (title) title.textContent = 'Add New Project';
    if (saveText) saveText.textContent = 'Save Project';
    if (form) form.reset();
    
    // Set default date to today
    const dateInput = Utils.$('#projectDate');
    if (dateInput) {
        dateInput.value = new Date().toISOString().split('T')[0];
    }
    
    Utils.openModal('#projectModal');
    
    // Focus first input
    setTimeout(() => {
        const firstInput = modal.querySelector('input[type="text"]');
        if (firstInput) firstInput.focus();
    }, 300);
    
    lucide.createIcons();
}

function editProject(projectId) {
    const project = AppData.projects.find(p => p.id === projectId);
    if (!project) return;
    
    currentEditingProject = project;
    
    const modal = Utils.$('#projectModal');
    const title = Utils.$('#projectModalTitle');
    const saveText = Utils.$('#projectSaveText');
    
    if (title) title.textContent = 'Edit Project';
    if (saveText) saveText.textContent = 'Update Project';
    
    // Fill form with project data
    Utils.$('#projectId').value = project.id;
    Utils.$('#projectTitle').value = project.title;
    Utils.$('#projectCategory').value = project.category;
    Utils.$('#projectDescription').value = project.description;
    Utils.$('#projectBudget').value = project.budget;
    Utils.$('#projectExpenses').value = project.expenses;
    Utils.$('#projectDate').value = project.date;
    Utils.$('#projectParticipants').value = project.participants || 0;
    Utils.$('#projectStatus').value = project.status;
    
    // Set visibility settings
    const publicRadio = Utils.$('input[name="isPublic"][value="true"]');
    const privateRadio = Utils.$('input[name="isPublic"][value="false"]');
    
    if (project.isPublic) {
        if (publicRadio) publicRadio.checked = true;
    } else {
        if (privateRadio) privateRadio.checked = true;
    }
    
    // Set visibility checkboxes
    Utils.$('input[name="showBudget"]').checked = project.showBudget;
    Utils.$('input[name="showStatus"]').checked = project.showStatus;
    Utils.$('input[name="showDescription"]').checked = project.showDescription;
    Utils.$('input[name="showDocuments"]').checked = project.showDocuments;
    
    Utils.openModal('#projectModal');
    lucide.createIcons();
}

function viewProject(projectId) {
    const project = AppData.projects.find(p => p.id === projectId);
    if (!project) return;
    
    // Create view modal
    const modal = Utils.createElement('div', 'modal');
    modal.innerHTML = `
        <div class="modal-content" style="max-width: 800px;">
            <div class="modal-header">
                <h3 class="modal-title">${project.title}</h3>
                <button class="modal-close" onclick="closeViewModal()">
                    <i data-lucide="x"></i>
                </button>
            </div>
            <div class="modal-body">
                <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 2rem;">
                    <div>
                        <div style="margin-bottom: 2rem;">
                            <h4 style="margin-bottom: 0.5rem;">Description</h4>
                            <p style="color: var(--gray-600); line-height: 1.6;">${project.description}</p>
                        </div>
                        
                        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; margin-bottom: 2rem;">
                            <div>
                                <h4 style="margin-bottom: 0.5rem;">Category</h4>
                                <span class="badge badge-${Utils.getCategoryColor(project.category)}">${project.category}</span>
                            </div>
                            <div>
                                <h4 style="margin-bottom: 0.5rem;">Status</h4>
                                <span class="badge badge-${Utils.getStatusColor(project.status)}">${Utils.capitalizeFirst(project.status)}</span>
                            </div>
                            <div>
                                <h4 style="margin-bottom: 0.5rem;">Start Date</h4>
                                <p>${Utils.formatDate(project.date)}</p>
                            </div>
                            <div>
                                <h4 style="margin-bottom: 0.5rem;">Participants</h4>
                                <p>${project.participants || 0}</p>
                            </div>
                        </div>
                        
                        <div>
                            <h4 style="margin-bottom: 1rem;">Budget Breakdown</h4>
                            <div style="background-color: var(--gray-50); padding: 1.5rem; border-radius: var(--radius-lg);">
                                <div style="display: flex; justify-content: space-between; margin-bottom: 0.5rem;">
                                    <span>Total Budget:</span>
                                    <span style="font-weight: 600;">${Utils.formatCurrency(project.budget)}</span>
                                </div>
                                <div style="display: flex; justify-content: space-between; margin-bottom: 0.5rem;">
                                    <span>Expenses:</span>
                                    <span style="font-weight: 600;">${Utils.formatCurrency(project.expenses)}</span>
                                </div>
                                <div style="display: flex; justify-content: space-between; padding-top: 0.5rem; border-top: 1px solid var(--gray-200);">
                                    <span>Remaining:</span>
                                    <span style="font-weight: 600; color: var(--green-500);">${Utils.formatCurrency(project.budget - project.expenses)}</span>
                                </div>
                                <div style="margin-top: 1rem;">
                                    <div class="progress-bar">
                                        <div class="progress-fill ${Utils.getProgressColor(Utils.calculateProgress(project.expenses, project.budget))}" style="width: ${Utils.calculateProgress(project.expenses, project.budget)}%;"></div>
                                    </div>
                                    <p style="text-align: center; margin-top: 0.5rem; font-size: 0.875rem; color: var(--gray-600);">
                                        ${Utils.calculateProgress(project.expenses, project.budget)}% utilized
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div>
                        <div style="margin-bottom: 2rem;">
                            <h4 style="margin-bottom: 1rem;">Visibility Settings</h4>
                            <div style="background-color: var(--gray-50); padding: 1rem; border-radius: var(--radius-lg);">
                                <div style="margin-bottom: 0.5rem;">
                                    <span class="badge ${project.isPublic ? 'badge-success' : 'badge-secondary'}">
                                        ${project.isPublic ? 'Public' : 'Private'}
                                    </span>
                                </div>
                                <div style="font-size: 0.875rem; color: var(--gray-600);">
                                    <div>Budget: ${project.showBudget ? '✓' : '✗'}</div>
                                    <div>Status: ${project.showStatus ? '✓' : '✗'}</div>
                                    <div>Description: ${project.showDescription ? '✓' : '✗'}</div>
                                    <div>Documents: ${project.showDocuments ? '✓' : '✗'}</div>
                                </div>
                            </div>
                        </div>
                        
                        <div>
                            <h4 style="margin-bottom: 1rem;">Project Information</h4>
                            <div style="font-size: 0.875rem; color: var(--gray-600); line-height: 1.6;">
                                <div style="margin-bottom: 0.5rem;"><strong>Created by:</strong> ${project.createdBy}</div>
                                <div style="margin-bottom: 0.5rem;"><strong>Project ID:</strong> #${project.id}</div>
                                <div><strong>Last updated:</strong> ${Utils.formatDate(new Date())}</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline" onclick="closeViewModal()">Close</button>
                <button type="button" class="btn btn-primary" onclick="editProject(${project.id}); closeViewModal();">
                    <i data-lucide="edit"></i>
                    Edit Project
                </button>
            </div>
        </div>
    `;
    
    modal.id = 'viewProjectModal';
    document.body.appendChild(modal);
    
    setTimeout(() => {
        modal.classList.add('active');
        lucide.createIcons();
    }, 10);
}

function closeViewModal() {
    const modal = Utils.$('#viewProjectModal');
    if (modal) {
        modal.classList.remove('active');
        setTimeout(() => {
            modal.remove();
        }, 300);
    }
}

function deleteProject(projectId) {
    const project = AppData.projects.find(p => p.id === projectId);
    if (!project) return;
    
    projectToDelete = project;
    
    const deleteNameEl = Utils.$('#deleteProjectName');
    if (deleteNameEl) {
        deleteNameEl.textContent = project.title;
    }
    
    Utils.openModal('#deleteProjectModal');
}

function confirmDeleteProject() {
    if (!projectToDelete) return;
    
    const success = AppData.deleteProject(projectToDelete.id);
    
    if (success) {
        Utils.showNotification('Project deleted successfully', 'success');
        loadProjectManagement();
        closeDeleteModal();
    } else {
        Utils.showNotification('Failed to delete project', 'error');
    }
    
    projectToDelete = null;
}

function closeProjectModal() {
    Utils.closeModal('#projectModal');
    currentEditingProject = null;
}

function closeDeleteModal() {
    Utils.closeModal('#deleteProjectModal');
    projectToDelete = null;
}

// Form Handlers
function handleProjectSubmit(event) {
    event.preventDefault();
    
    const formData = Utils.getFormData('#projectForm');
    
    // Convert string values to appropriate types
    formData.budget = parseFloat(formData.budget);
    formData.expenses = parseFloat(formData.expenses) || 0;
    formData.participants = parseInt(formData.participants) || 0;
    formData.isPublic = formData.isPublic === 'true';
    formData.showBudget = !!formData.showBudget;
    formData.showStatus = !!formData.showStatus;
    formData.showDescription = !!formData.showDescription;
    formData.showDocuments = !!formData.showDocuments;
    
    // Validate form
    const validation = Utils.validateForm('#projectForm', {
        title: { required: true },
        category: { required: true },
        description: { required: true },
        budget: { required: true },
        date: { required: true },
        status: { required: true }
    });
    
    if (!validation.isValid) {
        return;
    }
    
    Utils.showLoading('Saving project...');
    
    setTimeout(() => {
        let result;
        
        if (currentEditingProject) {
            // Update existing project
            result = AppData.updateProject(currentEditingProject.id, formData);
            Utils.showNotification('Project updated successfully', 'success');
        } else {
            // Create new project
            result = AppData.addProject(formData);
            Utils.showNotification('Project created successfully', 'success');
        }
        
        if (result) {
            loadProjectManagement();
            closeProjectModal();
        }
        
        Utils.hideLoading();
    }, 1000);
}

// File Upload Handlers
function handleFileUpload(event) {
    const files = Array.from(event.target.files);
    displayUploadedFiles(files);
}

function handleDragOver(event) {
    event.preventDefault();
    event.currentTarget.style.backgroundColor = 'var(--secondary-blue)';
}

function handleFileDrop(event) {
    event.preventDefault();
    event.currentTarget.style.backgroundColor = '';
    
    const files = Array.from(event.dataTransfer.files);
    displayUploadedFiles(files);
}

function displayUploadedFiles(files) {
    const container = Utils.$('#uploadedFilesList');
    if (!container) return;
    
    container.innerHTML = '';
    
    files.forEach((file, index) => {
        const fileItem = Utils.createElement('div', 'file-item');
        fileItem.style.cssText = `
            display: flex;
            align-items: center;
            gap: 1rem;
            padding: 0.75rem;
            background-color: var(--gray-50);
            border-radius: var(--radius-lg);
            margin-bottom: 0.5rem;
        `;
        
        fileItem.innerHTML = `
            <div style="width: 2rem; height: 2rem; background-color: var(--primary-blue); border-radius: 0.25rem; display: flex; align-items: center; justify-content: center; color: var(--white); flex-shrink: 0;">
                <i data-lucide="file" style="width: 1rem; height: 1rem;"></i>
            </div>
            <div style="flex: 1;">
                <div style="font-weight: 600; font-size: 0.875rem;">${file.name}</div>
                <div style="font-size: 0.75rem; color: var(--gray-500);">${Utils.formatFileSize(file.size)}</div>
            </div>
            <button type="button" onclick="removeFile(${index})" style="background: none; border: none; color: var(--gray-400); cursor: pointer;">
                <i data-lucide="x" style="width: 1rem; height: 1rem;"></i>
            </button>
        `;
        
        container.appendChild(fileItem);
    });
    
    lucide.createIcons();
}

function removeFile(index) {
    // Implementation for removing files would go here
    Utils.showNotification('File removed', 'info');
}

// Utility Functions
function getCategoryIcon(category) {
    const categoryIcons = {
        'Sports': 'trophy',
        'Education': 'graduation-cap',
        'Livelihood': 'briefcase',
        'Health': 'heart',
        'Environment': 'leaf'
    };
    return categoryIcons[category] || 'folder';
}

function getCategoryColor(category) {
    const categoryColors = {
        'Sports': 'primary-blue',
        'Education': 'green-500',
        'Livelihood': 'yellow-500',
        'Health': 'red-500',
        'Environment': 'purple-500'
    };
    return categoryColors[category] || 'gray-500';
}

function animateStatNumber(selector, targetNumber) {
    const element = Utils.$(selector);
    if (!element) return;
    
    const duration = 1500;
    const startTime = performance.now();
    const startNumber = 0;
    
    function updateNumber(currentTime) {
        const elapsed = currentTime - startTime;
        const progress = Math.min(elapsed / duration, 1);
        
        const easedProgress = 1 - Math.pow(1 - progress, 3);
        const currentNumber = Math.floor(startNumber + (targetNumber - startNumber) * easedProgress);
        
        element.textContent = currentNumber;
        
        if (progress < 1) {
            requestAnimationFrame(updateNumber);
        }
    }
    
    requestAnimationFrame(updateNumber);
}

function showEmptyState() {
    Utils.$('#projectsEmptyState').classList.remove('hidden');
    Utils.$('.card .table-container').style.display = 'none';
}

function hideEmptyState() {
    Utils.$('#projectsEmptyState').classList.add('hidden');
    const tableContainer = Utils.$('.card .table-container');
    if (tableContainer) {
        tableContainer.style.display = 'block';
    }
}

// Selection and Bulk Actions
function toggleSelectAll() {
    const selectAll = Utils.$('#selectAllProjects');
    const checkboxes = Utils.$$('.project-checkbox');
    
    checkboxes.forEach(checkbox => {
        checkbox.checked = selectAll.checked;
    });
    
    updateSelectedProjects();
}

function updateSelectedProjects() {
    const checkboxes = Utils.$$('.project-checkbox:checked');
    selectedProjects.clear();
    
    checkboxes.forEach(checkbox => {
        selectedProjects.add(parseInt(checkbox.value));
    });
    
    // Update UI based on selection
    const selectedCount = selectedProjects.size;
    // Could show bulk action toolbar here
}

function bulkActions() {
    if (selectedProjects.size === 0) {
        Utils.showNotification('Please select projects first', 'warning');
        return;
    }
    
    // Implementation for bulk actions
    Utils.showNotification(`${selectedProjects.size} projects selected`, 'info');
}

function exportProjects() {
    Utils.showNotification('Exporting projects...', 'info');
    // Implementation for export functionality
}

function handleLogout() {
    if (confirm('Are you sure you want to logout?')) {
        AppData.logout();
        Utils.showNotification('Logged out successfully', 'success');
        setTimeout(() => {
            window.location.href = 'index.html';
        }, 1000);
    }
}

// Format file size utility
Utils.formatFileSize = function(bytes) {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
};