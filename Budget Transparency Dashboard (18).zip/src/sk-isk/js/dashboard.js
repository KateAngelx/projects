// Dashboard Page JavaScript
document.addEventListener('DOMContentLoaded', function() {
    // Initialize data
    AppData.init();
    
    // Check authentication
    checkAuthentication();
    
    // Initialize icons
    if (typeof lucide !== 'undefined') {
        lucide.createIcons();
    }
    
    // Setup event listeners
    setupEventListeners();
    
    // Load dashboard data
    loadDashboardData();
    
    // Initialize charts
    if (typeof DashboardCharts !== 'undefined') {
        DashboardCharts.init();
    }
    
    console.log('Dashboard initialized');
});

function checkAuthentication() {
    if (!AppData.isLoggedIn || !AppData.currentUser) {
        Utils.showNotification('Please login to access the admin panel', 'warning');
        setTimeout(() => {
            window.location.href = 'login.html';
        }, 2000);
        return;
    }
    
    // Update user info in UI
    updateUserInfo();
}

function updateUserInfo() {
    const userNameEl = Utils.$('#currentUserName');
    const userRoleEl = Utils.$('#currentUserRole');
    const userAvatarEl = Utils.$('.user-avatar-small');
    
    if (userNameEl && AppData.currentUser) {
        userNameEl.textContent = AppData.currentUser.fullName;
    }
    
    if (userRoleEl && AppData.currentUser) {
        userRoleEl.textContent = AppData.currentUser.position;
    }
    
    if (userAvatarEl && AppData.currentUser) {
        userAvatarEl.textContent = AppData.currentUser.avatar;
    }
}

function setupEventListeners() {
    // Logout button
    const logoutBtn = Utils.$('#logoutBtn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', handleLogout);
    }
    
    // Navigation links
    document.querySelectorAll('.nav-item').forEach(link => {
        link.addEventListener('click', function(e) {
            // Remove active class from all nav items
            document.querySelectorAll('.nav-item').forEach(item => {
                item.classList.remove('active');
            });
            
            // Add active class to clicked item
            this.classList.add('active');
        });
    });
    
    // Mobile sidebar toggle (for responsive design)
    const sidebarToggle = Utils.$('#sidebarToggle');
    if (sidebarToggle) {
        sidebarToggle.addEventListener('click', toggleSidebar);
    }
}

function loadDashboardData() {
    // Update statistics with animation
    updateDashboardStats();
    
    // Load recent issues
    loadRecentIssues();
    
    // Load quick stats
    loadQuickStats();
    
    // Add animation to stat cards
    animateStatCards();
}

function updateDashboardStats() {
    const stats = AppData.systemStats;
    
    // Animate stat numbers
    animateStatNumber('#totalUsers', stats.totalUsers);
    animateStatNumber('#totalCommunities', stats.activeCommunities);
    animateStatNumber('#totalCourses', stats.totalCourses);
    animateStatNumber('#reportIssues', stats.reportIssues);
    
    // Update stat subtitles
    const activeUsersEl = Utils.$('#activeUsers');
    const avgMembersEl = Utils.$('#avgMembers');
    const coursesDescEl = Utils.$('#coursesDesc');
    const pendingIssuesEl = Utils.$('#pendingIssues');
    
    if (activeUsersEl) {
        activeUsersEl.textContent = `${stats.totalUsers} active users`;
    }
    
    if (avgMembersEl) {
        avgMembersEl.textContent = `${stats.avgCommunitySize} avg members`;
    }
    
    if (coursesDescEl) {
        coursesDescEl.textContent = 'Across all communities';
    }
    
    if (pendingIssuesEl) {
        pendingIssuesEl.textContent = `${stats.pendingIssues} pending`;
    }
}

function loadRecentIssues() {
    const container = Utils.$('#recentIssuesList');
    if (!container) return;
    
    // Sample recent issues data matching the design
    const recentIssues = [
        {
            title: 'Update Profile Picture',
            type: 'warning',
            author: 'AdminUser',
            icon: 'alert-triangle'
        },
        {
            title: 'Reporting post content',
            type: 'success',
            author: 'AdminUser',
            icon: 'check-circle'
        },
        {
            title: 'Account Registration',
            type: 'warning',
            author: 'AdminUser',
            icon: 'alert-triangle'
        },
        {
            title: 'Community Description should use the div tag',
            type: 'warning',
            author: 'AdminUser',
            icon: 'alert-triangle'
        }
    ];
    
    container.innerHTML = '';
    
    recentIssues.forEach((issue, index) => {
        const issueEl = Utils.createElement('div', `issue-item ${issue.type}`);
        
        issueEl.innerHTML = `
            <div class="issue-icon ${issue.type}">
                <i data-lucide="${issue.icon}"></i>
            </div>
            <div class="issue-content">
                <div class="issue-title">${issue.title}</div>
                <div class="issue-meta">
                    <div class="issue-author">
                        <div class="user-avatar-tiny">★</div>
                        <span>by <span class="user-badge">${issue.author}</span></span>
                    </div>
                </div>
            </div>
        `;
        
        // Add animation delay
        issueEl.style.animationDelay = `${index * 0.1}s`;
        issueEl.classList.add('fade-in');
        
        container.appendChild(issueEl);
    });
    
    // Re-initialize icons
    lucide.createIcons();
}

function loadQuickStats() {
    const stats = AppData.systemStats;
    
    // Update quick stats values
    const quickStats = [
        { selector: '.quick-stat-percentage', value: `${stats.userActivityRate}%` },
        { selector: '.quick-stat-members', value: `${stats.avgCommunitySize} members` }
    ];
    
    quickStats.forEach(stat => {
        const elements = Utils.$$(stat.selector);
        elements.forEach(el => {
            if (el.textContent.includes('100%')) {
                el.textContent = `${stats.userActivityRate}%`;
            } else if (el.textContent.includes('33%')) {
                el.textContent = `${stats.reportResolutionRate}%`;
            } else if (el.textContent.includes('26 members')) {
                el.textContent = `${stats.avgCommunitySize} members`;
            } else if (el.textContent.includes('183 members')) {
                el.textContent = `${stats.totalPlatformMembers} members`;
            }
        });
    });
}

function animateStatNumber(selector, targetNumber) {
    const element = Utils.$(selector);
    if (!element) return;
    
    const duration = 2000;
    const startTime = performance.now();
    const startNumber = 0;
    
    function updateNumber(currentTime) {
        const elapsed = currentTime - startTime;
        const progress = Math.min(elapsed / duration, 1);
        
        // Easing function (easeOutCubic)
        const easedProgress = 1 - Math.pow(1 - progress, 3);
        
        const currentNumber = Math.floor(startNumber + (targetNumber - startNumber) * easedProgress);
        element.textContent = currentNumber;
        
        if (progress < 1) {
            requestAnimationFrame(updateNumber);
        }
    }
    
    requestAnimationFrame(updateNumber);
}

function animateStatCards() {
    const statCards = Utils.$$('.stat-card');
    
    statCards.forEach((card, index) => {
        card.style.opacity = '0';
        card.style.transform = 'translateY(20px)';
        
        setTimeout(() => {
            card.style.transition = 'all 0.5s ease';
            card.style.opacity = '1';
            card.style.transform = 'translateY(0)';
        }, index * 100);
    });
}

function toggleSidebar() {
    const sidebar = Utils.$('.admin-sidebar');
    if (sidebar) {
        sidebar.classList.toggle('mobile-open');
    }
}

function handleLogout() {
    // Show confirmation dialog
    if (confirm('Are you sure you want to logout?')) {
        // Add logout animation
        Utils.showLoading('Logging out...');
        
        setTimeout(() => {
            AppData.logout();
            Utils.hideLoading();
            Utils.showNotification('Logged out successfully', 'success');
            
            setTimeout(() => {
                window.location.href = 'index.html';
            }, 1000);
        }, 1000);
    }
}

// Navigation helper functions
function navigateToProjects() {
    Utils.showLoading('Loading projects...');
    setTimeout(() => {
        window.location.href = 'projects.html';
    }, 500);
}

function navigateToUsers() {
    Utils.showLoading('Loading user management...');
    setTimeout(() => {
        window.location.href = 'youth-profiling.html';
    }, 500);
}

function navigateToEvents() {
    Utils.showLoading('Loading events...');
    setTimeout(() => {
        window.location.href = 'events.html';
    }, 500);
}

// Add hover effects to stat cards
function addInteractiveEffects() {
    const statCards = Utils.$$('.stat-card');
    
    statCards.forEach(card => {
        card.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-4px)';
            this.style.boxShadow = 'var(--shadow-md)';
        });
        
        card.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0)';
            this.style.boxShadow = 'var(--shadow-sm)';
        });
    });
    
    // Add click effects to issue items
    const issueItems = Utils.$$('.issue-item');
    
    issueItems.forEach(item => {
        item.addEventListener('click', function() {
            this.style.backgroundColor = 'var(--white)';
            this.style.boxShadow = 'var(--shadow-sm)';
            
            // Reset after animation
            setTimeout(() => {
                this.style.backgroundColor = '';
                this.style.boxShadow = '';
            }, 200);
        });
    });
}

// Initialize interactive effects after page loads
window.addEventListener('load', function() {
    addInteractiveEffects();
});

// Handle window resize for responsive design
window.addEventListener('resize', function() {
    const sidebar = Utils.$('.admin-sidebar');
    
    if (window.innerWidth >= 1024) {
        if (sidebar) {
            sidebar.classList.remove('mobile-open');
        }
    }
});