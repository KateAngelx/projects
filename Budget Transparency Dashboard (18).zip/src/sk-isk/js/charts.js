// Charts Configuration and Utilities
const ChartConfig = {
    // Default colors matching the government design system
    colors: {
        primary: '#3498DB',
        sidebarDark: '#2C3E50',
        success: '#10B981',
        warning: '#F59E0B',
        danger: '#EF4444',
        info: '#06b6d4',
        purple: '#8B5CF6',
        gray: '#6B7280',
        used: '#4A90E2',
        remaining: '#E5E7EB'
    },
    
    // Default chart options
    defaultOptions: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: {
                labels: {
                    font: {
                        family: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
                        size: 12
                    },
                    color: '#374151',
                    usePointStyle: true,
                    padding: 20
                }
            },
            tooltip: {
                backgroundColor: '#1f2937',
                titleColor: '#f9fafb',
                bodyColor: '#f9fafb',
                borderColor: '#374151',
                borderWidth: 1,
                cornerRadius: 8,
                titleFont: {
                    size: 14,
                    weight: 'bold'
                },
                bodyFont: {
                    size: 13
                },
                padding: 12
            }
        },
        animation: {
            duration: 2000,
            easing: 'easeInOutQuart',
            delay: (context) => {
                let delay = 0;
                if (context.type === 'data' && context.mode === 'default') {
                    delay = context.dataIndex * 100;
                }
                return delay;
            }
        }
    },
    
    // Chart type specific configurations
    doughnut: {
        cutout: '60%',
        plugins: {
            legend: {
                position: 'bottom'
            }
        }
    },
    
    bar: {
        scales: {
            y: {
                beginAtZero: true,
                grid: {
                    color: '#f3f4f6',
                    borderColor: '#e5e7eb'
                },
                ticks: {
                    color: '#6b7280',
                    font: {
                        size: 11
                    }
                }
            },
            x: {
                grid: {
                    display: false
                },
                ticks: {
                    color: '#6b7280',
                    font: {
                        size: 11
                    }
                }
            }
        }
    },
    
    line: {
        elements: {
            line: {
                borderWidth: 3,
                tension: 0.4
            },
            point: {
                radius: 5,
                hoverRadius: 7,
                borderWidth: 2
            }
        },
        scales: {
            y: {
                beginAtZero: true,
                grid: {
                    color: '#f3f4f6',
                    borderColor: '#e5e7eb'
                },
                ticks: {
                    color: '#6b7280',
                    font: {
                        size: 11
                    }
                }
            },
            x: {
                grid: {
                    display: false
                },
                ticks: {
                    color: '#6b7280',
                    font: {
                        size: 11
                    }
                }
            }
        }
    }
};

// Chart utility functions
const ChartUtils = {
    // Create a chart with default configuration
    createChart(canvas, type, data, customOptions = {}) {
        if (!canvas) return null;
        
        const ctx = canvas.getContext('2d');
        
        // Merge default options with custom options
        const options = this.mergeOptions(type, customOptions);
        
        return new Chart(ctx, {
            type: type,
            data: data,
            options: options
        });
    },
    
    // Merge default options with custom options
    mergeOptions(chartType, customOptions) {
        const baseOptions = { ...ChartConfig.defaultOptions };
        const typeOptions = ChartConfig[chartType] || {};
        
        return this.deepMerge(baseOptions, typeOptions, customOptions);
    },
    
    // Deep merge objects
    deepMerge(target, ...sources) {
        if (!sources.length) return target;
        const source = sources.shift();
        
        if (this.isObject(target) && this.isObject(source)) {
            for (const key in source) {
                if (this.isObject(source[key])) {
                    if (!target[key]) Object.assign(target, { [key]: {} });
                    this.deepMerge(target[key], source[key]);
                } else {
                    Object.assign(target, { [key]: source[key] });
                }
            }
        }
        
        return this.deepMerge(target, ...sources);
    },
    
    // Check if value is object
    isObject(item) {
        return item && typeof item === 'object' && !Array.isArray(item);
    },
    
    // Generate color palette
    generateColors(count, baseColor = 'primary') {
        const color = ChartConfig.colors[baseColor] || ChartConfig.colors.primary;
        const colors = [];
        
        for (let i = 0; i < count; i++) {
            const opacity = 0.8 - (i * 0.1);
            colors.push(this.hexToRgba(color, Math.max(opacity, 0.3)));
        }
        
        return colors;
    },
    
    // Convert hex to rgba
    hexToRgba(hex, alpha = 1) {
        const r = parseInt(hex.slice(1, 3), 16);
        const g = parseInt(hex.slice(3, 5), 16);
        const b = parseInt(hex.slice(5, 7), 16);
        
        return `rgba(${r}, ${g}, ${b}, ${alpha})`;
    },
    
    // Create gradient
    createGradient(ctx, color1, color2, direction = 'vertical') {
        const gradient = direction === 'vertical' 
            ? ctx.createLinearGradient(0, 0, 0, 400)
            : ctx.createLinearGradient(0, 0, 400, 0);
            
        gradient.addColorStop(0, color1);
        gradient.addColorStop(1, color2);
        
        return gradient;
    },
    
    // Format currency for chart labels
    formatCurrency(value) {
        return new Intl.NumberFormat('en-PH', {
            style: 'currency',
            currency: 'PHP',
            minimumFractionDigits: 0,
            maximumFractionDigits: 0
        }).format(value);
    },
    
    // Format number for chart labels
    formatNumber(value) {
        if (value >= 1000000) {
            return (value / 1000000).toFixed(1) + 'M';
        } else if (value >= 1000) {
            return (value / 1000).toFixed(1) + 'K';
        }
        return value.toString();
    },
    
    // Create pie chart data
    createPieData(labels, values, colors = null) {
        return {
            labels: labels,
            datasets: [{
                data: values,
                backgroundColor: colors || this.generateColors(values.length),
                borderWidth: 2,
                borderColor: '#ffffff',
                hoverBorderWidth: 3
            }]
        };
    },
    
    // Create bar chart data
    createBarData(labels, datasets) {
        return {
            labels: labels,
            datasets: datasets.map((dataset, index) => ({
                label: dataset.label,
                data: dataset.data,
                backgroundColor: dataset.backgroundColor || this.generateColors(1)[0],
                borderRadius: 6,
                borderSkipped: false,
                ...dataset
            }))
        };
    },
    
    // Create line chart data
    createLineData(labels, datasets) {
        return {
            labels: labels,
            datasets: datasets.map((dataset, index) => ({
                label: dataset.label,
                data: dataset.data,
                borderColor: dataset.borderColor || ChartConfig.colors.primary,
                backgroundColor: dataset.backgroundColor || this.hexToRgba(ChartConfig.colors.primary, 0.1),
                fill: dataset.fill !== undefined ? dataset.fill : true,
                ...dataset
            }))
        };
    },
    
    // Update chart data
    updateChart(chart, newData) {
        if (!chart) return;
        
        chart.data = newData;
        chart.update('none'); // Update without animation
    },
    
    // Animate chart update
    animateChartUpdate(chart, newData) {
        if (!chart) return;
        
        chart.data = newData;
        chart.update(); // Update with animation
    },
    
    // Destroy chart safely
    destroyChart(chart) {
        if (chart && typeof chart.destroy === 'function') {
            chart.destroy();
        }
    }
};

// Dashboard specific chart initializers
const DashboardCharts = {
    budgetChart: null,
    categoryChart: null,
    
    initBudgetVsExpensesChart() {
        const canvas = document.getElementById('budgetVsExpensesChart');
        if (!canvas) return;
        
        const used = 612000;
        const remaining = 238000;
        
        const data = {
            labels: ['Used Budget', 'Remaining Budget'],
            datasets: [{
                data: [used, remaining],
                backgroundColor: [
                    ChartConfig.colors.used,
                    ChartConfig.colors.remaining
                ],
                borderWidth: 0,
                hoverBorderWidth: 3,
                hoverBorderColor: '#fff'
            }]
        };
        
        const options = {
            responsive: true,
            maintainAspectRatio: false,
            cutout: '70%',
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const value = context.parsed;
                            const total = context.dataset.data.reduce((a, b) => a + b, 0);
                            const percentage = ((value / total) * 100).toFixed(1);
                            return `${context.label}: ₱${value.toLocaleString()} (${percentage}%)`;
                        }
                    }
                }
            },
            animation: {
                animateRotate: true,
                duration: 2000,
                easing: 'easeInOutQuart'
            }
        };
        
        this.budgetChart = new Chart(canvas, {
            type: 'doughnut',
            data: data,
            options: options
        });
    },
    
    initExpensesByCategoryChart() {
        const canvas = document.getElementById('expensesByCategoryChart');
        if (!canvas) return;
        
        const data = {
            labels: ['Education', 'Sports', 'Community Dev', 'Health', 'Environment', 'Arts & Culture'],
            datasets: [{
                label: 'Expenses',
                data: [180000, 150000, 120000, 80000, 50000, 32000],
                backgroundColor: [
                    ChartConfig.colors.primary,
                    ChartConfig.colors.success,
                    ChartConfig.colors.warning,
                    ChartConfig.colors.purple,
                    ChartConfig.colors.danger,
                    ChartConfig.colors.info
                ],
                borderRadius: 8,
                borderSkipped: false
            }]
        };
        
        const options = {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return `${context.label}: ₱${context.parsed.y.toLocaleString()}`;
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    grid: {
                        color: '#f3f4f6',
                        borderColor: '#e5e7eb'
                    },
                    ticks: {
                        color: '#6b7280',
                        font: {
                            size: 11
                        },
                        callback: function(value) {
                            return '₱' + (value / 1000) + 'K';
                        }
                    }
                },
                x: {
                    grid: {
                        display: false
                    },
                    ticks: {
                        color: '#6b7280',
                        font: {
                            size: 11
                        },
                        maxRotation: 45
                    }
                }
            },
            animation: {
                duration: 2000,
                easing: 'easeInOutQuart',
                delay: (context) => {
                    if (context.type === 'data' && context.mode === 'default') {
                        return context.dataIndex * 200;
                    }
                    return 0;
                }
            }
        };
        
        this.categoryChart = new Chart(canvas, {
            type: 'bar',
            data: data,
            options: options
        });
    },
    
    init() {
        // Wait for DOM to be ready
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', () => {
                this.initBudgetVsExpensesChart();
                this.initExpensesByCategoryChart();
            });
        } else {
            this.initBudgetVsExpensesChart();
            this.initExpensesByCategoryChart();
        }
    },
    
    destroy() {
        if (this.budgetChart) {
            this.budgetChart.destroy();
            this.budgetChart = null;
        }
        if (this.categoryChart) {
            this.categoryChart.destroy();
            this.categoryChart = null;
        }
    }
};

// Export for use in other files
if (typeof window !== 'undefined') {
    window.ChartConfig = ChartConfig;
    window.ChartUtils = ChartUtils;
    window.DashboardCharts = DashboardCharts;
}

// Chart.js global configuration
if (typeof Chart !== 'undefined') {
    Chart.defaults.font.family = '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
    Chart.defaults.font.size = 12;
    Chart.defaults.color = '#374151';
    
    // Register plugins if available
    if (Chart.registry) {
        // Additional Chart.js configuration can go here
    }
}