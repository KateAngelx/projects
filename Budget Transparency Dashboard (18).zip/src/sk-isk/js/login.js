// Login Page JavaScript
document.addEventListener('DOMContentLoaded', function() {
    // Initialize data
    AppData.init();
    
    // Initialize icons
    if (typeof lucide !== 'undefined') {
        lucide.createIcons();
    }
    
    // Setup event listeners
    setupEventListeners();
    
    // Check if already logged in
    checkLoginStatus();
    
    // Focus username field
    const usernameField = Utils.$('#username');
    if (usernameField) {
        usernameField.focus();
    }
    
    console.log('Login page initialized');
});

function setupEventListeners() {
    // Login form submission
    const loginForm = Utils.$('#loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', handleLogin);
    }
    
    // Enter key handling
    document.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            const form = Utils.$('#loginForm');
            if (form) {
                handleLogin(e);
            }
        }
    });
}

function handleLogin(event) {
    event.preventDefault();
    
    const formData = Utils.getFormData('#loginForm');
    const { username, password, remember } = formData;
    
    // Validate form
    const validation = Utils.validateForm('#loginForm', {
        username: {
            required: true,
            requiredMessage: 'Username is required'
        },
        password: {
            required: true,
            requiredMessage: 'Password is required'
        }
    });
    
    if (!validation.isValid) {
        return;
    }
    
    // Show loading state
    showLoadingState();
    
    // Simulate network delay for better UX
    setTimeout(() => {
        if (AppData.login(username, password)) {
            showSuccessState();
            
            // Remember user if checkbox is checked
            if (remember) {
                Utils.saveToStorage('rememberedUser', username);
            } else {
                Utils.removeFromStorage('rememberedUser');
            }
            
            // Redirect to dashboard after success animation
            setTimeout(() => {
                window.location.href = 'dashboard.html';
            }, 1500);
        } else {
            showErrorState();
        }
    }, 800);
}

function showLoadingState() {
    const submitBtn = Utils.$('button[type="submit"]');
    if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.innerHTML = `
            <div class="spinner" style="width: 1rem; height: 1rem; margin-right: 0.5rem;"></div>
            Signing In...
        `;
    }
}

function showSuccessState() {
    const submitBtn = Utils.$('button[type="submit"]');
    if (submitBtn) {
        submitBtn.innerHTML = `
            <i data-lucide="check-circle"></i>
            Success! Redirecting...
        `;
        submitBtn.style.backgroundColor = 'var(--green-500)';
        lucide.createIcons();
    }
    
    Utils.showNotification('Login successful! Redirecting to dashboard...', 'success', 2000);
}

function showErrorState() {
    const submitBtn = Utils.$('button[type="submit"]');
    if (submitBtn) {
        submitBtn.disabled = false;
        submitBtn.innerHTML = `
            <i data-lucide="log-in"></i>
            Sign In
        `;
        submitBtn.style.backgroundColor = '';
        lucide.createIcons();
    }
    
    // Show error notification
    Utils.showNotification('Invalid username or password. Please try again.', 'error');
    
    // Add shake animation to form
    const loginContainer = Utils.$('.login-container');
    if (loginContainer) {
        loginContainer.style.animation = 'shake 0.5s ease-in-out';
        setTimeout(() => {
            loginContainer.style.animation = '';
        }, 500);
    }
    
    // Clear password field and focus it
    const passwordField = Utils.$('#password');
    if (passwordField) {
        passwordField.value = '';
        passwordField.focus();
    }
}

function checkLoginStatus() {
    // Check if user is already logged in
    if (AppData.isLoggedIn && AppData.currentUser) {
        window.location.href = 'dashboard.html';
        return;
    }
    
    // Check for remembered user
    const rememberedUser = Utils.loadFromStorage('rememberedUser');
    if (rememberedUser) {
        const usernameField = Utils.$('#username');
        const rememberCheckbox = Utils.$('#remember');
        
        if (usernameField) {
            usernameField.value = rememberedUser;
        }
        
        if (rememberCheckbox) {
            rememberCheckbox.checked = true;
        }
        
        // Focus password field
        const passwordField = Utils.$('#password');
        if (passwordField) {
            passwordField.focus();
        }
    }
}

// Global function for demo credentials (called by onclick)
function fillCredentials(username, password) {
    const usernameField = Utils.$('#username');
    const passwordField = Utils.$('#password');
    
    if (usernameField && passwordField) {
        usernameField.value = username;
        passwordField.value = password;
        
        // Add visual feedback
        usernameField.style.backgroundColor = 'var(--green-100)';
        passwordField.style.backgroundColor = 'var(--green-100)';
        
        setTimeout(() => {
            usernameField.style.backgroundColor = '';
            passwordField.style.backgroundColor = '';
        }, 1000);
        
        // Focus password field for immediate submission
        passwordField.focus();
        passwordField.select();
    }
}

// Add CSS for shake animation
const shakeCSS = `
@keyframes shake {
    0%, 100% { transform: translateX(0); }
    25% { transform: translateX(-10px); }
    75% { transform: translateX(10px); }
}
`;

// Inject CSS
const style = document.createElement('style');
style.textContent = shakeCSS;
document.head.appendChild(style);