// Events Page JavaScript
document.addEventListener('DOMContentLoaded', function() {
    // Initialize data
    AppData.init();
    
    // Initialize icons
    if (typeof lucide !== 'undefined') {
        lucide.createIcons();
    }
    
    // Load events
    loadEvents();
    
    // Setup event listeners
    setupEventListeners();
    
    console.log('Events page initialized');
});

function setupEventListeners() {
    // Registration form
    const registrationForm = Utils.$('#registrationForm');
    if (registrationForm) {
        registrationForm.addEventListener('submit', handleEventRegistration);
    }
}

function loadEvents() {
    const container = Utils.$('#eventsList');
    if (!container) return;
    
    const events = AppData.events;
    
    container.innerHTML = '';
    
    events.forEach((event, index) => {
        const eventCard = createEventCard(event, index);
        container.appendChild(eventCard);
    });
    
    // Re-initialize icons
    lucide.createIcons();
}

function createEventCard(event, index) {
    const card = Utils.createElement('div', 'card event-card');
    
    const eventDate = new Date(event.date);
    
    card.innerHTML = `
        <div class="card-body">
            <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 1rem;">
                <div style="display: flex; align-items: center; gap: 1rem;">
                    <div style="text-align: center; padding: 0.75rem; background-color: var(--primary-blue); color: var(--white); border-radius: 0.5rem; min-width: 4rem;">
                        <div style="font-size: 1.25rem; font-weight: bold; line-height: 1;">${eventDate.getDate()}</div>
                        <div style="font-size: 0.75rem; text-transform: uppercase; letter-spacing: 0.5px;">${eventDate.toLocaleDateString('en-US', { month: 'short' })}</div>
                    </div>
                    <span class="badge badge-${Utils.getCategoryColor(event.category)}">${event.category}</span>
                </div>
                <span class="badge badge-info">${Utils.capitalizeFirst(event.status)}</span>
            </div>
            
            <h3 style="margin-bottom: 0.75rem; font-size: 1.125rem;">${event.title}</h3>
            
            <p style="color: var(--gray-600); margin-bottom: 1.5rem; font-size: 0.875rem; line-height: 1.5;">${event.description}</p>
            
            <div style="display: flex; flex-direction: column; gap: 0.75rem; margin-bottom: 1.5rem; font-size: 0.875rem;">
                <div style="display: flex; align-items: center; gap: 0.75rem;">
                    <i data-lucide="map-pin" style="width: 1rem; height: 1rem; color: var(--gray-400);"></i>
                    <span style="color: var(--gray-600);">${event.location}</span>
                </div>
                <div style="display: flex; align-items: center; gap: 0.75rem;">
                    <i data-lucide="calendar" style="width: 1rem; height: 1rem; color: var(--gray-400);"></i>
                    <span style="color: var(--gray-600);">${Utils.formatDate(event.date)}</span>
                </div>
                <div style="display: flex; align-items: center; gap: 0.75rem;">
                    <i data-lucide="users" style="width: 1rem; height: 1rem; color: var(--gray-400);"></i>
                    <span style="color: var(--gray-600);">${event.attendees} expected attendees</span>
                </div>
            </div>
            
            <div style="display: flex; gap: 0.75rem;">
                <button class="btn btn-outline btn-sm" onclick="viewEventDetails(${event.id})" style="flex: 1;">
                    <i data-lucide="eye"></i>
                    View Details
                </button>
                <button class="btn btn-primary btn-sm" onclick="registerForEvent(${event.id})">
                    <i data-lucide="user-plus"></i>
                    Register
                </button>
            </div>
        </div>
    `;
    
    // Add animation
    card.style.opacity = '0';
    card.style.transform = 'translateY(20px)';
    
    setTimeout(() => {
        card.style.transition = 'all 0.5s ease';
        card.style.opacity = '1';
        card.style.transform = 'translateY(0)';
    }, index * 100);
    
    return card;
}

function handleEventRegistration(event) {
    event.preventDefault();
    
    const formData = Utils.getFormData('#registrationForm');
    
    // Validate form
    const validation = Utils.validateForm('#registrationForm', {
        name: {
            required: true,
            requiredMessage: 'Full name is required'
        },
        email: {
            required: true,
            email: true,
            emailMessage: 'Please enter a valid email address'
        },
        age: {
            required: true,
            custom: (value) => {
                const age = parseInt(value);
                if (age < 15 || age > 30) {
                    return 'Age must be between 15 and 30';
                }
                return true;
            }
        }
    });
    
    if (!validation.isValid) {
        return;
    }
    
    // Get selected interests
    const interests = Array.from(document.querySelectorAll('input[name="interests"]:checked'))
        .map(checkbox => checkbox.value);
    
    // Show loading
    Utils.showLoading('Registering your interest...');
    
    // Simulate API call
    setTimeout(() => {
        Utils.hideLoading();
        Utils.showNotification('Thank you for your interest! We will contact you about upcoming events.', 'success');
        
        // Reset form
        Utils.resetForm('#registrationForm');
        
        // Add to audit log if admin is logged in
        if (AppData.currentUser) {
            AppData.addAuditLog(
                AppData.currentUser.fullName,
                'Create',
                `New event registration: ${formData.name} (${formData.email})`
            );
        }
    }, 2000);
}

// Global functions for button clicks
function viewEventDetails(eventId) {
    const event = AppData.events.find(e => e.id === eventId);
    if (!event) return;
    
    // Create and show modal
    const modal = Utils.createElement('div', 'modal');
    modal.innerHTML = `
        <div class="modal-content" style="max-width: 600px;">
            <div class="modal-header">
                <h3 class="modal-title">${event.title}</h3>
                <button class="modal-close" onclick="closeEventModal()">
                    <i data-lucide="x"></i>
                </button>
            </div>
            <div class="modal-body">
                <div style="display: flex; gap: 1rem; margin-bottom: 1.5rem;">
                    <span class="badge badge-${Utils.getCategoryColor(event.category)}">${event.category}</span>
                    <span class="badge badge-info">${Utils.capitalizeFirst(event.status)}</span>
                </div>
                
                <div style="margin-bottom: 1.5rem;">
                    <h4 style="margin-bottom: 0.5rem;">Description</h4>
                    <p style="color: var(--gray-600); line-height: 1.6;">${event.description}</p>
                </div>
                
                <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 1rem; margin-bottom: 1.5rem;">
                    <div>
                        <h4 style="margin-bottom: 0.5rem;">Date & Time</h4>
                        <p style="font-weight: 600;">${Utils.formatDate(event.date)}</p>
                    </div>
                    <div>
                        <h4 style="margin-bottom: 0.5rem;">Location</h4>
                        <p style="font-weight: 600;">${event.location}</p>
                    </div>
                    <div>
                        <h4 style="margin-bottom: 0.5rem;">Expected Attendees</h4>
                        <p style="font-size: 1.25rem; font-weight: 600; color: var(--primary-blue);">${event.attendees}</p>
                    </div>
                    <div>
                        <h4 style="margin-bottom: 0.5rem;">Category</h4>
                        <p style="font-weight: 600;">${event.category}</p>
                    </div>
                </div>
                
                <div style="background-color: var(--gray-50); padding: 1.5rem; border-radius: var(--radius-lg); margin-bottom: 1.5rem;">
                    <h4 style="margin-bottom: 1rem;">What to Expect</h4>
                    <ul style="color: var(--gray-600); line-height: 1.6; padding-left: 1.5rem;">
                        <li>Engaging activities and workshops</li>
                        <li>Networking opportunities with fellow youth</li>
                        <li>Free refreshments and materials</li>
                        <li>Certificate of participation</li>
                    </ul>
                </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-outline" onclick="closeEventModal()">Close</button>
                <button class="btn btn-primary" onclick="registerForEvent(${eventId}); closeEventModal();">
                    <i data-lucide="user-plus"></i>
                    Register for Event
                </button>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    lucide.createIcons();
    
    // Show modal with animation
    setTimeout(() => {
        modal.classList.add('active');
    }, 10);
}

function closeEventModal() {
    const modal = Utils.$('.modal');
    if (modal) {
        modal.classList.remove('active');
        setTimeout(() => {
            modal.remove();
        }, 300);
    }
}

function registerForEvent(eventId) {
    const event = AppData.events.find(e => e.id === eventId);
    if (!event) return;
    
    // Scroll to registration form
    const registrationForm = Utils.$('#registrationForm');
    if (registrationForm) {
        registrationForm.scrollIntoView({ behavior: 'smooth', block: 'center' });
        
        // Highlight the form
        registrationForm.style.backgroundColor = 'var(--secondary-blue)';
        setTimeout(() => {
            registrationForm.style.backgroundColor = '';
        }, 2000);
        
        // Focus first input
        const firstInput = registrationForm.querySelector('input');
        if (firstInput) {
            setTimeout(() => {
                firstInput.focus();
            }, 500);
        }
    }
    
    Utils.showNotification(`Scroll down to register for "${event.title}"`, 'info');
}