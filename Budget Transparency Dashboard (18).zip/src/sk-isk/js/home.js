// Home Page JavaScript
document.addEventListener('DOMContentLoaded', function() {
    // Initialize data
    AppData.init();
    
    // Initialize icons
    if (typeof lucide !== 'undefined') {
        lucide.createIcons();
    }
    
    // Update statistics
    updateHomeStats();
    
    // Render featured content
    renderFeaturedProjects();
    renderUpcomingEvents();
    
    console.log('Home page initialized');
});

function updateHomeStats() {
    const publicProjects = AppData.getPublicProjects();
    const totalYouth = AppData.getTotalYouth();
    const totalBudget = AppData.getTotalBudget();
    
    // Update stat numbers with animation
    const projectCountEl = Utils.$('#projectCount');
    const eventCountEl = Utils.$('#eventCount');
    const youthCountEl = Utils.$('#youthCount');
    const totalBudgetEl = Utils.$('#totalBudget');
    
    if (projectCountEl) {
        animateNumber(projectCountEl, publicProjects.length);
    }
    
    if (eventCountEl) {
        animateNumber(eventCountEl, AppData.events.length);
    }
    
    if (youthCountEl) {
        animateNumber(youthCountEl, totalYouth);
    }
    
    if (totalBudgetEl) {
        totalBudgetEl.textContent = Utils.formatCurrency(totalBudget);
    }
}

function renderFeaturedProjects() {
    const container = Utils.$('#featuredProjectsList');
    if (!container) return;
    
    const publicProjects = AppData.getPublicProjects().slice(0, 3); // Show top 3
    
    container.innerHTML = '';
    
    publicProjects.forEach((project, index) => {
        const projectCard = createProjectCard(project, index);
        container.appendChild(projectCard);
    });
    
    // Re-initialize icons
    lucide.createIcons();
}

function createProjectCard(project, index) {
    const card = Utils.createElement('div', 'card project-card');
    
    card.innerHTML = `
        <div class="card-body">
            <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 1rem;">
                <div style="display: flex; align-items: center; gap: 0.75rem;">
                    <div style="width: 2.5rem; height: 2.5rem; background-color: var(--${getCategoryColor(project.category)}); border-radius: 0.5rem; display: flex; align-items: center; justify-content: center; color: var(--white);">
                        <i data-lucide="${getCategoryIcon(project.category)}" style="width: 1.25rem; height: 1.25rem;"></i>
                    </div>
                    <span class="badge badge-${Utils.getCategoryColor(project.category)}">${project.category}</span>
                </div>
                ${project.showStatus ? `<span class="badge badge-${Utils.getStatusColor(project.status)}">${Utils.capitalizeFirst(project.status)}</span>` : ''}
            </div>
            
            <h3 style="margin-bottom: 0.75rem; font-size: 1.125rem;">${project.title}</h3>
            
            ${project.showDescription ? `<p style="color: var(--gray-600); margin-bottom: 1.5rem; font-size: 0.875rem; line-height: 1.5;">${Utils.truncateText(project.description, 120)}</p>` : ''}
            
            <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 1rem; margin-bottom: 1.5rem; font-size: 0.875rem;">
                ${project.showBudget ? `
                    <div>
                        <div style="color: var(--gray-500); margin-bottom: 0.25rem;">Budget</div>
                        <div style="font-weight: 600; color: var(--gray-900);">${Utils.formatCurrency(project.budget)}</div>
                    </div>
                ` : ''}
                <div>
                    <div style="color: var(--gray-500); margin-bottom: 0.25rem;">Participants</div>
                    <div style="font-weight: 600; color: var(--gray-900);">${project.participants || 0}</div>
                </div>
                <div>
                    <div style="color: var(--gray-500); margin-bottom: 0.25rem;">Date Started</div>
                    <div style="font-weight: 600; color: var(--gray-900);">${Utils.formatDate(project.date)}</div>
                </div>
                <div>
                    <div style="color: var(--gray-500); margin-bottom: 0.25rem;">Created By</div>
                    <div style="font-weight: 600; color: var(--gray-900);">${project.createdBy}</div>
                </div>
            </div>
            
            ${project.showBudget ? `
                <div style="margin-bottom: 1.5rem;">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.5rem;">
                        <span style="font-size: 0.875rem; color: var(--gray-600);">Budget Utilization</span>
                        <span style="font-size: 0.875rem; font-weight: 600; color: var(--gray-900);">${Utils.calculateProgress(project.expenses, project.budget)}%</span>
                    </div>
                    <div class="progress-bar">
                        <div class="progress-fill progress-fill-${Utils.getProgressColor(Utils.calculateProgress(project.expenses, project.budget))}" 
                             style="width: ${Utils.calculateProgress(project.expenses, project.budget)}%;"></div>
                    </div>
                    <div style="display: flex; justify-content: space-between; margin-top: 0.5rem; font-size: 0.75rem; color: var(--gray-500);">
                        <span>Spent: ${Utils.formatCurrency(project.expenses)}</span>
                        <span>Remaining: ${Utils.formatCurrency(project.budget - project.expenses)}</span>
                    </div>
                </div>
            ` : ''}
            
            <div style="display: flex; gap: 0.75rem;">
                <a href="projects.html" class="btn btn-outline btn-sm" style="flex: 1;">
                    <i data-lucide="eye"></i>
                    View Details
                </a>
                <button class="btn btn-primary btn-sm" onclick="shareProject(${project.id})">
                    <i data-lucide="share-2"></i>
                    Share
                </button>
            </div>
        </div>
    `;
    
    // Add animation
    card.style.opacity = '0';
    card.style.transform = 'translateY(20px)';
    
    setTimeout(() => {
        card.style.transition = 'all 0.5s ease';
        card.style.opacity = '1';
        card.style.transform = 'translateY(0)';
    }, index * 100);
    
    return card;
}

function renderUpcomingEvents() {
    const container = Utils.$('#upcomingEventsList');
    if (!container) return;
    
    const upcomingEvents = AppData.events.slice(0, 3); // Show top 3
    
    container.innerHTML = '';
    
    upcomingEvents.forEach((event, index) => {
        const eventCard = createEventCard(event, index);
        container.appendChild(eventCard);
    });
    
    // Re-initialize icons
    lucide.createIcons();
}

function createEventCard(event, index) {
    const card = Utils.createElement('div', 'card event-card');
    
    const eventDate = new Date(event.date);
    
    card.innerHTML = `
        <div class="card-body">
            <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 1rem;">
                <div style="display: flex; align-items: center; gap: 1rem;">
                    <div style="text-align: center; padding: 0.75rem; background-color: var(--primary-blue); color: var(--white); border-radius: 0.5rem; min-width: 4rem;">
                        <div style="font-size: 1.25rem; font-weight: bold; line-height: 1;">${eventDate.getDate()}</div>
                        <div style="font-size: 0.75rem; text-transform: uppercase; letter-spacing: 0.5px;">${eventDate.toLocaleDateString('en-US', { month: 'short' })}</div>
                    </div>
                    <span class="badge badge-${Utils.getCategoryColor(event.category)}">${event.category}</span>
                </div>
            </div>
            
            <h3 style="margin-bottom: 0.75rem; font-size: 1.125rem;">${event.title}</h3>
            
            <p style="color: var(--gray-600); margin-bottom: 1.5rem; font-size: 0.875rem; line-height: 1.5;">${Utils.truncateText(event.description, 100)}</p>
            
            <div style="display: flex; flex-direction: column; gap: 0.75rem; margin-bottom: 1.5rem; font-size: 0.875rem;">
                <div style="display: flex; align-items: center; gap: 0.75rem;">
                    <i data-lucide="map-pin" style="width: 1rem; height: 1rem; color: var(--gray-400);"></i>
                    <span style="color: var(--gray-600);">${event.location}</span>
                </div>
                <div style="display: flex; align-items: center; gap: 0.75rem;">
                    <i data-lucide="calendar" style="width: 1rem; height: 1rem; color: var(--gray-400);"></i>
                    <span style="color: var(--gray-600);">${Utils.formatDate(event.date)}</span>
                </div>
                <div style="display: flex; align-items: center; gap: 0.75rem;">
                    <i data-lucide="users" style="width: 1rem; height: 1rem; color: var(--gray-400);"></i>
                    <span style="color: var(--gray-600);">${event.attendees} expected attendees</span>
                </div>
            </div>
            
            <div style="display: flex; gap: 0.75rem;">
                <a href="events.html" class="btn btn-outline btn-sm" style="flex: 1;">
                    <i data-lucide="calendar"></i>
                    View Event
                </a>
                <button class="btn btn-primary btn-sm" onclick="registerForEvent(${event.id})">
                    <i data-lucide="user-plus"></i>
                    Register
                </button>
            </div>
        </div>
    `;
    
    // Add animation
    card.style.opacity = '0';
    card.style.transform = 'translateY(20px)';
    
    setTimeout(() => {
        card.style.transition = 'all 0.5s ease';
        card.style.opacity = '1';
        card.style.transform = 'translateY(0)';
    }, index * 100);
    
    return card;
}

function getCategoryIcon(category) {
    const categoryIcons = {
        'Sports': 'trophy',
        'Education': 'graduation-cap',
        'Livelihood': 'briefcase',
        'Health': 'heart',
        'Environment': 'leaf'
    };
    return categoryIcons[category] || 'folder';
}

function getCategoryColor(category) {
    const categoryColors = {
        'Sports': 'primary-blue',
        'Education': 'green-500',
        'Livelihood': 'yellow-500',
        'Health': 'red-500',
        'Environment': 'purple-500'
    };
    return categoryColors[category] || 'gray-500';
}

function animateNumber(element, targetNumber) {
    const duration = 2000; // 2 seconds
    const startTime = performance.now();
    const startNumber = 0;
    
    function updateNumber(currentTime) {
        const elapsed = currentTime - startTime;
        const progress = Math.min(elapsed / duration, 1);
        
        // Easing function (easeOutCubic)
        const easedProgress = 1 - Math.pow(1 - progress, 3);
        
        const currentNumber = Math.floor(startNumber + (targetNumber - startNumber) * easedProgress);
        
        if (targetNumber > 1000) {
            element.textContent = Utils.formatNumber(currentNumber);
        } else {
            element.textContent = currentNumber;
        }
        
        if (progress < 1) {
            requestAnimationFrame(updateNumber);
        }
    }
    
    requestAnimationFrame(updateNumber);
}

// Global functions for button clicks
function shareProject(projectId) {
    const project = AppData.projects.find(p => p.id === projectId);
    if (!project) return;
    
    if (navigator.share) {
        navigator.share({
            title: `SK Project: ${project.title}`,
            text: `Check out this SK project: ${project.title}`,
            url: window.location.href
        });
    } else {
        const shareText = `Check out this SK project: ${project.title} - ${project.description}`;
        navigator.clipboard.writeText(shareText).then(() => {
            Utils.showNotification('Project details copied to clipboard!', 'success');
        });
    }
}

function registerForEvent(eventId) {
    const event = AppData.events.find(e => e.id === eventId);
    if (!event) return;
    
    Utils.showNotification(`Registration for "${event.title}" will be available soon!`, 'info');
}

// Add scroll animations
function addScrollAnimations() {
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('fade-in');
            }
        });
    }, observerOptions);
    
    // Observe sections
    document.querySelectorAll('section').forEach(section => {
        observer.observe(section);
    });
}

// Initialize scroll animations when page loads
window.addEventListener('load', addScrollAnimations);