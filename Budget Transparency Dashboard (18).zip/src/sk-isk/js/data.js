// SK Admin Panel Data Management
const AppData = {
    // System state
    isLoggedIn: false,
    currentUser: null,
    
    // Admin users
    users: [
        {
            id: 1,
            username: 'admin',
            password: 'admin',
            fullName: 'SUPER_ADMIN',
            position: 'Administrator',
            role: 'admin',
            avatar: 'OA',
            isActive: true
        },
        {
            id: 2,
            username: 'treasurer',
            password: 'admin',
            fullName: 'Maria Santos',
            position: 'SK Treasurer',
            role: 'treasurer',
            avatar: 'MS',
            isActive: true
        },
        {
            id: 3,
            username: 'secretary',
            password: 'admin',
            fullName: 'Juan dela Cruz',
            position: 'SK Secretary',
            role: 'secretary',
            avatar: 'JC',
            isActive: true
        }
    ],
    
    // Projects data
    projects: [
        {
            id: 1,
            title: 'Youth Basketball Tournament',
            description: 'Annual basketball tournament for youth aged 15-25 to promote sports and healthy competition.',
            category: 'Sports',
            status: 'ongoing',
            budget: 50000,
            expenses: 32000,
            date: '2024-02-15',
            participants: 120,
            createdBy: 'SUPER_ADMIN',
            isPublic: true,
            showBudget: true,
            showDescription: true,
            showStatus: true
        },
        {
            id: 2,
            title: 'Computer Literacy Training',
            description: 'Free computer literacy training program for out-of-school youth.',
            category: 'Education',
            status: 'completed',
            budget: 75000,
            expenses: 72000,
            date: '2024-01-10',
            participants: 45,
            createdBy: 'Maria Santos',
            isPublic: true,
            showBudget: true,
            showDescription: true,
            showStatus: true
        },
        {
            id: 3,
            title: 'Livelihood Skills Workshop',
            description: 'Training workshop on various livelihood skills including cooking, crafts, and small business management.',
            category: 'Livelihood',
            status: 'ongoing',
            budget: 60000,
            expenses: 25000,
            date: '2024-03-01',
            participants: 30,
            createdBy: 'Juan dela Cruz',
            isPublic: true,
            showBudget: true,
            showDescription: true,
            showStatus: true
        },
        {
            id: 4,
            title: 'Mental Health Awareness Campaign',
            description: 'Community-wide campaign to promote mental health awareness among youth.',
            category: 'Health',
            status: 'planning',
            budget: 40000,
            expenses: 8000,
            date: '2024-04-15',
            participants: 0,
            createdBy: 'SUPER_ADMIN',
            isPublic: true,
            showBudget: false,
            showDescription: true,
            showStatus: true
        },
        {
            id: 5,
            title: 'Tree Planting Activity',
            description: 'Environmental initiative to plant 500 trees around the barangay.',
            category: 'Environment',
            status: 'ongoing',
            budget: 35000,
            expenses: 15000,
            date: '2024-03-20',
            participants: 80,
            createdBy: 'Maria Santos',
            isPublic: true,
            showBudget: true,
            showDescription: true,
            showStatus: true
        }
    ],
    
    // Events data
    events: [
        {
            id: 1,
            title: 'Youth Leadership Summit',
            description: 'Annual summit bringing together young leaders from different barangays.',
            category: 'Education',
            date: '2024-04-15',
            location: 'Barangay Hall',
            attendees: 150,
            status: 'upcoming'
        },
        {
            id: 2,
            title: 'Earth Day Celebration',
            description: 'Community event celebrating Earth Day with various environmental activities.',
            category: 'Environment',
            date: '2024-04-22',
            location: 'Community Park',
            attendees: 200,
            status: 'upcoming'
        },
        {
            id: 3,
            title: 'Sports Festival',
            description: 'Multi-sport festival featuring basketball, volleyball, and other games.',
            category: 'Sports',
            date: '2024-05-01',
            location: 'Sports Complex',
            attendees: 300,
            status: 'upcoming'
        }
    ],
    
    // Youth demographics data
    youthData: {
        totalYouth: 1950,
        byAge: {
            '15-18': 580,
            '19-22': 650,
            '23-26': 420,
            '27-30': 300
        },
        byGender: {
            male: 1014,
            female: 936
        },
        byEducation: {
            elementary: 293,
            highschool: 878,
            college: 488,
            graduate: 234,
            postgrad: 57
        },
        byStatus: {
            student: 1430,
            working: 380,
            unemployed: 140
        }
    },
    
    // Audit logs
    auditLogs: [
        {
            id: 1,
            user: 'SUPER_ADMIN',
            action: 'Create',
            details: 'Created new project: Youth Basketball Tournament',
            timestamp: new Date('2024-03-15T10:30:00'),
            severity: 'info',
            status: 'success'
        },
        {
            id: 2,
            user: 'Maria Santos',
            action: 'Update',
            details: 'Updated budget for Computer Literacy Training',
            timestamp: new Date('2024-03-14T14:15:00'),
            severity: 'info',
            status: 'success'
        },
        {
            id: 3,
            user: 'Juan dela Cruz',
            action: 'Upload',
            details: 'Uploaded meeting minutes document',
            timestamp: new Date('2024-03-13T16:45:00'),
            severity: 'info',
            status: 'success'
        },
        {
            id: 4,
            user: 'SUPER_ADMIN',
            action: 'Delete',
            details: 'Deleted outdated project proposal',
            timestamp: new Date('2024-03-12T09:20:00'),
            severity: 'warning',
            status: 'success'
        },
        {
            id: 5,
            user: 'Maria Santos',
            action: 'Login',
            details: 'User logged into the system',
            timestamp: new Date('2024-03-11T08:00:00'),
            severity: 'info',
            status: 'success'
        }
    ],
    
    // System statistics
    systemStats: {
        totalUsers: 132,
        activeCommunities: 7,
        totalCourses: 2,
        reportIssues: 6,
        pendingIssues: 4,
        userActivityRate: 100,
        reportResolutionRate: 33,
        avgCommunitySize: 26,
        totalPlatformMembers: 183
    },
    
    // Initialize data
    init() {
        this.loadFromStorage();
        console.log('AppData initialized');
    },
    
    // Save to localStorage
    saveToStorage() {
        const dataToSave = {
            projects: this.projects,
            events: this.events,
            youthData: this.youthData,
            auditLogs: this.auditLogs,
            systemStats: this.systemStats,
            isLoggedIn: this.isLoggedIn,
            currentUser: this.currentUser
        };
        localStorage.setItem('skSystemData', JSON.stringify(dataToSave));
    },
    
    // Load from localStorage
    loadFromStorage() {
        const savedData = localStorage.getItem('skSystemData');
        if (savedData) {
            try {
                const parsed = JSON.parse(savedData);
                Object.assign(this, parsed);
                
                // Convert date strings back to Date objects
                this.auditLogs.forEach(log => {
                    log.timestamp = new Date(log.timestamp);
                });
            } catch (error) {
                console.error('Error loading data from storage:', error);
            }
        }
    },
    
    // Authentication
    login(username, password) {
        const user = this.users.find(u => u.username === username && u.password === password);
        if (user) {
            this.isLoggedIn = true;
            this.currentUser = user;
            
            // Add login audit log
            this.addAuditLog(user.fullName, 'Login', 'User logged into the system');
            
            this.saveToStorage();
            return true;
        }
        return false;
    },
    
    logout() {
        if (this.currentUser) {
            this.addAuditLog(this.currentUser.fullName, 'Logout', 'User logged out of the system');
        }
        this.isLoggedIn = false;
        this.currentUser = null;
        this.saveToStorage();
    },
    
    // Data getters
    getPublicProjects() {
        return this.projects.filter(project => project.isPublic);
    },
    
    getTotalBudget() {
        return this.projects.reduce((total, project) => total + project.budget, 0);
    },
    
    getTotalExpenses() {
        return this.projects.reduce((total, project) => total + project.expenses, 0);
    },
    
    getTotalYouth() {
        return this.youthData.totalYouth;
    },
    
    getActiveUsers() {
        return this.users.filter(user => user.isActive);
    },
    
    // CRUD operations
    addProject(project) {
        const newProject = {
            ...project,
            id: Math.max(...this.projects.map(p => p.id)) + 1,
            createdBy: this.currentUser ? this.currentUser.fullName : 'System'
        };
        this.projects.push(newProject);
        
        if (this.currentUser) {
            this.addAuditLog(this.currentUser.fullName, 'Create', `Created new project: ${project.title}`);
        }
        
        this.saveToStorage();
        return newProject;
    },
    
    updateProject(id, updates) {
        const projectIndex = this.projects.findIndex(p => p.id === id);
        if (projectIndex !== -1) {
            this.projects[projectIndex] = { ...this.projects[projectIndex], ...updates };
            
            if (this.currentUser) {
                this.addAuditLog(this.currentUser.fullName, 'Update', `Updated project: ${this.projects[projectIndex].title}`);
            }
            
            this.saveToStorage();
            return this.projects[projectIndex];
        }
        return null;
    },
    
    deleteProject(id) {
        const projectIndex = this.projects.findIndex(p => p.id === id);
        if (projectIndex !== -1) {
            const project = this.projects[projectIndex];
            this.projects.splice(projectIndex, 1);
            
            if (this.currentUser) {
                this.addAuditLog(this.currentUser.fullName, 'Delete', `Deleted project: ${project.title}`);
            }
            
            this.saveToStorage();
            return true;
        }
        return false;
    },
    
    addEvent(event) {
        const newEvent = {
            ...event,
            id: Math.max(...this.events.map(e => e.id)) + 1
        };
        this.events.push(newEvent);
        
        if (this.currentUser) {
            this.addAuditLog(this.currentUser.fullName, 'Create', `Created new event: ${event.title}`);
        }
        
        this.saveToStorage();
        return newEvent;
    },
    
    // Audit log helper
    addAuditLog(user, action, details, severity = 'info') {
        const newLog = {
            id: Math.max(...this.auditLogs.map(l => l.id), 0) + 1,
            user,
            action,
            details,
            timestamp: new Date(),
            severity,
            status: 'success'
        };
        this.auditLogs.unshift(newLog);
        
        // Keep only last 100 logs
        if (this.auditLogs.length > 100) {
            this.auditLogs = this.auditLogs.slice(0, 100);
        }
        
        this.saveToStorage();
    }
};

// Initialize data when script loads
if (typeof window !== 'undefined') {
    AppData.init();
}