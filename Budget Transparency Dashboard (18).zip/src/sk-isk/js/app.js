// Main Application Logic
class SKApp {
    constructor() {
        this.currentView = 'home';
        this.currentAdminView = 'dashboard';
        this.isLoggedIn = false;
        this.isPublicView = true;
        
        this.init();
    }

    init() {
        // Initialize data
        AppData.init();
        
        // Load saved state
        this.loadState();
        
        // Initialize icons
        this.initLucideIcons();
        
        // Setup event listeners
        this.setupEventListeners();
        
        // Render initial view
        this.renderCurrentView();
        
        // Update statistics
        this.updateStatistics();
        
        console.log('SK System initialized successfully');
    }

    initLucideIcons() {
        // Initialize Lucide icons
        if (typeof lucide !== 'undefined') {
            lucide.createIcons();
        }
    }

    setupEventListeners() {
        // Public navigation
        document.querySelectorAll('[data-view]').forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const view = e.currentTarget.getAttribute('data-view');
                this.navigateToPublicView(view);
            });
        });

        // Admin navigation
        document.querySelectorAll('[data-admin-view]').forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const view = e.currentTarget.getAttribute('data-admin-view');
                this.navigateToAdminView(view);
            });
        });

        // Login modal
        const adminLoginBtn = Utils.$('#adminLoginBtn');
        const loginModal = Utils.$('#loginModal');
        const loginForm = Utils.$('#loginForm');
        
        if (adminLoginBtn) {
            adminLoginBtn.addEventListener('click', () => {
                Utils.openModal('#loginModal');
            });
        }

        if (loginModal) {
            loginModal.addEventListener('click', (e) => {
                if (e.target === loginModal) {
                    Utils.closeModal('#loginModal');
                }
            });
        }

        if (loginForm) {
            loginForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.handleLogin();
            });
        }

        // Logout
        const logoutBtn = Utils.$('#logoutBtn');
        if (logoutBtn) {
            logoutBtn.addEventListener('click', () => {
                this.handleLogout();
            });
        }

        // Contact form
        const contactForm = Utils.$('#contactForm');
        if (contactForm) {
            contactForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.handleContactForm();
            });
        }

        // Add project button
        const addProjectBtn = Utils.$('#addProjectBtn');
        if (addProjectBtn) {
            addProjectBtn.addEventListener('click', () => {
                this.showAddProjectModal();
            });
        }

        // ESC key to close modals
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                const openModal = Utils.$('.modal:not(.hidden)');
                if (openModal) {
                    openModal.classList.add('hidden');
                    document.body.style.overflow = '';
                }
            }
        });

        // Auto-save on data changes
        window.addEventListener('beforeunload', () => {
            this.saveState();
        });
    }

    navigateToPublicView(view) {
        this.currentView = view;
        this.isPublicView = true;
        
        // Update navigation active states
        document.querySelectorAll('.nav-link').forEach(link => {
            link.classList.remove('active');
        });
        
        const activeLink = Utils.$(`[data-view="${view}"]`);
        if (activeLink) {
            activeLink.classList.add('active');
        }

        // Show/hide views
        document.querySelectorAll('.public-view').forEach(viewEl => {
            viewEl.classList.remove('active');
        });
        
        const targetView = Utils.$(`#${view}View`);
        if (targetView) {
            targetView.classList.add('active');
        }

        // Render view content
        this.renderPublicView(view);
        
        // Update URL without reload
        history.pushState({ view, type: 'public' }, '', `#${view}`);
        
        this.saveState();
    }

    navigateToAdminView(view) {
        if (!this.isLoggedIn) return;
        
        this.currentAdminView = view;
        
        // Update navigation active states
        document.querySelectorAll('.nav-item').forEach(link => {
            link.classList.remove('active');
        });
        
        const activeLink = Utils.$(`[data-admin-view="${view}"]`);
        if (activeLink) {
            activeLink.classList.add('active');
        }

        // Show/hide admin views
        document.querySelectorAll('.admin-view').forEach(viewEl => {
            viewEl.classList.remove('active');
        });
        
        const targetView = Utils.$(`#${view}View`);
        if (targetView) {
            targetView.classList.add('active');
        }

        // Render admin view content
        this.renderAdminView(view);
        
        // Update URL
        history.pushState({ view, type: 'admin' }, '', `#admin-${view}`);
        
        this.saveState();
    }

    renderCurrentView() {
        if (this.isPublicView) {
            Utils.$('#publicView').classList.add('active');
            Utils.$('#adminView').classList.remove('active');
            this.renderPublicView(this.currentView);
        } else {
            Utils.$('#publicView').classList.remove('active');
            Utils.$('#adminView').classList.add('active');
            this.renderAdminView(this.currentAdminView);
        }
    }

    renderPublicView(view) {
        switch (view) {
            case 'home':
                this.renderHomeView();
                break;
            case 'public-projects':
                this.renderPublicProjectsView();
                break;
            case 'events':
                this.renderEventsView();
                break;
            case 'youth-summary':
                this.renderYouthSummaryView();
                break;
            case 'about':
            case 'contact':
                // These are static views, no special rendering needed
                break;
        }
        
        // Re-initialize icons after content change
        this.initLucideIcons();
    }

    renderAdminView(view) {
        switch (view) {
            case 'dashboard':
                this.renderDashboardView();
                break;
            case 'projects':
                this.renderProjectsView();
                break;
            case 'budget':
                this.renderBudgetView();
                break;
            case 'documents':
                this.renderDocumentsView();
                break;
            case 'youth':
                this.renderYouthView();
                break;
            case 'transparency':
                this.renderTransparencyView();
                break;
            case 'user-accounts':
                this.renderUserAccountsView();
                break;
            case 'audit':
                this.renderAuditView();
                break;
            case 'reports':
                this.renderReportsView();
                break;
        }
        
        // Re-initialize icons and charts
        this.initLucideIcons();
        setTimeout(() => {
            ChartManager.updateCharts();
        }, 100);
    }

    renderHomeView() {
        this.updateStatistics();
    }

    renderPublicProjectsView() {
        const container = Utils.$('#publicProjectsList');
        if (!container) return;

        const publicProjects = AppData.getPublicProjects();
        
        container.innerHTML = '';
        
        publicProjects.forEach(project => {
            const projectCard = Utils.createElement('div', 'project-card');
            
            projectCard.innerHTML = `
                <div class="project-header">
                    <div>
                        <h3 class="project-title">${project.title}</h3>
                        ${project.showStatus ? `<span class="badge ${Utils.getStatusColor(project.status)}">${Utils.capitalizeFirst(project.status)}</span>` : ''}
                    </div>
                </div>
                ${project.showDescription ? `<p>${project.description}</p>` : ''}
                <div class="project-meta">
                    <div class="meta-item">
                        <div class="meta-label">Category</div>
                        <div class="meta-value">${project.category}</div>
                    </div>
                    <div class="meta-item">
                        <div class="meta-label">Date Started</div>
                        <div class="meta-value">${Utils.formatDate(project.date)}</div>
                    </div>
                    ${project.showBudget ? `
                        <div class="meta-item">
                            <div class="meta-label">Budget</div>
                            <div class="meta-value">${Utils.formatCurrency(project.budget)}</div>
                        </div>
                    ` : ''}
                    <div class="meta-item">
                        <div class="meta-label">Participants</div>
                        <div class="meta-value">${project.participants || 'N/A'}</div>
                    </div>
                </div>
            `;
            
            container.appendChild(projectCard);
        });
        
        if (publicProjects.length === 0) {
            container.innerHTML = '<div class="empty-state"><p>No public projects available.</p></div>';
        }
    }

    renderEventsView() {
        const container = Utils.$('#eventsList');
        if (!container) return;

        container.innerHTML = '';
        
        AppData.events.forEach(event => {
            const eventCard = Utils.createElement('div', 'event-card');
            
            eventCard.innerHTML = `
                <div class="mb-4">
                    <span class="badge ${Utils.getCategoryColor(event.category)}">${event.category}</span>
                    <h3 class="mt-2 mb-2">${event.title}</h3>
                    <p>${event.description}</p>
                </div>
                <div class="space-y-2">
                    <div class="flex items-center gap-2">
                        <i data-lucide="calendar" class="w-4 h-4"></i>
                        <span>${Utils.formatDate(event.date)}</span>
                    </div>
                    <div class="flex items-center gap-2">
                        <i data-lucide="map-pin" class="w-4 h-4"></i>
                        <span>${event.location}</span>
                    </div>
                </div>
            `;
            
            container.appendChild(eventCard);
        });
    }

    renderYouthSummaryView() {
        const container = Utils.$('#youthBreakdown');
        if (!container) return;

        container.innerHTML = '';
        
        const colors = ['#2563eb', '#16a34a', '#f59e0b', '#dc2626', '#7c3aed'];
        
        AppData.youthProfiles.forEach((profile, index) => {
            const item = Utils.createElement('div', 'youth-item');
            
            item.innerHTML = `
                <div class="youth-type">
                    <div class="youth-color" style="background-color: ${colors[index % colors.length]}"></div>
                    <span>${profile.type}</span>
                </div>
                <div class="youth-stats">
                    <div class="youth-count">${Utils.formatNumber(profile.count)}</div>
                    <div class="youth-percentage">${profile.percentage}%</div>
                </div>
            `;
            
            container.appendChild(item);
        });

        // Initialize youth chart
        setTimeout(() => {
            ChartManager.initYouthChart();
        }, 100);
    }

    renderDashboardView() {
        this.updateStatistics();
        this.renderRecentActivity();
    }

    renderProjectsView() {
        const container = Utils.$('#projectsList');
        if (!container) return;

        container.innerHTML = `
            <div class="data-table">
                <div class="data-table-header">
                    <h3 class="data-table-title">Projects</h3>
                </div>
                <table class="table">
                    <thead>
                        <tr>
                            <th>Project</th>
                            <th>Category</th>
                            <th>Status</th>
                            <th>Budget</th>
                            <th>Expenses</th>
                            <th>Progress</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${AppData.projects.map(project => `
                            <tr>
                                <td>
                                    <div>
                                        <div class="font-medium">${project.title}</div>
                                        <div class="text-sm text-gray-600">${project.category}</div>
                                    </div>
                                </td>
                                <td><span class="badge">${project.category}</span></td>
                                <td><span class="badge ${Utils.getStatusColor(project.status)}">${Utils.capitalizeFirst(project.status)}</span></td>
                                <td>${Utils.formatCurrency(project.budget)}</td>
                                <td>${Utils.formatCurrency(project.expenses)}</td>
                                <td>
                                    <div class="progress-bar">
                                        <div class="progress-fill ${Utils.getProgressColor(Utils.calculateProgress(project.expenses, project.budget))}" 
                                             style="width: ${Utils.calculateProgress(project.expenses, project.budget)}%"></div>
                                    </div>
                                    <small>${Utils.calculateProgress(project.expenses, project.budget)}%</small>
                                </td>
                                <td>
                                    <div class="action-buttons">
                                        <button class="action-button" onclick="app.editProject(${project.id})">
                                            <i data-lucide="edit" class="w-4 h-4"></i>
                                        </button>
                                        <button class="action-button" onclick="app.viewProject(${project.id})">
                                            <i data-lucide="eye" class="w-4 h-4"></i>
                                        </button>
                                        <button class="action-button danger" onclick="app.deleteProject(${project.id})">
                                            <i data-lucide="trash-2" class="w-4 h-4"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            </div>
        `;
    }

    renderRecentActivity() {
        const container = Utils.$('#recentActivity');
        if (!container) return;

        const recentLogs = AppData.auditLogs.slice(0, 5);
        
        container.innerHTML = '';
        
        recentLogs.forEach(log => {
            const item = Utils.createElement('div', 'activity-item');
            
            item.innerHTML = `
                <div class="activity-icon">
                    <i data-lucide="${Utils.getStatusIcon(log.action.toLowerCase())}" class="w-4 h-4"></i>
                </div>
                <div class="activity-content">
                    <h4>${log.details}</h4>
                    <p>${log.user} • ${Utils.formatDateTime(log.timestamp)}</p>
                </div>
            `;
            
            container.appendChild(item);
        });
    }

    updateStatistics() {
        // Update public stats
        const projectCountEl = Utils.$('#projectCount');
        const eventCountEl = Utils.$('#eventCount');
        const youthCountEl = Utils.$('#youthCount');
        const totalBudgetEl = Utils.$('#totalBudget');

        if (projectCountEl) projectCountEl.textContent = AppData.getPublicProjects().length;
        if (eventCountEl) eventCountEl.textContent = AppData.events.length;
        if (youthCountEl) youthCountEl.textContent = Utils.formatNumber(AppData.getTotalYouth());
        if (totalBudgetEl) totalBudgetEl.textContent = Utils.formatCurrency(AppData.getTotalBudget());

        // Update admin stats
        const adminProjectCountEl = Utils.$('#adminProjectCount');
        const adminTotalBudgetEl = Utils.$('#adminTotalBudget');
        const adminTotalExpensesEl = Utils.$('#adminTotalExpenses');
        const adminActiveUsersEl = Utils.$('#adminActiveUsers');

        if (adminProjectCountEl) adminProjectCountEl.textContent = AppData.projects.length;
        if (adminTotalBudgetEl) adminTotalBudgetEl.textContent = Utils.formatCurrency(AppData.getTotalBudget());
        if (adminTotalExpensesEl) adminTotalExpensesEl.textContent = Utils.formatCurrency(AppData.getTotalExpenses());
        if (adminActiveUsersEl) adminActiveUsersEl.textContent = AppData.getActiveUsers().length;
    }

    handleLogin() {
        const username = Utils.$('#username').value;
        const password = Utils.$('#password').value;

        if (AppData.login(username, password)) {
            this.isLoggedIn = true;
            this.isPublicView = false;
            this.currentAdminView = 'dashboard';
            
            Utils.closeModal('#loginModal');
            Utils.showNotification('Login successful!', 'success');
            
            this.renderCurrentView();
            this.updateStatistics();
            
            // Clear form
            Utils.resetForm(Utils.$('#loginForm'));
        } else {
            Utils.showNotification('Invalid username or password', 'error');
        }
    }

    handleLogout() {
        AppData.logout();
        this.isLoggedIn = false;
        this.isPublicView = true;
        this.currentView = 'home';
        
        Utils.showNotification('Logged out successfully', 'info');
        this.renderCurrentView();
    }

    handleContactForm() {
        const formData = Utils.serializeForm(Utils.$('#contactForm'));
        
        // Simulate form submission
        Utils.showNotification('Message sent successfully!', 'success');
        Utils.resetForm(Utils.$('#contactForm'));
        
        // Add to audit log
        AppData.addAuditLog({
            action: 'Contact',
            module: 'Public',
            resource: 'Contact Form',
            details: `Contact form submitted: ${formData.subject}`,
            severity: 'low',
            status: 'success'
        });
    }

    // Project management methods
    editProject(id) {
        const project = AppData.projects.find(p => p.id === id);
        if (project) {
            Utils.showNotification(`Edit project: ${project.title}`, 'info');
            // TODO: Implement edit modal
        }
    }

    viewProject(id) {
        const project = AppData.projects.find(p => p.id === id);
        if (project) {
            Utils.showNotification(`View project: ${project.title}`, 'info');
            // TODO: Implement view modal
        }
    }

    deleteProject(id) {
        if (confirm('Are you sure you want to delete this project?')) {
            const project = AppData.deleteProject(id);
            if (project) {
                Utils.showNotification('Project deleted successfully', 'success');
                this.renderProjectsView();
                this.updateStatistics();
                
                AppData.addAuditLog({
                    action: 'Delete',
                    module: 'Projects',
                    resource: project.title,
                    resourceId: id,
                    details: `Deleted project: ${project.title}`,
                    severity: 'medium',
                    status: 'success'
                });
            }
        }
    }

    showAddProjectModal() {
        Utils.showNotification('Add project modal would open here', 'info');
        // TODO: Implement add project modal
    }

    // State management
    saveState() {
        const state = {
            currentView: this.currentView,
            currentAdminView: this.currentAdminView,
            isLoggedIn: this.isLoggedIn,
            isPublicView: this.isPublicView
        };
        Utils.storage.set('skAppState', state);
    }

    loadState() {
        const state = Utils.storage.get('skAppState');
        if (state) {
            this.currentView = state.currentView || 'home';
            this.currentAdminView = state.currentAdminView || 'dashboard';
            this.isLoggedIn = state.isLoggedIn || false;
            this.isPublicView = state.isPublicView !== undefined ? state.isPublicView : true;
        }
    }

    // Placeholder methods for other admin views
    renderBudgetView() {
        Utils.showNotification('Budget view would render here', 'info');
    }

    renderDocumentsView() {
        Utils.showNotification('Documents view would render here', 'info');
    }

    renderYouthView() {
        Utils.showNotification('Youth view would render here', 'info');
    }

    renderTransparencyView() {
        Utils.showNotification('Transparency view would render here', 'info');
    }

    renderUserAccountsView() {
        Utils.showNotification('User accounts view would render here', 'info');
    }

    renderAuditView() {
        Utils.showNotification('Audit view would render here', 'info');
    }

    renderReportsView() {
        Utils.showNotification('Reports view would render here', 'info');
    }
}

// Initialize the application
let app;

document.addEventListener('DOMContentLoaded', function() {
    console.log('Initializing SK Budget Transparency System...');
    app = new SKApp();
});

// Handle browser navigation
window.addEventListener('popstate', function(event) {
    if (event.state) {
        if (event.state.type === 'public') {
            app.navigateToPublicView(event.state.view);
        } else if (event.state.type === 'admin') {
            app.navigateToAdminView(event.state.view);
        }
    }
});

// Handle page visibility changes
document.addEventListener('visibilitychange', function() {
    if (document.hidden) {
        app.saveState();
    }
});