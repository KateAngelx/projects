// Projects Page JavaScript
let currentProjects = [];
let filteredProjects = [];
let currentPage = 1;
const projectsPerPage = 6;

document.addEventListener('DOMContentLoaded', function() {
    // Initialize data
    AppData.init();
    
    // Initialize icons
    if (typeof lucide !== 'undefined') {
        lucide.createIcons();
    }
    
    // Load projects
    loadProjects();
    
    // Setup event listeners
    setupEventListeners();
    
    console.log('Projects page initialized');
});

function setupEventListeners() {
    // Search input
    const searchInput = Utils.$('#searchInput');
    if (searchInput) {
        searchInput.addEventListener('input', Utils.debounce(handleSearch, 300));
    }
    
    // Filters
    const categoryFilter = Utils.$('#categoryFilter');
    const statusFilter = Utils.$('#statusFilter');
    
    if (categoryFilter) {
        categoryFilter.addEventListener('change', handleFilter);
    }
    
    if (statusFilter) {
        statusFilter.addEventListener('change', handleFilter);
    }
    
    // Clear filters button
    const clearFiltersBtn = Utils.$('#clearFilters');
    if (clearFiltersBtn) {
        clearFiltersBtn.addEventListener('click', clearFilters);
    }
    
    // Reset filters button
    const resetFiltersBtn = Utils.$('#resetFilters');
    if (resetFiltersBtn) {
        resetFiltersBtn.addEventListener('click', clearFilters);
    }
    
    // Load more button
    const loadMoreBtn = Utils.$('#loadMoreBtn');
    if (loadMoreBtn) {
        loadMoreBtn.addEventListener('click', loadMoreProjects);
    }
}

function loadProjects() {
    currentProjects = AppData.getPublicProjects();
    filteredProjects = [...currentProjects];
    currentPage = 1;
    
    renderProjects();
    updateLoadMoreButton();
    toggleEmptyState();
}

function handleSearch(event) {
    const searchTerm = event.target.value.trim();
    applyFilters(searchTerm);
}

function handleFilter() {
    const searchTerm = Utils.$('#searchInput').value.trim();
    applyFilters(searchTerm);
}

function applyFilters(searchTerm = '') {
    let filtered = [...currentProjects];
    
    // Apply search filter
    if (searchTerm) {
        filtered = Utils.searchItems(filtered, searchTerm, ['title', 'description', 'category']);
    }
    
    // Apply category filter
    const categoryFilter = Utils.$('#categoryFilter').value;
    if (categoryFilter !== 'all') {
        filtered = filtered.filter(project => project.category === categoryFilter);
    }
    
    // Apply status filter
    const statusFilter = Utils.$('#statusFilter').value;
    if (statusFilter !== 'all') {
        filtered = filtered.filter(project => project.status === statusFilter);
    }
    
    filteredProjects = filtered;
    currentPage = 1;
    
    renderProjects();
    updateLoadMoreButton();
    toggleEmptyState();
}

function clearFilters() {
    Utils.$('#searchInput').value = '';
    Utils.$('#categoryFilter').value = 'all';
    Utils.$('#statusFilter').value = 'all';
    
    filteredProjects = [...currentProjects];
    currentPage = 1;
    
    renderProjects();
    updateLoadMoreButton();
    toggleEmptyState();
}

function renderProjects() {
    const container = Utils.$('#projectsList');
    if (!container) return;
    
    const startIndex = 0;
    const endIndex = currentPage * projectsPerPage;
    const projectsToShow = filteredProjects.slice(startIndex, endIndex);
    
    container.innerHTML = '';
    
    projectsToShow.forEach((project, index) => {
        const projectCard = createProjectCard(project, index);
        container.appendChild(projectCard);
    });
    
    // Re-initialize icons
    lucide.createIcons();
}

function createProjectCard(project, index) {
    const card = Utils.createElement('div', 'card project-card');
    
    card.innerHTML = `
        <div class="card-body">
            <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 1rem;">
                <div style="display: flex; align-items: center; gap: 0.75rem;">
                    <div style="width: 2.5rem; height: 2.5rem; background-color: var(--${getCategoryColor(project.category)}); border-radius: 0.5rem; display: flex; align-items: center; justify-content: center; color: var(--white);">
                        <i data-lucide="${getCategoryIcon(project.category)}" style="width: 1.25rem; height: 1.25rem;"></i>
                    </div>
                    <span class="badge badge-${Utils.getCategoryColor(project.category)}">${project.category}</span>
                </div>
                ${project.showStatus ? `<span class="badge badge-${Utils.getStatusColor(project.status)}">${Utils.capitalizeFirst(project.status)}</span>` : ''}
            </div>
            
            <h3 style="margin-bottom: 0.75rem; font-size: 1.125rem;">${project.title}</h3>
            
            ${project.showDescription ? `<p style="color: var(--gray-600); margin-bottom: 1.5rem; font-size: 0.875rem; line-height: 1.5;">${Utils.truncateText(project.description, 120)}</p>` : ''}
            
            <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 1rem; margin-bottom: 1.5rem; font-size: 0.875rem;">
                ${project.showBudget ? `
                    <div>
                        <div style="color: var(--gray-500); margin-bottom: 0.25rem;">Budget</div>
                        <div style="font-weight: 600; color: var(--gray-900);">${Utils.formatCurrency(project.budget)}</div>
                    </div>
                ` : ''}
                <div>
                    <div style="color: var(--gray-500); margin-bottom: 0.25rem;">Participants</div>
                    <div style="font-weight: 600; color: var(--gray-900);">${project.participants || 0}</div>
                </div>
                <div>
                    <div style="color: var(--gray-500); margin-bottom: 0.25rem;">Date Started</div>
                    <div style="font-weight: 600; color: var(--gray-900);">${Utils.formatDate(project.date)}</div>
                </div>
                <div>
                    <div style="color: var(--gray-500); margin-bottom: 0.25rem;">Created By</div>
                    <div style="font-weight: 600; color: var(--gray-900);">${project.createdBy}</div>
                </div>
            </div>
            
            ${project.showBudget ? `
                <div style="margin-bottom: 1.5rem;">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.5rem;">
                        <span style="font-size: 0.875rem; color: var(--gray-600);">Budget Utilization</span>
                        <span style="font-size: 0.875rem; font-weight: 600; color: var(--gray-900);">${Utils.calculateProgress(project.expenses, project.budget)}%</span>
                    </div>
                    <div class="progress-bar">
                        <div class="progress-fill ${Utils.getProgressColor(Utils.calculateProgress(project.expenses, project.budget))}" 
                             style="width: ${Utils.calculateProgress(project.expenses, project.budget)}%;"></div>
                    </div>
                    <div style="display: flex; justify-content: space-between; margin-top: 0.5rem; font-size: 0.75rem; color: var(--gray-500);">
                        <span>Spent: ${Utils.formatCurrency(project.expenses)}</span>
                        <span>Remaining: ${Utils.formatCurrency(project.budget - project.expenses)}</span>
                    </div>
                </div>
            ` : ''}
            
            <div style="display: flex; gap: 0.75rem;">
                <button class="btn btn-outline btn-sm" onclick="viewProjectDetails(${project.id})" style="flex: 1;">
                    <i data-lucide="eye"></i>
                    View Details
                </button>
                <button class="btn btn-primary btn-sm" onclick="shareProject(${project.id})">
                    <i data-lucide="share-2"></i>
                    Share
                </button>
            </div>
        </div>
    `;
    
    // Add animation
    card.style.opacity = '0';
    card.style.transform = 'translateY(20px)';
    
    setTimeout(() => {
        card.style.transition = 'all 0.5s ease';
        card.style.opacity = '1';
        card.style.transform = 'translateY(0)';
    }, index * 100);
    
    return card;
}

function loadMoreProjects() {
    currentPage++;
    renderProjects();
    updateLoadMoreButton();
}

function updateLoadMoreButton() {
    const loadMoreBtn = Utils.$('#loadMoreBtn');
    if (!loadMoreBtn) return;
    
    const totalShown = currentPage * projectsPerPage;
    const hasMore = totalShown < filteredProjects.length;
    
    if (hasMore) {
        loadMoreBtn.classList.remove('hidden');
        loadMoreBtn.innerHTML = `Load More (${filteredProjects.length - totalShown} remaining)`;
    } else {
        loadMoreBtn.classList.add('hidden');
    }
}

function toggleEmptyState() {
    const emptyState = Utils.$('#emptyState');
    const projectsList = Utils.$('#projectsList');
    
    if (!emptyState || !projectsList) return;
    
    if (filteredProjects.length === 0) {
        emptyState.classList.remove('hidden');
        projectsList.style.display = 'none';
    } else {
        emptyState.classList.add('hidden');
        projectsList.style.display = 'grid';
    }
}

function getCategoryIcon(category) {
    const categoryIcons = {
        'Sports': 'trophy',
        'Education': 'graduation-cap',
        'Livelihood': 'briefcase',
        'Health': 'heart',
        'Environment': 'leaf'
    };
    return categoryIcons[category] || 'folder';
}

function getCategoryColor(category) {
    const categoryColors = {
        'Sports': 'primary-blue',
        'Education': 'green-500',
        'Livelihood': 'yellow-500',
        'Health': 'red-500',
        'Environment': 'purple-500'
    };
    return categoryColors[category] || 'gray-500';
}

// Global functions for button clicks
function viewProjectDetails(projectId) {
    const project = AppData.projects.find(p => p.id === projectId);
    if (!project) return;
    
    // Create and show modal
    const modal = Utils.createElement('div', 'modal');
    modal.innerHTML = `
        <div class="modal-content" style="max-width: 600px;">
            <div class="modal-header">
                <h3 class="modal-title">${project.title}</h3>
                <button class="modal-close" onclick="closeProjectModal()">
                    <i data-lucide="x"></i>
                </button>
            </div>
            <div class="modal-body">
                <div style="display: flex; gap: 1rem; margin-bottom: 1.5rem;">
                    <span class="badge badge-${Utils.getCategoryColor(project.category)}">${project.category}</span>
                    ${project.showStatus ? `<span class="badge badge-${Utils.getStatusColor(project.status)}">${Utils.capitalizeFirst(project.status)}</span>` : ''}
                </div>
                
                ${project.showDescription ? `
                    <div style="margin-bottom: 1.5rem;">
                        <h4 style="margin-bottom: 0.5rem;">Description</h4>
                        <p style="color: var(--gray-600); line-height: 1.6;">${project.description}</p>
                    </div>
                ` : ''}
                
                <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 1rem; margin-bottom: 1.5rem;">
                    ${project.showBudget ? `
                        <div>
                            <h4 style="margin-bottom: 0.5rem;">Budget</h4>
                            <p style="font-size: 1.25rem; font-weight: 600; color: var(--primary-blue);">${Utils.formatCurrency(project.budget)}</p>
                        </div>
                    ` : ''}
                    <div>
                        <h4 style="margin-bottom: 0.5rem;">Participants</h4>
                        <p style="font-size: 1.25rem; font-weight: 600; color: var(--green-500);">${project.participants || 0}</p>
                    </div>
                    <div>
                        <h4 style="margin-bottom: 0.5rem;">Date Started</h4>
                        <p style="font-weight: 600;">${Utils.formatDate(project.date)}</p>
                    </div>
                    <div>
                        <h4 style="margin-bottom: 0.5rem;">Created By</h4>
                        <p style="font-weight: 600;">${project.createdBy}</p>
                    </div>
                </div>
                
                ${project.showBudget ? `
                    <div>
                        <h4 style="margin-bottom: 1rem;">Budget Utilization</h4>
                        <div style="display: flex; justify-content: space-between; margin-bottom: 0.5rem;">
                            <span>Progress: ${Utils.calculateProgress(project.expenses, project.budget)}%</span>
                            <span>${Utils.formatCurrency(project.expenses)} / ${Utils.formatCurrency(project.budget)}</span>
                        </div>
                        <div class="progress-bar">
                            <div class="progress-fill ${Utils.getProgressColor(Utils.calculateProgress(project.expenses, project.budget))}" 
                                 style="width: ${Utils.calculateProgress(project.expenses, project.budget)}%;"></div>
                        </div>
                    </div>
                ` : ''}
            </div>
            <div class="modal-footer">
                <button class="btn btn-outline" onclick="closeProjectModal()">Close</button>
                <button class="btn btn-primary" onclick="shareProject(${projectId}); closeProjectModal();">
                    <i data-lucide="share-2"></i>
                    Share Project
                </button>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    lucide.createIcons();
    
    // Show modal with animation
    setTimeout(() => {
        modal.classList.add('active');
    }, 10);
}

function closeProjectModal() {
    const modal = Utils.$('.modal');
    if (modal) {
        modal.classList.remove('active');
        setTimeout(() => {
            modal.remove();
        }, 300);
    }
}

function shareProject(projectId) {
    const project = AppData.projects.find(p => p.id === projectId);
    if (!project) return;
    
    if (navigator.share) {
        navigator.share({
            title: `SK Project: ${project.title}`,
            text: `Check out this SK project: ${project.title} - ${project.description}`,
            url: window.location.href
        });
    } else {
        const shareText = `Check out this SK project: ${project.title} - ${project.description}`;
        navigator.clipboard.writeText(shareText).then(() => {
            Utils.showNotification('Project details copied to clipboard!', 'success');
        });
    }
}