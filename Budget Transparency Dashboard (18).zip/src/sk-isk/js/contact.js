// Contact Page JavaScript
document.addEventListener('DOMContentLoaded', function() {
    // Initialize data
    AppData.init();
    
    // Initialize icons
    if (typeof lucide !== 'undefined') {
        lucide.createIcons();
    }
    
    // Setup event listeners
    setupEventListeners();
    
    console.log('Contact page initialized');
});

function setupEventListeners() {
    // Contact form
    const contactForm = Utils.$('#contactForm');
    if (contactForm) {
        contactForm.addEventListener('submit', handleContactSubmission);
    }
}

function handleContactSubmission(event) {
    event.preventDefault();
    
    const formData = Utils.getFormData('#contactForm');
    
    // Validate form
    const validation = Utils.validateForm('#contactForm', {
        name: {
            required: true,
            requiredMessage: 'Full name is required'
        },
        email: {
            required: true,
            email: true,
            emailMessage: 'Please enter a valid email address'
        },
        category: {
            required: true,
            requiredMessage: 'Please select a category'
        },
        subject: {
            required: true,
            requiredMessage: 'Subject is required'
        },
        message: {
            required: true,
            minLength: 10,
            requiredMessage: 'Message is required',
            minLengthMessage: 'Message must be at least 10 characters long'
        },
        consent: {
            required: true,
            requiredMessage: 'You must agree to the privacy policy'
        }
    });
    
    if (!validation.isValid) {
        return;
    }
    
    // Show loading
    Utils.showLoading('Sending your message...');
    
    // Simulate API call
    setTimeout(() => {
        Utils.hideLoading();
        Utils.showNotification('Thank you for your message! We will get back to you within 24 hours.', 'success');
        
        // Reset form
        Utils.resetForm('#contactForm');
        
        // Add to audit log if admin is logged in
        if (AppData.currentUser) {
            AppData.addAuditLog(
                AppData.currentUser.fullName,
                'Create',
                `New contact message: ${formData.subject} from ${formData.name}`
            );
        }
        
        // Store contact submission
        storeContactSubmission(formData);
    }, 2000);
}

function storeContactSubmission(formData) {
    // Get existing submissions or initialize empty array
    const submissions = Utils.loadFromStorage('contactSubmissions', []);
    
    // Add new submission
    const newSubmission = {
        id: Date.now(),
        ...formData,
        timestamp: new Date().toISOString(),
        status: 'new'
    };
    
    submissions.unshift(newSubmission);
    
    // Keep only last 100 submissions
    if (submissions.length > 100) {
        submissions.splice(100);
    }
    
    // Save back to storage
    Utils.saveToStorage('contactSubmissions', submissions);
}

// Global modal functions
function openSMSModal() {
    const modal = Utils.createElement('div', 'modal');
    modal.id = 'smsModal';
    modal.innerHTML = `
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title">SMS Updates Subscription</h3>
                <button class="modal-close" onclick="closeSMSModal()">
                    <i data-lucide="x"></i>
                </button>
            </div>
            <div class="modal-body">
                <p style="margin-bottom: 1.5rem;">Stay updated with SK news, events, and announcements via SMS.</p>
                <form id="smsSubscriptionForm">
                    <div class="form-group">
                        <label for="smsName" class="form-label">Full Name</label>
                        <input type="text" id="smsName" name="name" class="form-input" required>
                    </div>
                    <div class="form-group">
                        <label for="smsPhone" class="form-label">Mobile Number</label>
                        <input type="tel" id="smsPhone" name="phone" class="form-input" placeholder="+63 9XX XXX XXXX" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Subscription Preferences</label>
                        <div class="checkbox-group">
                            <label class="checkbox-label">
                                <input type="checkbox" name="sms-prefs" value="events">
                                <span>Event Announcements</span>
                            </label>
                            <label class="checkbox-label">
                                <input type="checkbox" name="sms-prefs" value="projects">
                                <span>Project Updates</span>
                            </label>
                            <label class="checkbox-label">
                                <input type="checkbox" name="sms-prefs" value="meetings">
                                <span>Meeting Schedules</span>
                            </label>
                            <label class="checkbox-label">
                                <input type="checkbox" name="sms-prefs" value="emergency">
                                <span>Emergency Alerts</span>
                            </label>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary btn-full">Subscribe</button>
                </form>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    lucide.createIcons();
    
    // Setup form handler
    const form = modal.querySelector('#smsSubscriptionForm');
    form.addEventListener('submit', handleSMSSubscription);
    
    // Show modal
    setTimeout(() => {
        modal.classList.add('active');
    }, 10);
    
    // Focus first input
    setTimeout(() => {
        modal.querySelector('#smsName').focus();
    }, 300);
}

function closeSMSModal() {
    const modal = Utils.$('#smsModal');
    if (modal) {
        modal.classList.remove('active');
        setTimeout(() => {
            modal.remove();
        }, 300);
    }
}

function handleSMSSubscription(event) {
    event.preventDefault();
    
    const formData = Utils.getFormData('#smsSubscriptionForm');
    
    // Get selected preferences
    const preferences = Array.from(document.querySelectorAll('input[name="sms-prefs"]:checked'))
        .map(checkbox => checkbox.value);
    
    Utils.showLoading('Subscribing...');
    
    setTimeout(() => {
        Utils.hideLoading();
        Utils.showNotification('Successfully subscribed to SMS updates!', 'success');
        closeSMSModal();
        
        // Store subscription
        const subscriptions = Utils.loadFromStorage('smsSubscriptions', []);
        subscriptions.push({
            id: Date.now(),
            ...formData,
            preferences,
            timestamp: new Date().toISOString()
        });
        Utils.saveToStorage('smsSubscriptions', subscriptions);
    }, 1500);
}

function openAppointmentModal() {
    const modal = Utils.createElement('div', 'modal');
    modal.id = 'appointmentModal';
    modal.innerHTML = `
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title">Schedule Meeting</h3>
                <button class="modal-close" onclick="closeAppointmentModal()">
                    <i data-lucide="x"></i>
                </button>
            </div>
            <div class="modal-body">
                <p style="margin-bottom: 1.5rem;">Book an appointment with SK officials.</p>
                <form id="appointmentForm">
                    <div class="form-row">
                        <div class="form-group">
                            <label for="appointmentName" class="form-label">Full Name</label>
                            <input type="text" id="appointmentName" name="name" class="form-input" required>
                        </div>
                        <div class="form-group">
                            <label for="appointmentEmail" class="form-label">Email</label>
                            <input type="email" id="appointmentEmail" name="email" class="form-input" required>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="appointmentDate" class="form-label">Preferred Date</label>
                            <input type="date" id="appointmentDate" name="date" class="form-input" required>
                        </div>
                        <div class="form-group">
                            <label for="appointmentTime" class="form-label">Preferred Time</label>
                            <select id="appointmentTime" name="time" class="form-select" required>
                                <option value="">Select time</option>
                                <option value="09:00">9:00 AM</option>
                                <option value="10:00">10:00 AM</option>
                                <option value="11:00">11:00 AM</option>
                                <option value="14:00">2:00 PM</option>
                                <option value="15:00">3:00 PM</option>
                                <option value="16:00">4:00 PM</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="appointmentPurpose" class="form-label">Purpose of Meeting</label>
                        <textarea id="appointmentPurpose" name="purpose" rows="3" class="form-textarea" required></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary btn-full">Book Appointment</button>
                </form>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    lucide.createIcons();
    
    // Set minimum date to today
    const dateInput = modal.querySelector('#appointmentDate');
    const today = new Date().toISOString().split('T')[0];
    dateInput.setAttribute('min', today);
    
    // Setup form handler
    const form = modal.querySelector('#appointmentForm');
    form.addEventListener('submit', handleAppointmentBooking);
    
    // Show modal
    setTimeout(() => {
        modal.classList.add('active');
    }, 10);
    
    // Focus first input
    setTimeout(() => {
        modal.querySelector('#appointmentName').focus();
    }, 300);
}

function closeAppointmentModal() {
    const modal = Utils.$('#appointmentModal');
    if (modal) {
        modal.classList.remove('active');
        setTimeout(() => {
            modal.remove();
        }, 300);
    }
}

function handleAppointmentBooking(event) {
    event.preventDefault();
    
    const formData = Utils.getFormData('#appointmentForm');
    
    Utils.showLoading('Booking appointment...');
    
    setTimeout(() => {
        Utils.hideLoading();
        Utils.showNotification('Appointment request submitted! We will confirm your booking via email.', 'success');
        closeAppointmentModal();
        
        // Store appointment
        const appointments = Utils.loadFromStorage('appointments', []);
        appointments.push({
            id: Date.now(),
            ...formData,
            status: 'pending',
            timestamp: new Date().toISOString()
        });
        Utils.saveToStorage('appointments', appointments);
    }, 1500);
}

function openFAQModal() {
    const modal = Utils.createElement('div', 'modal');
    modal.id = 'faqModal';
    modal.innerHTML = `
        <div class="modal-content" style="max-width: 700px;">
            <div class="modal-header">
                <h3 class="modal-title">Frequently Asked Questions</h3>
                <button class="modal-close" onclick="closeFAQModal()">
                    <i data-lucide="x"></i>
                </button>
            </div>
            <div class="modal-body">
                <div class="faq-list">
                    ${generateFAQItems()}
                </div>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    lucide.createIcons();
    
    // Setup FAQ toggle handlers
    modal.querySelectorAll('.faq-question').forEach(question => {
        question.addEventListener('click', toggleFAQ);
    });
    
    // Show modal
    setTimeout(() => {
        modal.classList.add('active');
    }, 10);
}

function closeFAQModal() {
    const modal = Utils.$('#faqModal');
    if (modal) {
        modal.classList.remove('active');
        setTimeout(() => {
            modal.remove();
        }, 300);
    }
}

function generateFAQItems() {
    const faqs = [
        {
            question: 'How can I participate in SK programs?',
            answer: 'Youth aged 15-30 can participate in SK programs by registering at our office or through our online registration form. Bring a valid ID and proof of residence.'
        },
        {
            question: 'How is the SK budget allocated?',
            answer: 'Our budget is allocated across five main areas: Education (30%), Sports & Recreation (25%), Livelihood (20%), Health & Wellness (15%), and Environment (10%).'
        },
        {
            question: 'Can I propose a project to the SK?',
            answer: 'Yes! We encourage youth to submit project proposals. You can submit them through our contact form or present them during our monthly public consultations.'
        },
        {
            question: 'How can I access SK documents?',
            answer: 'Public documents are available through our transparency portal. For other documents, submit a formal request through our office during business hours.'
        },
        {
            question: 'How do I register for SK events?',
            answer: 'You can register for events through our events page, by visiting our office, or by filling out the registration form on our contact page.'
        },
        {
            question: 'What are the requirements for SK membership?',
            answer: 'To be eligible for SK membership, you must be between 15-30 years old, a registered voter or barangay resident, and actively participate in youth activities.'
        }
    ];
    
    return faqs.map(faq => `
        <div class="faq-item">
            <div class="faq-question" style="display: flex; justify-content: space-between; align-items: center; padding: 1rem; background-color: var(--gray-50); border-radius: var(--radius-lg); cursor: pointer; margin-bottom: 0.5rem;">
                <h4 style="margin: 0;">${faq.question}</h4>
                <i data-lucide="chevron-down" style="width: 1rem; height: 1rem; transition: transform 0.2s;"></i>
            </div>
            <div class="faq-answer" style="display: none; padding: 1rem; color: var(--gray-600); line-height: 1.6;">
                <p>${faq.answer}</p>
            </div>
        </div>
    `).join('');
}

function toggleFAQ(event) {
    const question = event.currentTarget;
    const answer = question.nextElementSibling;
    const chevron = question.querySelector('[data-lucide="chevron-down"]');
    
    if (answer.style.display === 'none' || answer.style.display === '') {
        answer.style.display = 'block';
        chevron.style.transform = 'rotate(180deg)';
        question.style.backgroundColor = 'var(--secondary-blue)';
    } else {
        answer.style.display = 'none';
        chevron.style.transform = 'rotate(0deg)';
        question.style.backgroundColor = 'var(--gray-50)';
    }
}