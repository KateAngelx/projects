// Document Management JavaScript
let currentDocuments = [];
let selectedDocuments = new Set();
let currentView = 'list';

document.addEventListener('DOMContentLoaded', function() {
    // Initialize data
    AppData.init();
    
    // Check authentication
    checkAuthentication();
    
    // Initialize icons
    if (typeof lucide !== 'undefined') {
        lucide.createIcons();
    }
    
    // Setup event listeners
    setupEventListeners();
    
    // Load document management data
    loadDocumentManagement();
    
    console.log('Document Management initialized');
});

function checkAuthentication() {
    if (!AppData.isLoggedIn || !AppData.currentUser) {
        Utils.showNotification('Please login to access the admin panel', 'warning');
        setTimeout(() => {
            window.location.href = 'login.html';
        }, 2000);
        return;
    }
    
    updateUserInfo();
}

function updateUserInfo() {
    const userNameEl = Utils.$('#currentUserName');
    const userRoleEl = Utils.$('#currentUserRole');
    
    if (userNameEl && AppData.currentUser) {
        userNameEl.textContent = AppData.currentUser.fullName;
    }
    
    if (userRoleEl && AppData.currentUser) {
        userRoleEl.textContent = AppData.currentUser.position;
    }
}

function setupEventListeners() {
    // Logout button
    const logoutBtn = Utils.$('#logoutBtn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', handleLogout);
    }
    
    // Search and filters
    const searchInput = Utils.$('#documentSearchInput');
    const typeFilter = Utils.$('#typeFilterSelect');
    const visibilityFilter = Utils.$('#visibilityFilterSelect');
    const dateFilter = Utils.$('#dateFilterSelect');
    const clearFilters = Utils.$('#clearDocumentFilters');
    
    if (searchInput) {
        searchInput.addEventListener('input', Utils.debounce(filterDocuments, 300));
    }
    
    if (typeFilter) {
        typeFilter.addEventListener('change', filterDocuments);
    }
    
    if (visibilityFilter) {
        visibilityFilter.addEventListener('change', filterDocuments);
    }
    
    if (dateFilter) {
        dateFilter.addEventListener('change', filterDocuments);
    }
    
    if (clearFilters) {
        clearFilters.addEventListener('click', clearDocumentFilters);
    }
    
    // Upload form
    const uploadForm = Utils.$('#uploadForm');
    if (uploadForm) {
        uploadForm.addEventListener('submit', handleDocumentUpload);
    }
    
    // File input
    const fileInput = Utils.$('#documentFiles');
    if (fileInput) {
        fileInput.addEventListener('change', handleFileSelection);
    }
    
    // File drop zone
    const dropZone = Utils.$('#fileDropZone');
    if (dropZone) {
        dropZone.addEventListener('dragover', handleDragOver);
        dropZone.addEventListener('drop', handleFileDrop);
        dropZone.addEventListener('click', () => fileInput.click());
    }
}

function loadDocumentManagement() {
    // Generate mock document data
    generateMockDocuments();
    
    // Update document statistics
    updateDocumentStats();
    
    // Load documents
    loadDocuments();
    
    // Populate project filter
    populateProjectFilter();
}

function generateMockDocuments() {
    const documentTypes = ['resolution', 'minutes', 'report', 'policy', 'financial', 'legal', 'correspondence', 'other'];
    const documentNames = [
        'SK Resolution No. 001-2024',
        'Monthly Meeting Minutes - March 2024',
        'Youth Development Report Q1 2024',
        'Anti-Bullying Policy Implementation',
        'Budget Allocation Report FY 2024',
        'Sports Equipment Purchase Agreement',
        'Letter to Barangay Council',
        'Training Certificate Template',
        'SK Code of Conduct Guidelines',
        'Community Service Hours Log',
        'Project Proposal Template',
        'Financial Assistance Guidelines'
    ];
    
    currentDocuments = [];
    
    documentNames.forEach((name, index) => {
        const doc = {
            id: index + 1,
            name: name,
            type: documentTypes[Math.floor(Math.random() * documentTypes.length)],
            size: Math.floor(Math.random() * 5000000) + 100000, // Random size between 100KB and 5MB
            format: getFileFormat(name),
            visibility: Math.random() > 0.3 ? 'public' : 'private',
            dateAdded: getRandomDate(),
            addedBy: AppData.currentUser.fullName,
            description: getDocumentDescription(name),
            tags: getDocumentTags(name),
            projectId: Math.random() > 0.5 ? AppData.projects[Math.floor(Math.random() * AppData.projects.length)].id : null,
            downloadCount: Math.floor(Math.random() * 100),
            lastModified: getRandomDate()
        };
        
        currentDocuments.push(doc);
    });
    
    // Sort by date added (newest first)
    currentDocuments.sort((a, b) => new Date(b.dateAdded) - new Date(a.dateAdded));
}

function getFileFormat(name) {
    if (name.includes('Minutes') || name.includes('Report')) return 'pdf';
    if (name.includes('Template') || name.includes('Agreement')) return 'docx';
    if (name.includes('Log') || name.includes('Hours')) return 'xlsx';
    return 'pdf';
}

function getDocumentDescription(name) {
    const descriptions = {
        'SK Resolution': 'Official resolution passed by the Sangguniang Kabataan',
        'Meeting Minutes': 'Detailed minutes from the monthly SK meeting',
        'Report': 'Comprehensive report on various SK activities and programs',
        'Policy': 'Official policy document for SK governance',
        'Budget': 'Financial documents related to SK budget and expenses',
        'Agreement': 'Legal agreement or contract document',
        'Letter': 'Official correspondence and communications',
        'Template': 'Standard template for SK documentation',
        'Guidelines': 'Guidelines and procedures for SK operations',
        'Log': 'Record keeping and tracking document'
    };
    
    for (const [key, desc] of Object.entries(descriptions)) {
        if (name.includes(key)) return desc;
    }
    
    return 'SK administrative document';
}

function getDocumentTags(name) {
    const tagMap = {
        'Resolution': ['resolution', 'official', 'governance'],
        'Minutes': ['meeting', 'minutes', 'proceedings'],
        'Report': ['report', 'analysis', 'data'],
        'Policy': ['policy', 'rules', 'guidelines'],
        'Budget': ['budget', 'financial', 'expenses'],
        'Agreement': ['legal', 'contract', 'agreement'],
        'Letter': ['correspondence', 'communication'],
        'Template': ['template', 'form'],
        'Guidelines': ['guidelines', 'procedures'],
        'Log': ['log', 'record', 'tracking']
    };
    
    for (const [key, tags] of Object.entries(tagMap)) {
        if (name.includes(key)) return tags.join(', ');
    }
    
    return 'document, sk, administration';
}

function getRandomDate() {
    const start = new Date();
    start.setMonth(start.getMonth() - 6);
    const end = new Date();
    
    return new Date(start.getTime() + Math.random() * (end.getTime() - start.getTime()))
        .toISOString().split('T')[0];
}

function updateDocumentStats() {
    const totalDocs = currentDocuments.length;
    const publicDocs = currentDocuments.filter(d => d.visibility === 'public').length;
    const privateDocs = totalDocs - publicDocs;
    const resolutions = currentDocuments.filter(d => d.type === 'resolution').length;
    const minutes = currentDocuments.filter(d => d.type === 'minutes').length;
    const totalSize = currentDocuments.reduce((sum, d) => sum + d.size, 0);
    
    // Update stat cards with animation
    animateStatNumber('#totalDocuments', totalDocs);
    animateStatNumber('#resolutionsCount', resolutions);
    animateStatNumber('#minutesCount', minutes);
    
    setTimeout(() => {
        const documentsBreakdown = Utils.$('#documentsBreakdown');
        const resolutionsYear = Utils.$('#resolutionsYear');
        const minutesMonth = Utils.$('#minutesMonth');
        const storageUsed = Utils.$('#storageUsed');
        
        if (documentsBreakdown) {
            documentsBreakdown.textContent = `${publicDocs} public, ${privateDocs} private`;
        }
        
        if (resolutionsYear) {
            resolutionsYear.textContent = 'This year';
        }
        
        if (minutesMonth) {
            const thisMonthMinutes = currentDocuments.filter(d => 
                d.type === 'minutes' && 
                new Date(d.dateAdded).getMonth() === new Date().getMonth()
            ).length;
            minutesMonth.textContent = `This month: ${thisMonthMinutes}`;
        }
        
        if (storageUsed) {
            storageUsed.textContent = Utils.formatFileSize(totalSize);
        }
    }, 1000);
}

function loadDocuments() {
    if (currentView === 'list') {
        loadDocumentsList();
    } else {
        loadDocumentsGrid();
    }
}

function loadDocumentsList() {
    const tbody = Utils.$('#documentsTableBody');
    if (!tbody) return;
    
    tbody.innerHTML = '';
    
    if (currentDocuments.length === 0) {
        showEmptyState();
        return;
    }
    
    hideEmptyState();
    
    currentDocuments.forEach(document => {
        const row = createDocumentTableRow(document);
        tbody.appendChild(row);
    });
    
    lucide.createIcons();
}

function createDocumentTableRow(document) {
    const row = Utils.createElement('tr');
    
    row.innerHTML = `
        <td>
            <input type="checkbox" class="document-checkbox" value="${document.id}" onchange="updateSelectedDocuments()">
        </td>
        <td>
            <div style="display: flex; align-items: center; gap: 1rem;">
                <div style="width: 2.5rem; height: 2.5rem; background-color: var(--primary-blue); border-radius: 0.5rem; display: flex; align-items: center; justify-content: center; color: var(--white); flex-shrink: 0;">
                    <i data-lucide="${getDocumentIcon(document.format)}" style="width: 1.25rem; height: 1.25rem;"></i>
                </div>
                <div>
                    <h4 style="margin-bottom: 0.25rem; font-size: 0.875rem;">${document.name}</h4>
                    <p style="font-size: 0.75rem; color: var(--gray-500); margin-bottom: 0.25rem;">${Utils.truncateText(document.description, 50)}</p>
                    <div style="font-size: 0.75rem; color: var(--gray-500);">
                        ${document.tags ? `Tags: ${document.tags}` : 'No tags'}
                    </div>
                </div>
            </div>
        </td>
        <td>
            <span class="badge badge-info">${Utils.capitalizeFirst(document.type)}</span>
        </td>
        <td style="font-size: 0.875rem;">${Utils.formatFileSize(document.size)}</td>
        <td>
            <div style="display: flex; align-items: center; gap: 0.5rem;">
                <div style="width: 8px; height: 8px; border-radius: 50%; background-color: ${document.visibility === 'public' ? 'var(--green-500)' : 'var(--gray-400)'};"></div>
                <span style="font-size: 0.875rem;">${Utils.capitalizeFirst(document.visibility)}</span>
            </div>
        </td>
        <td style="font-size: 0.875rem;">${Utils.formatDate(document.dateAdded)}</td>
        <td style="font-size: 0.875rem;">${document.addedBy}</td>
        <td>
            <div style="display: flex; gap: 0.25rem;">
                <button class="btn btn-outline btn-sm" onclick="viewDocument(${document.id})" title="View">
                    <i data-lucide="eye" style="width: 0.875rem; height: 0.875rem;"></i>
                </button>
                <button class="btn btn-outline btn-sm" onclick="downloadDocument(${document.id})" title="Download">
                    <i data-lucide="download" style="width: 0.875rem; height: 0.875rem;"></i>
                </button>
                <button class="btn btn-outline btn-sm" onclick="editDocument(${document.id})" title="Edit">
                    <i data-lucide="edit" style="width: 0.875rem; height: 0.875rem;"></i>
                </button>
                <button class="btn btn-outline btn-sm" onclick="deleteDocument(${document.id})" title="Delete" style="color: var(--red-500); border-color: var(--red-500);">
                    <i data-lucide="trash-2" style="width: 0.875rem; height: 0.875rem;"></i>
                </button>
            </div>
        </td>
    `;
    
    return row;
}

function loadDocumentsGrid() {
    const grid = Utils.$('#documentsGrid');
    if (!grid) return;
    
    grid.innerHTML = '';
    
    if (currentDocuments.length === 0) {
        showEmptyState();
        return;
    }
    
    hideEmptyState();
    
    currentDocuments.forEach((document, index) => {
        const card = createDocumentCard(document, index);
        grid.appendChild(card);
    });
    
    lucide.createIcons();
}

function createDocumentCard(document, index) {
    const card = Utils.createElement('div', 'card document-card');
    
    card.innerHTML = `
        <div class="card-body">
            <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 1rem;">
                <input type="checkbox" class="document-checkbox" value="${document.id}" onchange="updateSelectedDocuments()">
                <div style="display: flex; align-items: center; gap: 0.5rem;">
                    <div style="width: 8px; height: 8px; border-radius: 50%; background-color: ${document.visibility === 'public' ? 'var(--green-500)' : 'var(--gray-400)'};"></div>
                    <span style="font-size: 0.75rem; color: var(--gray-500);">${Utils.capitalizeFirst(document.visibility)}</span>
                </div>
            </div>
            
            <div style="text-align: center; margin-bottom: 1rem;">
                <div style="width: 4rem; height: 4rem; background-color: var(--primary-blue); border-radius: var(--radius-lg); display: flex; align-items: center; justify-content: center; color: var(--white); margin: 0 auto 1rem;">
                    <i data-lucide="${getDocumentIcon(document.format)}" style="width: 2rem; height: 2rem;"></i>
                </div>
                <h4 style="margin-bottom: 0.5rem; font-size: 0.875rem;">${document.name}</h4>
                <span class="badge badge-info">${Utils.capitalizeFirst(document.type)}</span>
            </div>
            
            <div style="font-size: 0.75rem; color: var(--gray-500); margin-bottom: 1rem; line-height: 1.4;">
                ${Utils.truncateText(document.description, 80)}
            </div>
            
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem; font-size: 0.75rem; color: var(--gray-500);">
                <span>${Utils.formatDate(document.dateAdded)}</span>
                <span>${Utils.formatFileSize(document.size)}</span>
            </div>
            
            <div style="display: flex; gap: 0.5rem;">
                <button class="btn btn-outline btn-sm" onclick="viewDocument(${document.id})" style="flex: 1;">
                    <i data-lucide="eye"></i>
                    View
                </button>
                <button class="btn btn-outline btn-sm" onclick="downloadDocument(${document.id})">
                    <i data-lucide="download"></i>
                </button>
                <button class="btn btn-outline btn-sm" onclick="editDocument(${document.id})">
                    <i data-lucide="edit"></i>
                </button>
            </div>
        </div>
    `;
    
    // Add animation
    card.style.opacity = '0';
    card.style.transform = 'translateY(20px)';
    
    setTimeout(() => {
        card.style.transition = 'all 0.3s ease';
        card.style.opacity = '1';
        card.style.transform = 'translateY(0)';
    }, index * 50);
    
    return card;
}

function getDocumentIcon(format) {
    const icons = {
        'pdf': 'file-text',
        'doc': 'file-text',
        'docx': 'file-text',
        'xls': 'file-spreadsheet',
        'xlsx': 'file-spreadsheet',
        'jpg': 'image',
        'jpeg': 'image',
        'png': 'image',
        'default': 'file'
    };
    
    return icons[format] || icons['default'];
}

function toggleView(view) {
    currentView = view;
    
    const listView = Utils.$('#documentsListView');
    const gridView = Utils.$('#documentsGridView');
    const listBtn = Utils.$('#listViewBtn');
    const gridBtn = Utils.$('#gridViewBtn');
    
    if (view === 'list') {
        listView.classList.remove('hidden');
        gridView.classList.add('hidden');
        listBtn.classList.add('btn-primary');
        listBtn.classList.remove('btn-outline');
        gridBtn.classList.add('btn-outline');
        gridBtn.classList.remove('btn-primary');
        loadDocumentsList();
    } else {
        listView.classList.add('hidden');
        gridView.classList.remove('hidden');
        gridBtn.classList.add('btn-primary');
        gridBtn.classList.remove('btn-outline');
        listBtn.classList.add('btn-outline');
        listBtn.classList.remove('btn-primary');
        loadDocumentsGrid();
    }
}

function filterDocuments() {
    const searchTerm = Utils.$('#documentSearchInput').value.toLowerCase();
    const typeFilter = Utils.$('#typeFilterSelect').value;
    const visibilityFilter = Utils.$('#visibilityFilterSelect').value;
    const dateFilter = Utils.$('#dateFilterSelect').value;
    
    let filteredDocuments = currentDocuments;
    
    // Apply search filter
    if (searchTerm) {
        filteredDocuments = filteredDocuments.filter(doc =>
            doc.name.toLowerCase().includes(searchTerm) ||
            doc.description.toLowerCase().includes(searchTerm) ||
            doc.tags.toLowerCase().includes(searchTerm)
        );
    }
    
    // Apply type filter
    if (typeFilter !== 'all') {
        filteredDocuments = filteredDocuments.filter(doc => doc.type === typeFilter);
    }
    
    // Apply visibility filter
    if (visibilityFilter !== 'all') {
        filteredDocuments = filteredDocuments.filter(doc => doc.visibility === visibilityFilter);
    }
    
    // Apply date filter
    if (dateFilter !== 'all') {
        const now = new Date();
        const filterDate = new Date();
        
        switch (dateFilter) {
            case 'today':
                filterDate.setDate(now.getDate());
                break;
            case 'week':
                filterDate.setDate(now.getDate() - 7);
                break;
            case 'month':
                filterDate.setMonth(now.getMonth() - 1);
                break;
            case 'year':
                filterDate.setFullYear(now.getFullYear() - 1);
                break;
        }
        
        filteredDocuments = filteredDocuments.filter(doc =>
            new Date(doc.dateAdded) >= filterDate
        );
    }
    
    // Update the document list/grid with filtered results
    const originalDocuments = currentDocuments;
    currentDocuments = filteredDocuments;
    loadDocuments();
    currentDocuments = originalDocuments;
}

function clearDocumentFilters() {
    Utils.$('#documentSearchInput').value = '';
    Utils.$('#typeFilterSelect').value = 'all';
    Utils.$('#visibilityFilterSelect').value = 'all';
    Utils.$('#dateFilterSelect').value = 'all';
    
    loadDocuments();
}

function populateProjectFilter() {
    const associatedProjectSelect = Utils.$('#associatedProject');
    if (!associatedProjectSelect) return;
    
    associatedProjectSelect.innerHTML = '<option value="">No associated project</option>';
    
    AppData.projects.forEach(project => {
        const option = Utils.createElement('option', '', project.title);
        option.value = project.id;
        associatedProjectSelect.appendChild(option);
    });
}

// Modal Functions
function openUploadModal() {
    const modal = Utils.$('#uploadModal');
    const form = Utils.$('#uploadForm');
    
    if (form) form.reset();
    
    // Clear file list
    const filesList = Utils.$('#selectedFilesList');
    if (filesList) filesList.innerHTML = '';
    
    Utils.openModal('#uploadModal');
    
    lucide.createIcons();
}

function closeUploadModal() {
    Utils.closeModal('#uploadModal');
}

function handleFileSelection(event) {
    const files = Array.from(event.target.files);
    displaySelectedFiles(files);
}

function handleDragOver(event) {
    event.preventDefault();
    event.currentTarget.style.backgroundColor = 'var(--secondary-blue)';
    event.currentTarget.style.borderColor = 'var(--primary-blue)';
}

function handleFileDrop(event) {
    event.preventDefault();
    event.currentTarget.style.backgroundColor = '';
    event.currentTarget.style.borderColor = '';
    
    const files = Array.from(event.dataTransfer.files);
    displaySelectedFiles(files);
    
    // Update file input
    const fileInput = Utils.$('#documentFiles');
    if (fileInput) {
        fileInput.files = event.dataTransfer.files;
    }
}

function displaySelectedFiles(files) {
    const container = Utils.$('#selectedFilesList');
    if (!container) return;
    
    container.innerHTML = '';
    
    files.forEach((file, index) => {
        const fileItem = Utils.createElement('div');
        fileItem.style.cssText = `
            display: flex;
            align-items: center;
            gap: 1rem;
            padding: 0.75rem;
            background-color: var(--gray-50);
            border-radius: var(--radius-lg);
            margin-bottom: 0.5rem;
        `;
        
        fileItem.innerHTML = `
            <div style="width: 2rem; height: 2rem; background-color: var(--primary-blue); border-radius: 0.25rem; display: flex; align-items: center; justify-content: center; color: var(--white); flex-shrink: 0;">
                <i data-lucide="${getDocumentIcon(file.name.split('.').pop())}" style="width: 1rem; height: 1rem;"></i>
            </div>
            <div style="flex: 1;">
                <div style="font-weight: 600; font-size: 0.875rem;">${file.name}</div>
                <div style="font-size: 0.75rem; color: var(--gray-500);">${Utils.formatFileSize(file.size)}</div>
            </div>
            <button type="button" onclick="removeSelectedFile(${index})" style="background: none; border: none; color: var(--gray-400); cursor: pointer;">
                <i data-lucide="x" style="width: 1rem; height: 1rem;"></i>
            </button>
        `;
        
        container.appendChild(fileItem);
    });
    
    lucide.createIcons();
}

function removeSelectedFile(index) {
    // This would require more complex file handling in a real implementation
    Utils.showNotification('File removed from selection', 'info');
}

function handleDocumentUpload(event) {
    event.preventDefault();
    
    const formData = Utils.getFormData('#uploadForm');
    const files = Utils.$('#documentFiles').files;
    
    if (files.length === 0) {
        Utils.showNotification('Please select files to upload', 'warning');
        return;
    }
    
    // Validate form
    const validation = Utils.validateForm('#uploadForm', {
        type: { required: true },
        description: { required: false }
    });
    
    if (!validation.isValid) {
        return;
    }
    
    Utils.showLoading('Uploading documents...');
    
    setTimeout(() => {
        // Simulate file upload
        Array.from(files).forEach((file, index) => {
            const newDocument = {
                id: currentDocuments.length + index + 1,
                name: file.name,
                type: formData.type,
                size: file.size,
                format: file.name.split('.').pop(),
                visibility: formData.visibility,
                dateAdded: formData.date || new Date().toISOString().split('T')[0],
                addedBy: AppData.currentUser.fullName,
                description: formData.description || getDocumentDescription(file.name),
                tags: formData.tags || getDocumentTags(file.name),
                projectId: formData.project ? parseInt(formData.project) : null,
                downloadCount: 0,
                lastModified: new Date().toISOString().split('T')[0]
            };
            
            currentDocuments.unshift(newDocument);
        });
        
        // Add audit log
        AppData.addAuditLog(
            AppData.currentUser.fullName,
            'Create',
            `Uploaded ${files.length} document(s)`
        );
        
        // Refresh data
        updateDocumentStats();
        loadDocuments();
        closeUploadModal();
        
        Utils.hideLoading();
        Utils.showNotification(`${files.length} document(s) uploaded successfully`, 'success');
    }, 2000);
}

// Document Actions
function viewDocument(documentId) {
    const document = currentDocuments.find(d => d.id === documentId);
    if (!document) return;
    
    const modal = Utils.$('#documentDetailsModal');
    const title = Utils.$('#documentDetailsTitle');
    const body = Utils.$('#documentDetailsBody');
    
    if (title) title.textContent = document.name;
    
    if (body) {
        const associatedProject = document.projectId ? 
            AppData.projects.find(p => p.id === document.projectId) : null;
        
        body.innerHTML = `
            <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 2rem;">
                <div>
                    <div style="text-align: center; margin-bottom: 2rem;">
                        <div style="width: 5rem; height: 5rem; background-color: var(--primary-blue); border-radius: var(--radius-lg); display: flex; align-items: center; justify-content: center; color: var(--white); margin: 0 auto 1rem;">
                            <i data-lucide="${getDocumentIcon(document.format)}" style="width: 2.5rem; height: 2.5rem;"></i>
                        </div>
                        <h3 style="margin-bottom: 0.5rem;">${document.name}</h3>
                        <span class="badge badge-info">${Utils.capitalizeFirst(document.type)}</span>
                    </div>
                    
                    <div style="margin-bottom: 2rem;">
                        <h4 style="margin-bottom: 0.5rem;">Description</h4>
                        <p style="color: var(--gray-600); line-height: 1.6;">${document.description}</p>
                    </div>
                    
                    ${document.tags ? `
                        <div style="margin-bottom: 2rem;">
                            <h4 style="margin-bottom: 0.5rem;">Tags</h4>
                            <div style="display: flex; flex-wrap: wrap; gap: 0.5rem;">
                                ${document.tags.split(', ').map(tag => `<span class="badge badge-secondary">${tag.trim()}</span>`).join('')}
                            </div>
                        </div>
                    ` : ''}
                    
                    ${associatedProject ? `
                        <div>
                            <h4 style="margin-bottom: 0.5rem;">Associated Project</h4>
                            <div style="padding: 1rem; background-color: var(--gray-50); border-radius: var(--radius-lg);">
                                <h5 style="margin-bottom: 0.25rem;">${associatedProject.title}</h5>
                                <p style="font-size: 0.875rem; color: var(--gray-600);">${associatedProject.category} • ${Utils.capitalizeFirst(associatedProject.status)}</p>
                            </div>
                        </div>
                    ` : ''}
                </div>
                
                <div>
                    <div style="background-color: var(--gray-50); padding: 1.5rem; border-radius: var(--radius-lg); margin-bottom: 2rem;">
                        <h4 style="margin-bottom: 1rem;">Document Info</h4>
                        <div style="font-size: 0.875rem; line-height: 1.6;">
                            <div style="margin-bottom: 0.5rem;"><strong>File Size:</strong> ${Utils.formatFileSize(document.size)}</div>
                            <div style="margin-bottom: 0.5rem;"><strong>Format:</strong> ${document.format.toUpperCase()}</div>
                            <div style="margin-bottom: 0.5rem;"><strong>Visibility:</strong> ${Utils.capitalizeFirst(document.visibility)}</div>
                            <div style="margin-bottom: 0.5rem;"><strong>Added:</strong> ${Utils.formatDate(document.dateAdded)}</div>
                            <div style="margin-bottom: 0.5rem;"><strong>Added By:</strong> ${document.addedBy}</div>
                            <div style="margin-bottom: 0.5rem;"><strong>Downloads:</strong> ${document.downloadCount}</div>
                            <div><strong>Last Modified:</strong> ${Utils.formatDate(document.lastModified)}</div>
                        </div>
                    </div>
                    
                    <div style="display: flex; flex-direction: column; gap: 0.75rem;">
                        <button class="btn btn-primary" onclick="downloadDocument(${document.id}); closeDocumentDetailsModal();">
                            <i data-lucide="download"></i>
                            Download Document
                        </button>
                        <button class="btn btn-outline" onclick="editDocument(${document.id}); closeDocumentDetailsModal();">
                            <i data-lucide="edit"></i>
                            Edit Document
                        </button>
                        <button class="btn btn-outline" onclick="shareDocument(${document.id})">
                            <i data-lucide="share-2"></i>
                            Share Document
                        </button>
                    </div>
                </div>
            </div>
        `;
    }
    
    Utils.openModal('#documentDetailsModal');
    lucide.createIcons();
}

function closeDocumentDetailsModal() {
    Utils.closeModal('#documentDetailsModal');
}

function downloadDocument(documentId) {
    const document = currentDocuments.find(d => d.id === documentId);
    if (!document) return;
    
    // Increment download count
    document.downloadCount++;
    
    Utils.showNotification(`Downloading: ${document.name}`, 'success');
    
    // Add audit log
    AppData.addAuditLog(
        AppData.currentUser.fullName,
        'Download',
        `Downloaded document: ${document.name}`
    );
}

function editDocument(documentId) {
    Utils.showNotification('Edit document functionality would be implemented here', 'info');
}

function deleteDocument(documentId) {
    const document = currentDocuments.find(d => d.id === documentId);
    if (!document) return;
    
    const deleteNameEl = Utils.$('#deleteDocumentName');
    if (deleteNameEl) {
        deleteNameEl.textContent = document.name;
    }
    
    Utils.openModal('#deleteDocumentModal');
}

function confirmDeleteDocument() {
    const documentName = Utils.$('#deleteDocumentName').textContent;
    const documentIndex = currentDocuments.findIndex(d => d.name === documentName);
    
    if (documentIndex > -1) {
        currentDocuments.splice(documentIndex, 1);
        
        // Add audit log
        AppData.addAuditLog(
            AppData.currentUser.fullName,
            'Delete',
            `Deleted document: ${documentName}`
        );
        
        updateDocumentStats();
        loadDocuments();
        closeDeleteDocumentModal();
        
        Utils.showNotification('Document deleted successfully', 'success');
    }
}

function closeDeleteDocumentModal() {
    Utils.closeModal('#deleteDocumentModal');
}

function shareDocument(documentId) {
    const document = currentDocuments.find(d => d.id === documentId);
    if (!document) return;
    
    if (navigator.share) {
        navigator.share({
            title: document.name,
            text: `Check out this document: ${document.name}`,
            url: window.location.href
        });
    } else {
        const shareText = `Check out this document: ${document.name} - ${document.description}`;
        navigator.clipboard.writeText(shareText).then(() => {
            Utils.showNotification('Document link copied to clipboard!', 'success');
        });
    }
}

// Utility Functions
function animateStatNumber(selector, targetNumber) {
    const element = Utils.$(selector);
    if (!element) return;
    
    const duration = 1500;
    const startTime = performance.now();
    const startNumber = 0;
    
    function updateNumber(currentTime) {
        const elapsed = currentTime - startTime;
        const progress = Math.min(elapsed / duration, 1);
        
        const easedProgress = 1 - Math.pow(1 - progress, 3);
        const currentNumber = Math.floor(startNumber + (targetNumber - startNumber) * easedProgress);
        
        element.textContent = currentNumber;
        
        if (progress < 1) {
            requestAnimationFrame(updateNumber);
        }
    }
    
    requestAnimationFrame(updateNumber);
}

function showEmptyState() {
    Utils.$('#documentsEmptyState').classList.remove('hidden');
    
    const listView = Utils.$('#documentsListView');
    const gridView = Utils.$('#documentsGridView');
    
    if (listView) listView.style.display = 'none';
    if (gridView) gridView.style.display = 'none';
}

function hideEmptyState() {
    Utils.$('#documentsEmptyState').classList.add('hidden');
    
    const listView = Utils.$('#documentsListView');
    const gridView = Utils.$('#documentsGridView');
    
    if (currentView === 'list' && listView) {
        listView.style.display = 'block';
    } else if (currentView === 'grid' && gridView) {
        gridView.style.display = 'block';
    }
}

// Selection and Bulk Actions
function toggleSelectAllDocuments() {
    const selectAll = Utils.$('#selectAllDocuments');
    const checkboxes = Utils.$$('.document-checkbox');
    
    checkboxes.forEach(checkbox => {
        checkbox.checked = selectAll.checked;
    });
    
    updateSelectedDocuments();
}

function updateSelectedDocuments() {
    const checkboxes = Utils.$$('.document-checkbox:checked');
    selectedDocuments.clear();
    
    checkboxes.forEach(checkbox => {
        selectedDocuments.add(parseInt(checkbox.value));
    });
}

function bulkDocumentActions() {
    if (selectedDocuments.size === 0) {
        Utils.showNotification('Please select documents first', 'warning');
        return;
    }
    
    Utils.showNotification(`${selectedDocuments.size} documents selected`, 'info');
}

function exportDocumentList() {
    Utils.showNotification('Exporting document list...', 'info');
}

function handleLogout() {
    if (confirm('Are you sure you want to logout?')) {
        AppData.logout();
        Utils.showNotification('Logged out successfully', 'success');
        setTimeout(() => {
            window.location.href = 'index.html';
        }, 1000);
    }
}