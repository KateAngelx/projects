import React from 'react';
import { Button } from '../../../../components/ui/button';

interface PublicAboutProps {
  currentView: string;
  setCurrentView: (view: string) => void;
  setShowLoginDialog: (show: boolean) => void;
}

export default function PublicAbout({ currentView, setCurrentView, setShowLoginDialog }: PublicAboutProps) {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Navigation */}
      <nav className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-lg">SK</span>
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900">Sangguniang Kabataan</h1>
                <p className="text-sm text-gray-600">Budget Transparency Portal</p>
              </div>
            </div>
            
            <div className="hidden md:flex items-center space-x-8">
              <button onClick={() => setCurrentView('home')} className="text-sm font-medium text-gray-700 hover:text-blue-600">Home</button>
              <button onClick={() => setCurrentView('public-projects')} className="text-sm font-medium text-gray-700 hover:text-blue-600">Projects</button>
              <button onClick={() => setCurrentView('events')} className="text-sm font-medium text-gray-700 hover:text-blue-600">Events</button>
              <button onClick={() => setCurrentView('youth-summary')} className="text-sm font-medium text-gray-700 hover:text-blue-600">Youth</button>
              <button onClick={() => setCurrentView('about')} className="text-sm font-medium text-blue-600">About</button>
              <button onClick={() => setCurrentView('contact')} className="text-sm font-medium text-gray-700 hover:text-blue-600">Contact</button>
              <Button onClick={() => setShowLoginDialog(true)} size="sm" className="bg-blue-600 hover:bg-blue-700">Admin Login</Button>
            </div>
          </div>
        </div>
      </nav>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <h1 className="text-3xl font-bold text-gray-900 mb-8">About Us</h1>
        <div className="prose max-w-none">
          <p className="text-lg text-gray-600">
            The Sangguniang Kabataan (SK) is committed to transparent governance and youth empowerment through accountable budget management and community-driven development initiatives.
          </p>
        </div>
      </div>
    </div>
  );
}