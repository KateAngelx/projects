import React from 'react';
import { Calendar, MapPin, Users, Clock, ArrowRight } from 'lucide-react';
import { Button } from '../../../../components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../../../../components/ui/card';
import { Badge } from '../../../../components/ui/badge';

interface Event {
  id: number;
  title: string;
  date: string;
  time: string;
  location: string;
  description: string;
  category: string;
  capacity: number;
  registered: number;
  status: string;
}

interface PublicEventsProps {
  currentView: string;
  setCurrentView: (view: string) => void;
  setShowLoginDialog: (show: boolean) => void;
  events: Event[];
}

export default function PublicEvents({ currentView, setCurrentView, setShowLoginDialog, events }: PublicEventsProps) {
  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'Leadership': return 'bg-blue-100 text-blue-800';
      case 'Environment': return 'bg-green-100 text-green-800';
      case 'Skills Development': return 'bg-purple-100 text-purple-800';
      case 'Sports': return 'bg-orange-100 text-orange-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'upcoming': return 'bg-blue-100 text-blue-800';
      case 'completed': return 'bg-green-100 text-green-800';
      case 'cancelled': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Navigation */}
      <nav className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-lg">SK</span>
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900">Sangguniang Kabataan</h1>
                <p className="text-sm text-gray-600">Budget Transparency Portal</p>
              </div>
            </div>
            
            <div className="hidden md:flex items-center space-x-8">
              <button 
                onClick={() => setCurrentView('home')}
                className={`text-sm font-medium transition-colors ${
                  currentView === 'home' ? 'text-blue-600' : 'text-gray-700 hover:text-blue-600'
                }`}
              >
                Home
              </button>
              <button 
                onClick={() => setCurrentView('public-projects')}
                className={`text-sm font-medium transition-colors ${
                  currentView === 'public-projects' ? 'text-blue-600' : 'text-gray-700 hover:text-blue-600'
                }`}
              >
                Projects
              </button>
              <button 
                onClick={() => setCurrentView('events')}
                className={`text-sm font-medium transition-colors ${
                  currentView === 'events' ? 'text-blue-600' : 'text-gray-700 hover:text-blue-600'
                }`}
              >
                Events
              </button>
              <button 
                onClick={() => setCurrentView('youth-summary')}
                className={`text-sm font-medium transition-colors ${
                  currentView === 'youth-summary' ? 'text-blue-600' : 'text-gray-700 hover:text-blue-600'
                }`}
              >
                Youth
              </button>
              <button 
                onClick={() => setCurrentView('about')}
                className={`text-sm font-medium transition-colors ${
                  currentView === 'about' ? 'text-blue-600' : 'text-gray-700 hover:text-blue-600'
                }`}
              >
                About
              </button>
              <button 
                onClick={() => setCurrentView('contact')}
                className={`text-sm font-medium transition-colors ${
                  currentView === 'contact' ? 'text-blue-600' : 'text-gray-700 hover:text-blue-600'
                }`}
              >
                Contact
              </button>
              <Button 
                onClick={() => setShowLoginDialog(true)}
                size="sm"
                className="bg-blue-600 hover:bg-blue-700"
              >
                Admin Login
              </Button>
            </div>
          </div>
        </div>
      </nav>

      {/* Header */}
      <div className="bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="text-center">
            <h1 className="text-3xl font-bold text-gray-900 mb-4">Community Events</h1>
            <p className="text-xl text-gray-600">
              Join us in our upcoming events and community activities
            </p>
          </div>
        </div>
      </div>

      {/* Events List */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="space-y-6">
          {events.map((event) => (
            <Card key={event.id} className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <CardTitle className="text-xl mb-2">{event.title}</CardTitle>
                    <div className="flex flex-wrap gap-2">
                      <Badge className={getCategoryColor(event.category)}>
                        {event.category}
                      </Badge>
                      <Badge className={getStatusColor(event.status)}>
                        {event.status.charAt(0).toUpperCase() + event.status.slice(1)}
                      </Badge>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-sm text-gray-500">Registration</div>
                    <div className="text-lg font-semibold text-gray-900">
                      {event.registered} / {event.capacity}
                    </div>
                    <div className="w-20 bg-gray-200 rounded-full h-2 mt-1">
                      <div 
                        className="bg-blue-600 h-2 rounded-full" 
                        style={{ width: `${(event.registered / event.capacity) * 100}%` }}
                      ></div>
                    </div>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 mb-4">{event.description}</p>
                
                <div className="grid md:grid-cols-2 gap-4 mb-4">
                  <div className="flex items-center gap-2 text-gray-600">
                    <Calendar className="w-5 h-5 text-blue-600" />
                    <span>{new Date(event.date).toLocaleDateString('en-US', { 
                      weekday: 'long', 
                      year: 'numeric', 
                      month: 'long', 
                      day: 'numeric' 
                    })}</span>
                  </div>
                  <div className="flex items-center gap-2 text-gray-600">
                    <Clock className="w-5 h-5 text-blue-600" />
                    <span>{event.time}</span>
                  </div>
                  <div className="flex items-center gap-2 text-gray-600">
                    <MapPin className="w-5 h-5 text-blue-600" />
                    <span>{event.location}</span>
                  </div>
                  <div className="flex items-center gap-2 text-gray-600">
                    <Users className="w-5 h-5 text-blue-600" />
                    <span>Capacity: {event.capacity} participants</span>
                  </div>
                </div>
                
                {event.status === 'upcoming' && (
                  <div className="flex gap-2">
                    <Button className="bg-blue-600 hover:bg-blue-700">
                      Register Now
                      <ArrowRight className="w-4 h-4 ml-2" />
                    </Button>
                    <Button variant="outline">
                      Learn More
                    </Button>
                  </div>
                )}
                
                {event.status === 'completed' && (
                  <div className="flex gap-2">
                    <Button variant="outline">
                      View Summary
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12 mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8">
            <div className="col-span-2">
              <div className="flex items-center space-x-3 mb-4">
                <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
                  <span className="text-white font-bold text-lg">SK</span>
                </div>
                <div>
                  <h3 className="text-lg font-bold">Sangguniang Kabataan</h3>
                  <p className="text-gray-400 text-sm">Budget Transparency Portal</p>
                </div>
              </div>
              <p className="text-gray-400 mb-4">
                Empowering youth through transparent governance and community-driven development.
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Quick Links</h4>
              <ul className="space-y-2 text-gray-400">
                <li><button onClick={() => setCurrentView('home')} className="hover:text-white transition-colors">Home</button></li>
                <li><button onClick={() => setCurrentView('public-projects')} className="hover:text-white transition-colors">Projects</button></li>
                <li><button onClick={() => setCurrentView('youth-summary')} className="hover:text-white transition-colors">Youth Programs</button></li>
                <li><button onClick={() => setCurrentView('about')} className="hover:text-white transition-colors">About Us</button></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Contact</h4>
              <ul className="space-y-2 text-gray-400">
                <li>Barangay Hall</li>
                <li>Monday - Friday, 8AM - 5PM</li>
                <li>sk@barangay.gov.ph</li>
                <li>(02) 123-4567</li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2024 Sangguniang Kabataan. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}