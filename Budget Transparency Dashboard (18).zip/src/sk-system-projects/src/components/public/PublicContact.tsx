import React from 'react';
import { Button } from '../../../../components/ui/button';

interface PublicContactProps {
  currentView: string;
  setCurrentView: (view: string) => void;
  setShowLoginDialog: (show: boolean) => void;
}

export default function PublicContact({ currentView, setCurrentView, setShowLoginDialog }: PublicContactProps) {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Navigation */}
      <nav className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-lg">SK</span>
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900">Sangguniang Kabataan</h1>
                <p className="text-sm text-gray-600">Budget Transparency Portal</p>
              </div>
            </div>
            
            <div className="hidden md:flex items-center space-x-8">
              <button onClick={() => setCurrentView('home')} className="text-sm font-medium text-gray-700 hover:text-blue-600">Home</button>
              <button onClick={() => setCurrentView('public-projects')} className="text-sm font-medium text-gray-700 hover:text-blue-600">Projects</button>
              <button onClick={() => setCurrentView('events')} className="text-sm font-medium text-gray-700 hover:text-blue-600">Events</button>
              <button onClick={() => setCurrentView('youth-summary')} className="text-sm font-medium text-gray-700 hover:text-blue-600">Youth</button>
              <button onClick={() => setCurrentView('about')} className="text-sm font-medium text-gray-700 hover:text-blue-600">About</button>
              <button onClick={() => setCurrentView('contact')} className="text-sm font-medium text-blue-600">Contact</button>
              <Button onClick={() => setShowLoginDialog(true)} size="sm" className="bg-blue-600 hover:bg-blue-700">Admin Login</Button>
            </div>
          </div>
        </div>
      </nav>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <h1 className="text-3xl font-bold text-gray-900 mb-8">Contact Us</h1>
        <div className="grid md:grid-cols-2 gap-8">
          <div>
            <h3 className="text-lg font-semibold mb-4">Get in Touch</h3>
            <div className="space-y-3">
              <p><strong>Address:</strong> Barangay Hall, Main Street</p>
              <p><strong>Phone:</strong> (02) 123-4567</p>
              <p><strong>Email:</strong> sk@barangay.gov.ph</p>
              <p><strong>Office Hours:</strong> Monday - Friday, 8AM - 5PM</p>
            </div>
          </div>
          <div>
            <h3 className="text-lg font-semibold mb-4">Send a Message</h3>
            <p className="text-gray-600">We'd love to hear from you. Contact us for any inquiries about our projects or how to get involved.</p>
          </div>
        </div>
      </div>
    </div>
  );
}