import React from 'react';
import { Users, Target, Eye, Shield, ArrowRight, Calendar, Award, TrendingUp } from 'lucide-react';
import { Button } from '../../../../components/ui/button';
import { Card, CardContent } from '../../../../components/ui/card';
import { ImageWithFallback } from '../../../../components/figma/ImageWithFallback';

interface PublicHomeProps {
  currentView: string;
  setCurrentView: (view: string) => void;
  setShowLoginDialog: (show: boolean) => void;
}

export default function PublicHome({ currentView, setCurrentView, setShowLoginDialog }: PublicHomeProps) {
  const features = [
    {
      icon: Eye,
      title: "Full Transparency",
      description: "Complete visibility into all SK projects, budgets, and expenditures"
    },
    {
      icon: Users,
      title: "Community Engagement",
      description: "Active participation opportunities for all youth in the barangay"
    },
    {
      icon: Target,
      title: "Goal-Oriented Projects",
      description: "Strategic initiatives focused on youth development and community growth"
    },
    {
      icon: Shield,
      title: "Accountable Governance",
      description: "Responsible management of public funds with regular audits and reports"
    }
  ];

  const stats = [
    { label: "Active Projects", value: "12", icon: TrendingUp },
    { label: "Youth Beneficiaries", value: "285", icon: Users },
    { label: "Budget Allocated", value: "₱850K", icon: Target },
    { label: "Community Events", value: "24", icon: Calendar }
  ];

  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <nav className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-lg">SK</span>
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900">Sangguniang Kabataan</h1>
                <p className="text-sm text-gray-600">Budget Transparency Portal</p>
              </div>
            </div>
            
            <div className="hidden md:flex items-center space-x-8">
              <button 
                onClick={() => setCurrentView('home')}
                className={`text-sm font-medium transition-colors ${
                  currentView === 'home' ? 'text-blue-600' : 'text-gray-700 hover:text-blue-600'
                }`}
              >
                Home
              </button>
              <button 
                onClick={() => setCurrentView('public-projects')}
                className={`text-sm font-medium transition-colors ${
                  currentView === 'public-projects' ? 'text-blue-600' : 'text-gray-700 hover:text-blue-600'
                }`}
              >
                Projects
              </button>
              <button 
                onClick={() => setCurrentView('events')}
                className={`text-sm font-medium transition-colors ${
                  currentView === 'events' ? 'text-blue-600' : 'text-gray-700 hover:text-blue-600'
                }`}
              >
                Events
              </button>
              <button 
                onClick={() => setCurrentView('youth-summary')}
                className={`text-sm font-medium transition-colors ${
                  currentView === 'youth-summary' ? 'text-blue-600' : 'text-gray-700 hover:text-blue-600'
                }`}
              >
                Youth
              </button>
              <button 
                onClick={() => setCurrentView('about')}
                className={`text-sm font-medium transition-colors ${
                  currentView === 'about' ? 'text-blue-600' : 'text-gray-700 hover:text-blue-600'
                }`}
              >
                About
              </button>
              <button 
                onClick={() => setCurrentView('contact')}
                className={`text-sm font-medium transition-colors ${
                  currentView === 'contact' ? 'text-blue-600' : 'text-gray-700 hover:text-blue-600'
                }`}
              >
                Contact
              </button>
              <Button 
                onClick={() => setShowLoginDialog(true)}
                size="sm"
                className="bg-blue-600 hover:bg-blue-700"
              >
                Admin Login
              </Button>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="bg-gradient-to-br from-blue-50 to-indigo-100 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h1 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-6">
                Transparent Youth 
                <span className="text-blue-600"> Governance</span>
              </h1>
              <p className="text-xl text-gray-600 mb-8">
                Empowering youth through accountable leadership, transparent budget management, 
                and community-driven development initiatives.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button 
                  onClick={() => setCurrentView('public-projects')}
                  size="lg"
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  View Projects
                  <ArrowRight className="ml-2 w-5 h-5" />
                </Button>
                <Button 
                  onClick={() => setCurrentView('youth-summary')}
                  variant="outline" 
                  size="lg"
                  className="border-blue-600 text-blue-600 hover:bg-blue-50"
                >
                  Youth Programs
                </Button>
              </div>
            </div>
            <div className="relative">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1531545514256-b1400bc00f31"
                alt="Youth community engagement"
                className="rounded-2xl shadow-2xl w-full h-96 object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Statistics Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Our Impact</h2>
            <p className="text-xl text-gray-600">Real numbers, real impact in our community</p>
          </div>
          
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <div className="inline-flex items-center justify-center w-16 h-16 bg-blue-100 rounded-full mb-4">
                  <stat.icon className="w-8 h-8 text-blue-600" />
                </div>
                <div className="text-3xl font-bold text-gray-900 mb-2">{stat.value}</div>
                <div className="text-gray-600">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Why Choose Transparency</h2>
            <p className="text-xl text-gray-600">Building trust through open governance and accountability</p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <Card key={index} className="border-0 shadow-lg hover:shadow-xl transition-shadow">
                <CardContent className="p-6 text-center">
                  <div className="inline-flex items-center justify-center w-16 h-16 bg-blue-100 rounded-full mb-4">
                    <feature.icon className="w-8 h-8 text-blue-600" />
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-3">{feature.title}</h3>
                  <p className="text-gray-600">{feature.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-blue-600">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-white mb-4">
            Get Involved in Your Community
          </h2>
          <p className="text-xl text-blue-100 mb-8">
            Join us in building a better future for our youth and community
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              onClick={() => setCurrentView('events')}
              size="lg"
              variant="outline"
              className="bg-transparent border-white text-white hover:bg-white hover:text-blue-600"
            >
              View Events
            </Button>
            <Button 
              onClick={() => setCurrentView('contact')}
              size="lg"
              className="bg-white text-blue-600 hover:bg-gray-100"
            >
              Contact Us
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8">
            <div className="col-span-2">
              <div className="flex items-center space-x-3 mb-4">
                <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
                  <span className="text-white font-bold text-lg">SK</span>
                </div>
                <div>
                  <h3 className="text-lg font-bold">Sangguniang Kabataan</h3>
                  <p className="text-gray-400 text-sm">Budget Transparency Portal</p>
                </div>
              </div>
              <p className="text-gray-400 mb-4">
                Empowering youth through transparent governance and community-driven development.
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Quick Links</h4>
              <ul className="space-y-2 text-gray-400">
                <li><button onClick={() => setCurrentView('public-projects')} className="hover:text-white transition-colors">Projects</button></li>
                <li><button onClick={() => setCurrentView('events')} className="hover:text-white transition-colors">Events</button></li>
                <li><button onClick={() => setCurrentView('youth-summary')} className="hover:text-white transition-colors">Youth Programs</button></li>
                <li><button onClick={() => setCurrentView('about')} className="hover:text-white transition-colors">About Us</button></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Contact</h4>
              <ul className="space-y-2 text-gray-400">
                <li>Barangay Hall</li>
                <li>Monday - Friday, 8AM - 5PM</li>
                <li>sk@barangay.gov.ph</li>
                <li>(02) 123-4567</li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2024 Sangguniang Kabataan. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}