import React from 'react';
import { DollarSign, TrendingUp, AlertTriangle, CheckCircle } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '../../../../components/ui/card';
import { Badge } from '../../../../components/ui/badge';
import { Progress } from '../../../../components/ui/progress';

interface Project {
  id: number;
  title: string;
  budget: number;
  expenses: number;
  status: string;
}

interface BudgetMonitoringProps {
  projects: Project[];
}

export default function BudgetMonitoring({ projects }: BudgetMonitoringProps) {
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-PH', {
      style: 'currency',
      currency: 'PHP',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(amount);
  };

  const calculateProgress = (expenses: number, budget: number) => {
    return Math.round((expenses / budget) * 100);
  };

  const getBudgetStatus = (expenses: number, budget: number) => {
    const percentage = (expenses / budget) * 100;
    if (percentage > 90) return { status: 'critical', color: 'text-red-600' };
    if (percentage > 75) return { status: 'warning', color: 'text-orange-600' };
    return { status: 'good', color: 'text-green-600' };
  };

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Budget Monitoring</h1>
        <p className="text-gray-600">Track and monitor budget utilization across all projects</p>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Total Budget</p>
                <p className="text-2xl font-bold text-gray-900">
                  {formatCurrency(projects.reduce((sum, p) => sum + p.budget, 0))}
                </p>
              </div>
              <DollarSign className="w-8 h-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Total Expenses</p>
                <p className="text-2xl font-bold text-gray-900">
                  {formatCurrency(projects.reduce((sum, p) => sum + p.expenses, 0))}
                </p>
              </div>
              <TrendingUp className="w-8 h-8 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Remaining</p>
                <p className="text-2xl font-bold text-gray-900">
                  {formatCurrency(projects.reduce((sum, p) => sum + (p.budget - p.expenses), 0))}
                </p>
              </div>
              <CheckCircle className="w-8 h-8 text-purple-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Over Budget</p>
                <p className="text-2xl font-bold text-gray-900">
                  {projects.filter(p => p.expenses > p.budget).length}
                </p>
              </div>
              <AlertTriangle className="w-8 h-8 text-red-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Project Budget Status</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {projects.map((project) => {
                const progress = calculateProgress(project.expenses, project.budget);
                const budgetStatus = getBudgetStatus(project.expenses, project.budget);
                
                return (
                  <div key={project.id} className="p-4 border rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-medium">{project.title}</h4>
                      <Badge 
                        className={`${
                          budgetStatus.status === 'critical' ? 'bg-red-100 text-red-800' :
                          budgetStatus.status === 'warning' ? 'bg-orange-100 text-orange-800' :
                          'bg-green-100 text-green-800'
                        }`}
                      >
                        {progress}% utilized
                      </Badge>
                    </div>
                    
                    <div className="flex items-center justify-between text-sm text-gray-600 mb-2">
                      <span>Budget: {formatCurrency(project.budget)}</span>
                      <span>Spent: {formatCurrency(project.expenses)}</span>
                    </div>
                    
                    <Progress 
                      value={Math.min(progress, 100)} 
                      className={`h-2 ${
                        budgetStatus.status === 'critical' ? '[&>div]:bg-red-600' :
                        budgetStatus.status === 'warning' ? '[&>div]:bg-orange-600' :
                        '[&>div]:bg-green-600'
                      }`}
                    />
                    
                    <div className="flex items-center justify-between text-xs text-gray-500 mt-1">
                      <span>Remaining: {formatCurrency(project.budget - project.expenses)}</span>
                      <span className={budgetStatus.color}>
                        {budgetStatus.status === 'critical' ? 'Over budget!' :
                         budgetStatus.status === 'warning' ? 'Close to limit' : 'On track'}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}