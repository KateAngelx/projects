import React from 'react';
import { Download, FileText, Calendar } from 'lucide-react';
import { Button } from '../../../../components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../../../../components/ui/card';

export default function PDFReports() {
  const reportTypes = [
    {
      title: 'Project Summary Report',
      description: 'Complete overview of all projects and their status',
      icon: FileText
    },
    {
      title: 'Budget Analysis Report',
      description: 'Detailed budget allocation and expense analysis',
      icon: Calendar
    },
    {
      title: 'Youth Engagement Report',
      description: 'Youth participation and program effectiveness metrics',
      icon: FileText
    },
    {
      title: 'Transparency Report',
      description: 'Public transparency and accountability metrics',
      icon: FileText
    }
  ];

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">PDF Report Generator</h1>
        <p className="text-gray-600">Generate comprehensive reports for transparency and analysis</p>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        {reportTypes.map((report, index) => (
          <Card key={index}>
            <CardHeader>
              <CardTitle className="flex items-center gap-3">
                <report.icon className="w-6 h-6 text-blue-600" />
                {report.title}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 mb-4">{report.description}</p>
              <Button className="w-full bg-blue-600 hover:bg-blue-700">
                <Download className="w-4 h-4 mr-2" />
                Generate Report
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}