import React from 'react';
import { Users, Plus } from 'lucide-react';
import { Button } from '../../../../components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../../../../components/ui/card';
import { Badge } from '../../../../components/ui/badge';

interface YouthProfile {
  id: number;
  name: string;
  age: number;
  gender: string;
  address: string;
  education: string;
  skills: string[];
  interests: string[];
  participatedProjects: number[];
  dateRegistered: string;
  status: string;
}

interface YouthProfilingProps {
  youthProfiles: YouthProfile[];
}

export default function YouthProfiling({ youthProfiles }: YouthProfilingProps) {
  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Youth Profiling</h1>
          <p className="text-gray-600">Manage youth profiles and participation tracking</p>
        </div>
        <Button className="bg-blue-600 hover:bg-blue-700">
          <Plus className="w-4 h-4 mr-2" />
          Add Youth Profile
        </Button>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {youthProfiles.map((profile) => (
          <Card key={profile.id}>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg">{profile.name}</CardTitle>
                <Badge variant={profile.status === 'active' ? 'default' : 'secondary'}>
                  {profile.status}
                </Badge>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-2 text-sm">
                <p><strong>Age:</strong> {profile.age}</p>
                <p><strong>Education:</strong> {profile.education}</p>
                <p><strong>Address:</strong> {profile.address}</p>
                <div>
                  <strong>Skills:</strong>
                  <div className="flex flex-wrap gap-1 mt-1">
                    {profile.skills.map((skill, index) => (
                      <Badge key={index} variant="outline" className="text-xs">
                        {skill}
                      </Badge>
                    ))}
                  </div>
                </div>
                <div>
                  <strong>Interests:</strong>
                  <div className="flex flex-wrap gap-1 mt-1">
                    {profile.interests.map((interest, index) => (
                      <Badge key={index} variant="secondary" className="text-xs">
                        {interest}
                      </Badge>
                    ))}
                  </div>
                </div>
                <p><strong>Projects Participated:</strong> {profile.participatedProjects.length}</p>
                <p><strong>Registered:</strong> {new Date(profile.dateRegistered).toLocaleDateString()}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}