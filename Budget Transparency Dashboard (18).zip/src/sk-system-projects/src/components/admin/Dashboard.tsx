import React from 'react';
import { 
  Users, 
  DollarSign, 
  FolderOpen, 
  Calendar, 
  TrendingUp, 
  AlertCircle,
  CheckCircle,
  Clock,
  ArrowUpRight
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '../../../../components/ui/card';
import { Button } from '../../../../components/ui/button';
import { Badge } from '../../../../components/ui/badge';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line } from 'recharts';

interface DashboardProps {
  setCurrentView: (view: string) => void;
}

export default function Dashboard({ setCurrentView }: DashboardProps) {
  // Mock data for charts
  const budgetData = [
    { month: 'Jan', budget: 120000, expenses: 85000 },
    { month: 'Feb', budget: 150000, expenses: 120000 },
    { month: 'Mar', budget: 180000, expenses: 165000 },
    { month: 'Apr', budget: 200000, expenses: 180000 },
    { month: 'May', budget: 160000, expenses: 140000 },
    { month: 'Jun', budget: 220000, expenses: 200000 },
  ];

  const projectStatusData = [
    { name: 'Completed', value: 8, color: '#10B981' },
    { name: 'Ongoing', value: 12, color: '#3B82F6' },
    { name: 'Planning', value: 5, color: '#F59E0B' },
    { name: 'On Hold', value: 2, color: '#EF4444' },
  ];

  const categoryData = [
    { category: 'Education', projects: 8, budget: 320000 },
    { category: 'Sports', projects: 6, budget: 180000 },
    { category: 'Environment', projects: 4, budget: 150000 },
    { category: 'Technology', projects: 5, budget: 200000 },
    { category: 'Health', projects: 4, budget: 120000 },
  ];

  const recentActivities = [
    {
      id: 1,
      action: 'Project Created',
      description: 'Youth Skills Development Program',
      user: 'SK Chairman',
      time: '2 hours ago',
      type: 'create'
    },
    {
      id: 2,
      action: 'Budget Updated',
      description: 'Community Sports Festival - ₱80,000',
      user: 'SK Treasurer',
      time: '4 hours ago',
      type: 'update'
    },
    {
      id: 3,
      action: 'Document Uploaded',
      description: 'Financial Report Q2 2024',
      user: 'SK Secretary',
      time: '6 hours ago',
      type: 'upload'
    },
    {
      id: 4,
      action: 'Project Completed',
      description: 'Environmental Awareness Campaign',
      user: 'SK Chairman',
      time: '1 day ago',
      type: 'complete'
    }
  ];

  const alerts = [
    {
      id: 1,
      type: 'warning',
      title: 'Budget Alert',
      message: 'Community Sports Festival is 85% over budget',
      priority: 'high'
    },
    {
      id: 2,
      type: 'info',
      title: 'Document Review',
      message: '3 documents pending approval',
      priority: 'medium'
    },
    {
      id: 3,
      type: 'success',
      title: 'Project Milestone',
      message: 'Youth Skills Program reached 75% completion',
      priority: 'low'
    }
  ];

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-PH', {
      style: 'currency',
      currency: 'PHP',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(amount);
  };

  const getActivityIcon = (type: string) => {
    switch (type) {
      case 'create': return <FolderOpen className="w-4 h-4 text-blue-600" />;
      case 'update': return <DollarSign className="w-4 h-4 text-orange-600" />;
      case 'upload': return <Calendar className="w-4 h-4 text-green-600" />;
      case 'complete': return <CheckCircle className="w-4 h-4 text-purple-600" />;
      default: return <Clock className="w-4 h-4 text-gray-600" />;
    }
  };

  const getAlertIcon = (type: string) => {
    switch (type) {
      case 'warning': return <AlertCircle className="w-5 h-5 text-orange-600" />;
      case 'info': return <Clock className="w-5 h-5 text-blue-600" />;
      case 'success': return <CheckCircle className="w-5 h-5 text-green-600" />;
      default: return <AlertCircle className="w-5 h-5 text-gray-600" />;
    }
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Dashboard</h1>
          <p className="text-gray-600">Overview of SK Budget Transparency System</p>
        </div>
        <div className="flex gap-3">
          <Button onClick={() => setCurrentView('projects')} className="bg-blue-600 hover:bg-blue-700">
            <FolderOpen className="w-4 h-4 mr-2" />
            Manage Projects
          </Button>
          <Button onClick={() => setCurrentView('reports')} variant="outline">
            <TrendingUp className="w-4 h-4 mr-2" />
            Generate Report
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="border-l-4 border-l-blue-600">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Total Projects</p>
                <p className="text-3xl font-bold text-gray-900">27</p>
                <p className="text-sm text-green-600 font-medium">↑ 12% from last month</p>
              </div>
              <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                <FolderOpen className="w-6 h-6 text-blue-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-green-600">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Total Budget</p>
                <p className="text-3xl font-bold text-gray-900">₱1.2M</p>
                <p className="text-sm text-green-600 font-medium">↑ 8% from last month</p>
              </div>
              <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                <DollarSign className="w-6 h-6 text-green-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-purple-600">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Youth Engaged</p>
                <p className="text-3xl font-bold text-gray-900">485</p>
                <p className="text-sm text-green-600 font-medium">↑ 15% from last month</p>
              </div>
              <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center">
                <Users className="w-6 h-6 text-purple-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-orange-600">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Active Events</p>
                <p className="text-3xl font-bold text-gray-900">8</p>
                <p className="text-sm text-orange-600 font-medium">→ Same as last month</p>
              </div>
              <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center">
                <Calendar className="w-6 h-6 text-orange-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts Row */}
      <div className="grid lg:grid-cols-3 gap-6">
        {/* Budget vs Expenses Chart */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-blue-600" />
              Budget vs Expenses Trend
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={budgetData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis dataKey="month" stroke="#666" />
                <YAxis stroke="#666" />
                <Tooltip 
                  formatter={(value) => [formatCurrency(value as number), '']}
                  labelStyle={{ color: '#333' }}
                />
                <Bar dataKey="budget" fill="#3B82F6" name="Budget" radius={[4, 4, 0, 0]} />
                <Bar dataKey="expenses" fill="#10B981" name="Expenses" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Project Status Pie Chart */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FolderOpen className="w-5 h-5 text-blue-600" />
              Project Status
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={projectStatusData}
                  cx="50%"
                  cy="50%"
                  innerRadius={40}
                  outerRadius={100}
                  paddingAngle={2}
                  dataKey="value"
                >
                  {projectStatusData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
            <div className="mt-4 space-y-2">
              {projectStatusData.map((item, index) => (
                <div key={index} className="flex items-center justify-between text-sm">
                  <div className="flex items-center gap-2">
                    <div 
                      className="w-3 h-3 rounded-full" 
                      style={{ backgroundColor: item.color }}
                    ></div>
                    <span>{item.name}</span>
                  </div>
                  <span className="font-medium">{item.value}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Bottom Row */}
      <div className="grid lg:grid-cols-3 gap-6">
        {/* Recent Activities */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <Clock className="w-5 h-5 text-blue-600" />
                Recent Activities
              </CardTitle>
              <Button variant="ghost" size="sm" onClick={() => setCurrentView('audit')}>
                View All
                <ArrowUpRight className="w-4 h-4 ml-1" />
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentActivities.map((activity) => (
                <div key={activity.id} className="flex items-start gap-3 p-3 rounded-lg hover:bg-gray-50 transition-colors">
                  <div className="flex-shrink-0 mt-1">
                    {getActivityIcon(activity.type)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-gray-900">{activity.action}</p>
                    <p className="text-sm text-gray-600 truncate">{activity.description}</p>
                    <div className="flex items-center gap-2 mt-1">
                      <span className="text-xs text-gray-500">{activity.user}</span>
                      <span className="text-xs text-gray-400">•</span>
                      <span className="text-xs text-gray-500">{activity.time}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Alerts */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertCircle className="w-5 h-5 text-orange-600" />
              System Alerts
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {alerts.map((alert) => (
                <div key={alert.id} className="p-3 border rounded-lg">
                  <div className="flex items-start gap-3">
                    <div className="flex-shrink-0">
                      {getAlertIcon(alert.type)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <h4 className="text-sm font-medium text-gray-900">{alert.title}</h4>
                        <Badge 
                          variant="outline" 
                          className={`text-xs ${
                            alert.priority === 'high' ? 'border-red-200 text-red-800' :
                            alert.priority === 'medium' ? 'border-orange-200 text-orange-800' :
                            'border-green-200 text-green-800'
                          }`}
                        >
                          {alert.priority}
                        </Badge>
                      </div>
                      <p className="text-sm text-gray-600">{alert.message}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}