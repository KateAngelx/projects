import React from 'react';
import { UserPlus, Edit, Trash2 } from 'lucide-react';
import { Button } from '../../../../components/ui/button';
import { Card, CardContent } from '../../../../components/ui/card';
import { Badge } from '../../../../components/ui/badge';

interface User {
  id: number;
  username: string;
  name: string;
  role: string;
  email: string;
  department: string;
  permissions: string[];
  status: string;
  dateCreated: string;
  lastLogin: string;
}

interface UserAccountsProps {
  users: User[];
  onUpdateUser: (id: number, updates: any) => void;
  onDeleteUser: (id: number) => void;
  onAddUser: (user: any) => void;
}

export default function UserAccounts({ users }: UserAccountsProps) {
  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">User Accounts</h1>
          <p className="text-gray-600">Manage user accounts and permissions</p>
        </div>
        <Button className="bg-blue-600 hover:bg-blue-700">
          <UserPlus className="w-4 h-4 mr-2" />
          Add User
        </Button>
      </div>

      <div className="grid gap-4">
        {users.map((user) => (
          <Card key={user.id}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-medium">{user.name}</h3>
                  <p className="text-sm text-gray-600">{user.email}</p>
                  <div className="flex items-center gap-2 mt-2">
                    <Badge>{user.role}</Badge>
                    <Badge variant="outline">{user.department}</Badge>
                    <Badge variant={user.status === 'active' ? 'default' : 'secondary'}>
                      {user.status}
                    </Badge>
                  </div>
                  <p className="text-xs text-gray-500 mt-1">
                    Last login: {user.lastLogin}
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <Button variant="ghost" size="sm">
                    <Edit className="w-4 h-4" />
                  </Button>
                  <Button variant="ghost" size="sm">
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}