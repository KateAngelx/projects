import React from 'react';
import { Eye, EyeOff, Settings } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '../../../../components/ui/card';
import { Switch } from '../../../../components/ui/switch';
import { Badge } from '../../../../components/ui/badge';

interface PublicTransparencyControlsProps {
  projects: any[];
  documents: any[];
}

export default function PublicTransparencyControls({ projects, documents }: PublicTransparencyControlsProps) {
  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Public Transparency Controls</h1>
        <p className="text-gray-600">Control what information is visible to the public</p>
      </div>

      <div className="grid gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Eye className="w-5 h-5" />
              Public Projects
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {projects.map((project) => (
                <div key={project.id} className="flex items-center justify-between p-3 border rounded">
                  <div className="flex items-center gap-3">
                    {project.isPublic ? (
                      <Eye className="w-4 h-4 text-green-600" />
                    ) : (
                      <EyeOff className="w-4 h-4 text-gray-400" />
                    )}
                    <div>
                      <h4 className="font-medium">{project.title}</h4>
                      <p className="text-sm text-gray-600">{project.category}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <Badge variant={project.isPublic ? "default" : "secondary"}>
                      {project.isPublic ? 'Public' : 'Private'}
                    </Badge>
                    <Switch checked={project.isPublic} />
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Settings className="w-5 h-5" />
              Public Documents
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {documents.map((document) => (
                <div key={document.id} className="flex items-center justify-between p-3 border rounded">
                  <div className="flex items-center gap-3">
                    {document.isPublic ? (
                      <Eye className="w-4 h-4 text-green-600" />
                    ) : (
                      <EyeOff className="w-4 h-4 text-gray-400" />
                    )}
                    <div>
                      <h4 className="font-medium">{document.title}</h4>
                      <p className="text-sm text-gray-600">{document.type}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <Badge variant={document.isPublic ? "default" : "secondary"}>
                      {document.isPublic ? 'Public' : 'Private'}
                    </Badge>
                    <Switch checked={document.isPublic} />
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}