import React, { useState } from 'react';
import { FileText, Upload, Eye, Download, Edit, Trash2 } from 'lucide-react';
import { Button } from '../../../../components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../../../../components/ui/card';
import { Badge } from '../../../../components/ui/badge';

interface Document {
  id: number;
  title: string;
  type: string;
  category: string;
  uploadDate: string;
  uploadedBy: string;
  size: string;
  format: string;
  isPublic: boolean;
  downloadCount: number;
  description: string;
  lastModified: string;
}

interface DocumentManagementProps {
  documents: Document[];
  onUpdateDocument: (id: number, updates: any) => void;
  onDeleteDocument: (id: number) => void;
  onAddDocument: (document: any) => void;
}

export default function DocumentManagement({ documents }: DocumentManagementProps) {
  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Document Management</h1>
          <p className="text-gray-600">Manage and organize all project documents</p>
        </div>
        <Button className="bg-blue-600 hover:bg-blue-700">
          <Upload className="w-4 h-4 mr-2" />
          Upload Document
        </Button>
      </div>

      <div className="grid gap-4">
        {documents.map((doc) => (
          <Card key={doc.id}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <FileText className="w-8 h-8 text-blue-600" />
                  <div>
                    <h3 className="font-medium">{doc.title}</h3>
                    <p className="text-sm text-gray-600">{doc.description}</p>
                    <div className="flex items-center gap-2 mt-1">
                      <Badge variant="outline">{doc.type}</Badge>
                      <Badge variant={doc.isPublic ? "default" : "secondary"}>
                        {doc.isPublic ? 'Public' : 'Private'}
                      </Badge>
                      <span className="text-xs text-gray-500">{doc.size}</span>
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Button variant="ghost" size="sm">
                    <Eye className="w-4 h-4" />
                  </Button>
                  <Button variant="ghost" size="sm">
                    <Download className="w-4 h-4" />
                  </Button>
                  <Button variant="ghost" size="sm">
                    <Edit className="w-4 h-4" />
                  </Button>
                  <Button variant="ghost" size="sm">
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}