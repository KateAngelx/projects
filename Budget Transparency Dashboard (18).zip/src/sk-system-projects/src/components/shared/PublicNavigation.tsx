import React from 'react';
import { Home, FolderOpen, Calendar, Users, Info, Phone } from 'lucide-react';
import { useAppContext } from '../../App';

const publicNavItems = [
  { icon: Home, label: 'Home', view: 'home', color: 'blue' },
  { icon: FolderOpen, label: 'Projects', view: 'public-projects', color: 'green' },
  { icon: Calendar, label: 'Events', view: 'events', color: 'purple' },
  { icon: Users, label: 'Youth Profiles', view: 'youth-summary', color: 'pink' },
  { icon: Info, label: 'About SK', view: 'about', color: 'orange' },
  { icon: Phone, label: 'Contact', view: 'contact', color: 'red' }
];

export default function PublicNavigation() {
  const { currentView, setCurrentView } = useAppContext();

  const getColorClasses = (color: string, isActive: boolean) => {
    if (isActive) {
      return 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white shadow-lg scale-105';
    }
    
    const colorMap: Record<string, string> = {
      blue: 'hover:bg-blue-50 hover:text-blue-700',
      green: 'hover:bg-green-50 hover:text-green-700',
      purple: 'hover:bg-purple-50 hover:text-purple-700',
      pink: 'hover:bg-pink-50 hover:text-pink-700',
      orange: 'hover:bg-orange-50 hover:text-orange-700',
      red: 'hover:bg-red-50 hover:text-red-700'
    };
    
    return `text-gray-700 ${colorMap[color]} hover:scale-105`;
  };

  return (
    <nav className="w-full bg-white border-b border-gray-200 px-6 py-4 shadow-sm">
      <div className="flex flex-wrap justify-center gap-4">
        {publicNavItems.map((item, index) => (
          <button
            key={index}
            onClick={() => setCurrentView(item.view)}
            className={`flex items-center gap-2 px-6 py-3 rounded-xl font-medium transition-all duration-200 transform hover:shadow-md ${
              getColorClasses(item.color, currentView === item.view)
            }`}
          >
            <item.icon className="w-5 h-5" />
            <span>{item.label}</span>
          </button>
        ))}
      </div>
    </nav>
  );
}