import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '../../../../components/ui/dialog';
import { Button } from '../../../../components/ui/button';
import { Input } from '../../../../components/ui/input';
import { Label } from '../../../../components/ui/label';
import { User, Lock } from 'lucide-react';

interface LoginDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  loginForm: { username: string; password: string };
  setLoginForm: (form: { username: string; password: string }) => void;
  onLogin: () => void;
}

export default function LoginDialog({ 
  open, 
  onOpenChange, 
  loginForm, 
  setLoginForm, 
  onLogin 
}: LoginDialogProps) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="text-center text-xl">
            SK Admin Portal Login
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4 pt-4">
          <div className="space-y-2">
            <Label htmlFor="username">Username</Label>
            <div className="relative">
              <User className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                id="username"
                type="text"
                placeholder="Enter your username"
                value={loginForm.username}
                onChange={(e) => setLoginForm({ ...loginForm, username: e.target.value })}
                className="pl-10"
              />
            </div>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="password">Password</Label>
            <div className="relative">
              <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                id="password"
                type="password"
                placeholder="Enter your password"
                value={loginForm.password}
                onChange={(e) => setLoginForm({ ...loginForm, password: e.target.value })}
                className="pl-10"
                onKeyPress={(e) => {
                  if (e.key === 'Enter') {
                    onLogin();
                  }
                }}
              />
            </div>
          </div>
          
          <div className="flex gap-2 pt-4">
            <Button 
              variant="outline" 
              onClick={() => onOpenChange(false)}
              className="flex-1"
            >
              Cancel
            </Button>
            <Button 
              onClick={onLogin}
              disabled={!loginForm.username || !loginForm.password}
              className="flex-1"
              style={{ backgroundColor: '#3498DB' }}
            >
              Login
            </Button>
          </div>
          
          <div className="text-center text-sm text-gray-500 pt-2">
            Demo credentials: admin / password
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}