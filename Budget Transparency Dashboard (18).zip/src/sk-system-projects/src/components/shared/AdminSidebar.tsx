import React from 'react';
import { 
  BarChart3, FolderOpen, DollarSign, FileText, Users, 
  Settings, Eye, UserPlus, ClipboardList, Download
} from 'lucide-react';
import { useAppContext } from '../../App';

const sidebarItems = [
  { icon: BarChart3, label: 'Dashboard', view: 'dashboard', color: 'blue' },
  { icon: FolderOpen, label: 'Project Management', view: 'projects', color: 'green' },
  { icon: DollarSign, label: 'Budget Monitoring', view: 'budget', color: 'yellow' },
  { icon: FileText, label: 'Document Management', view: 'documents', color: 'purple' },
  { icon: Users, label: 'Youth Profiling', view: 'youth', color: 'pink' },
  { icon: Eye, label: 'Public Transparency', view: 'transparency', color: 'orange' },
  { icon: UserPlus, label: 'User Accounts', view: 'users', color: 'red' },
  { icon: ClipboardList, label: 'Audit Trail', view: 'audit', color: 'indigo' },
  { icon: Download, label: 'PDF Reports', view: 'reports', color: 'emerald' },
  { icon: Settings, label: 'System Settings', view: 'settings', color: 'gray' }
];

export default function AdminSidebar() {
  const { currentView, setCurrentView, currentUser } = useAppContext();

  const getColorClasses = (color: string, isActive: boolean) => {
    if (isActive) {
      return 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white shadow-lg';
    }
    
    const colorMap: Record<string, string> = {
      blue: 'hover:bg-blue-50 hover:text-blue-700',
      green: 'hover:bg-green-50 hover:text-green-700',
      yellow: 'hover:bg-yellow-50 hover:text-yellow-700',
      purple: 'hover:bg-purple-50 hover:text-purple-700',
      pink: 'hover:bg-pink-50 hover:text-pink-700',
      orange: 'hover:bg-orange-50 hover:text-orange-700',
      red: 'hover:bg-red-50 hover:text-red-700',
      indigo: 'hover:bg-indigo-50 hover:text-indigo-700',
      emerald: 'hover:bg-emerald-50 hover:text-emerald-700',
      gray: 'hover:bg-gray-50 hover:text-gray-700'
    };
    
    return `text-gray-700 ${colorMap[color]}`;
  };

  return (
    <aside className="w-64 bg-white border-r border-gray-200 min-h-[calc(100vh-73px)] sticky top-[73px] shadow-sm">
      <div className="p-6">
        <div className="mb-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-2">Admin Panel</h2>
          <div className="flex items-center gap-2 p-3 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg border border-blue-200">
            <div className="w-8 h-8 rounded-full bg-gradient-to-r from-blue-600 to-indigo-600 flex items-center justify-center">
              <span className="text-white text-xs font-medium">
                {currentUser.name.split(' ').map((n: string) => n[0]).join('').toUpperCase()}
              </span>
            </div>
            <div>
              <div className="text-sm font-medium text-gray-900">{currentUser.name}</div>
              <div className="text-xs text-gray-600">{currentUser.role.toUpperCase()}</div>
            </div>
          </div>
        </div>
        
        <nav className="space-y-2">
          {sidebarItems.map((item, index) => (
            <button
              key={index}
              onClick={() => setCurrentView(item.view)}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 transform hover:scale-105 hover:shadow-md ${
                getColorClasses(item.color, currentView === item.view)
              }`}
            >
              <item.icon className="w-5 h-5" />
              <span className="font-medium">{item.label}</span>
            </button>
          ))}
        </nav>

        <div className="mt-8 p-4 bg-gradient-to-r from-gray-50 to-blue-50 rounded-xl border border-gray-200">
          <h3 className="text-sm font-semibold text-gray-900 mb-2">Quick Stats</h3>
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-gray-600">Active Projects</span>
              <span className="font-medium text-blue-600">3</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-gray-600">Total Budget</span>
              <span className="font-medium text-green-600">₱210K</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-gray-600">Youth Served</span>
              <span className="font-medium text-purple-600">480</span>
            </div>
          </div>
        </div>
      </div>
    </aside>
  );
}