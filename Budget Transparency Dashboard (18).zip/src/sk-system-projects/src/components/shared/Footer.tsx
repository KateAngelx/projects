import React from 'react';
import { Card } from '../../../../components/ui/card';
import { Button } from '../../../../components/ui/button';
import { 
  Users, Phone, Mail, MapPin, Globe, Facebook, Instagram, 
  Twitter, Youtube, Heart, Award, Shield, Calendar
} from 'lucide-react';

interface FooterProps {
  isPublicView: boolean;
}

export default function Footer({ isPublicView }: FooterProps) {
  if (!isPublicView) {
    // Admin Footer
    return (
      <footer className="bg-white border-t border-gray-200 px-6 py-4 mt-auto">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 bg-blue-600 rounded-lg flex items-center justify-center">
              <Users className="w-4 h-4 text-white" />
            </div>
            <span className="text-sm text-gray-600">
              SK Transparency System © 2024 - Admin Panel
            </span>
          </div>
          <div className="flex items-center gap-4 text-sm text-gray-600">
            <span>Version 1.0.0</span>
            <Button variant="ghost" size="sm">Help</Button>
            <Button variant="ghost" size="sm">Support</Button>
          </div>
        </div>
      </footer>
    );
  }

  // Public Footer
  return (
    <footer className="bg-gray-900 text-white">
      <div className="container mx-auto px-6 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* About Section */}
          <div>
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
                <Users className="w-6 h-6 text-white" />
              </div>
              <div>
                <h3 className="text-lg font-semibold">SK Alawihao</h3>
                <p className="text-sm text-gray-400">Transparency System</p>
              </div>
            </div>
            <p className="text-gray-300 mb-4">
              Empowering youth through transparency, accountability, and innovative governance. 
              Building a stronger community for the future.
            </p>
            <div className="flex items-center gap-2 text-sm text-gray-400">
              <Award className="w-4 h-4" />
              <span>ISO 9001:2015 Certified</span>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-lg font-semibold mb-6">Quick Links</h4>
            <ul className="space-y-3">
              <li>
                <a href="#" className="text-gray-300 hover:text-white transition-colors">
                  Our Projects
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-300 hover:text-white transition-colors">
                  Upcoming Events
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-300 hover:text-white transition-colors">
                  Youth Programs
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-300 hover:text-white transition-colors">
                  Budget Reports
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-300 hover:text-white transition-colors">
                  Document Library
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-300 hover:text-white transition-colors">
                  FAQs
                </a>
              </li>
            </ul>
          </div>

          {/* Contact Information */}
          <div>
            <h4 className="text-lg font-semibold mb-6">Contact Us</h4>
            <ul className="space-y-4">
              <li className="flex items-start gap-3">
                <MapPin className="w-5 h-5 text-blue-400 mt-0.5 flex-shrink-0" />
                <div>
                  <p className="text-gray-300">Barangay Hall, Alawihao</p>
                  <p className="text-gray-400 text-sm">Municipality, Province 1234</p>
                </div>
              </li>
              <li className="flex items-center gap-3">
                <Phone className="w-5 h-5 text-blue-400 flex-shrink-0" />
                <div>
                  <p className="text-gray-300">+63 123 456 7890</p>
                  <p className="text-gray-400 text-sm">Mon-Fri, 8AM-5PM</p>
                </div>
              </li>
              <li className="flex items-center gap-3">
                <Mail className="w-5 h-5 text-blue-400 flex-shrink-0" />
                <div>
                  <p className="text-gray-300">sk.alawihao@barangay.gov.ph</p>
                  <p className="text-gray-400 text-sm">Official Email</p>
                </div>
              </li>
            </ul>
          </div>

          {/* Social Media & Updates */}
          <div>
            <h4 className="text-lg font-semibold mb-6">Stay Connected</h4>
            <div className="grid grid-cols-2 gap-3 mb-6">
              <Button variant="outline" className="border-gray-600 text-gray-300 hover:bg-blue-600 hover:border-blue-600 hover:text-white">
                <Facebook className="w-4 h-4 mr-2" />
                Facebook
              </Button>
              <Button variant="outline" className="border-gray-600 text-gray-300 hover:bg-pink-600 hover:border-pink-600 hover:text-white">
                <Instagram className="w-4 h-4 mr-2" />
                Instagram
              </Button>
              <Button variant="outline" className="border-gray-600 text-gray-300 hover:bg-blue-400 hover:border-blue-400 hover:text-white">
                <Twitter className="w-4 h-4 mr-2" />
                Twitter
              </Button>
              <Button variant="outline" className="border-gray-600 text-gray-300 hover:bg-red-600 hover:border-red-600 hover:text-white">
                <Youtube className="w-4 h-4 mr-2" />
                YouTube
              </Button>
            </div>
            
            <div className="bg-gray-800 rounded-lg p-4">
              <div className="flex items-center gap-2 mb-2">
                <Calendar className="w-4 h-4 text-blue-400" />
                <span className="text-sm font-medium">Next Event</span>
              </div>
              <p className="text-sm text-gray-300">Youth Leadership Summit</p>
              <p className="text-xs text-gray-400">April 15, 2024</p>
            </div>
          </div>
        </div>

        {/* Bottom Section */}
        <div className="border-t border-gray-700 mt-8 pt-8">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-6 text-sm text-gray-400">
              <div className="flex items-center gap-2">
                <Shield className="w-4 h-4" />
                <span>Secure & Transparent</span>
              </div>
              <div className="flex items-center gap-2">
                <Heart className="w-4 h-4 text-red-400" />
                <span>Serving with Integrity</span>
              </div>
            </div>
            
            <div className="flex items-center gap-6 text-sm text-gray-400">
              <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
              <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
              <a href="#" className="hover:text-white transition-colors">Accessibility</a>
            </div>
          </div>
          
          <div className="flex flex-col md:flex-row items-center justify-between gap-4 mt-4 pt-4 border-t border-gray-800">
            <p className="text-sm text-gray-400">
              © 2024 Sangguniang Kabataan Barangay Alawihao. All rights reserved.
            </p>
            <div className="flex items-center gap-4 text-sm text-gray-400">
              <span>Powered by</span>
              <div className="flex items-center gap-1">
                <Globe className="w-4 h-4" />
                <span className="font-medium">SK Transparency Platform</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}