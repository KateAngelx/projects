import { 
  BarChart3, FolderOpen, DollarSign, FileText, Users, 
  Settings, Eye, UserPlus, ClipboardList, Download,
  Home, Calendar, Info, Phone
} from 'lucide-react';

export const sidebarItems = [
  { icon: BarChart3, label: 'Dashboard', view: 'dashboard' },
  { icon: FolderOpen, label: 'Project Management', view: 'projects' },
  { icon: DollarSign, label: 'Budget Monitoring', view: 'budget' },
  { icon: FileText, label: 'Document Management', view: 'documents' },
  { icon: Users, label: 'Youth Profiling', view: 'youth' },
  { icon: Eye, label: 'Public Transparency Controls', view: 'transparency' },
  { icon: UserPlus, label: 'User Accounts', view: 'users' },
  { icon: ClipboardList, label: 'Audit Trail', view: 'audit' },
  { icon: Download, label: 'PDF Report Generator', view: 'reports' },
  { icon: Settings, label: 'System Settings', view: 'settings' }
];

export const publicNavItems = [
  { icon: Home, label: 'Home', view: 'home' },
  { icon: FolderOpen, label: 'Projects', view: 'public-projects' },
  { icon: Calendar, label: 'Events', view: 'events' },
  { icon: Users, label: 'Youth Profile', view: 'youth-summary' },
  { icon: Info, label: 'About SK', view: 'about' },
  { icon: Phone, label: 'Contact Us', view: 'contact' }
];

export const BUDGET_CONSTANTS = {
  totalBudget: 850000,
  totalExpenses: 612000,
  remainingBalance: 238000
};

export const expensesByCategory = [
  { category: 'Sports', amount: 150000 },
  { category: 'Education', amount: 120000 },
  { category: 'Livelihood', amount: 100000 },
  { category: 'Health', amount: 90000 },
  { category: 'Environment', amount: 80000 }
];