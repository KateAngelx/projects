// Mock data for the SK Budget Transparency System

export const initialProjects = [
  {
    id: 1,
    title: "Youth Skills Development Program",
    description: "A comprehensive program to develop technical and leadership skills among youth in the community.",
    budget: 150000,
    expenses: 75000,
    status: "ongoing",
    priority: "high",
    startDate: "2024-01-15",
    endDate: "2024-12-15",
    category: "Education",
    participants: 45,
    isPublic: true,
    createdBy: "SK Chairman",
    lastModified: "2024-08-15",
    documents: ["project-proposal.pdf", "budget-breakdown.xlsx"]
  },
  {
    id: 2,
    title: "Community Sports Festival",
    description: "Annual sports festival promoting healthy competition and community bonding among youth.",
    budget: 80000,
    expenses: 65000,
    status: "ongoing",
    priority: "medium",
    startDate: "2024-03-01",
    endDate: "2024-09-30",
    category: "Sports",
    participants: 120,
    isPublic: true,
    createdBy: "SK Secretary",
    lastModified: "2024-08-10",
    documents: ["event-plan.pdf", "equipment-list.xlsx"]
  },
  {
    id: 3,
    title: "Environmental Awareness Campaign",
    description: "Campaign to raise awareness about environmental conservation and sustainable practices.",
    budget: 50000,
    expenses: 30000,
    status: "completed",
    priority: "high",
    startDate: "2024-02-01",
    endDate: "2024-06-30",
    category: "Environment",
    participants: 200,
    isPublic: true,
    createdBy: "SK Treasurer",
    lastModified: "2024-07-01",
    documents: ["campaign-materials.pdf", "impact-report.pdf"]
  },
  {
    id: 4,
    title: "Digital Literacy Training",
    description: "Training program to improve digital skills and computer literacy among youth.",
    budget: 100000,
    expenses: 25000,
    status: "planning",
    priority: "medium",
    startDate: "2024-09-01",
    endDate: "2024-11-30",
    category: "Technology",
    participants: 60,
    isPublic: false,
    createdBy: "SK Auditor",
    lastModified: "2024-08-20",
    documents: ["training-modules.pdf"]
  }
];

export const initialDocuments = [
  {
    id: 1,
    title: "2024 Annual Budget Plan",
    type: "Budget",
    category: "Financial",
    uploadDate: "2024-01-10",
    uploadedBy: "SK Treasurer",
    size: "2.5 MB",
    format: "PDF",
    isPublic: true,
    downloadCount: 156,
    description: "Comprehensive budget plan for all SK projects and activities in 2024",
    lastModified: "2024-08-15"
  },
  {
    id: 2,
    title: "Youth Development Policy Guidelines",
    type: "Policy",
    category: "Governance",
    uploadDate: "2024-02-15",
    uploadedBy: "SK Chairman",
    size: "1.8 MB",
    format: "PDF",
    isPublic: true,
    downloadCount: 89,
    description: "Guidelines and policies for youth development programs",
    lastModified: "2024-08-10"
  },
  {
    id: 3,
    title: "Financial Audit Report Q1 2024",
    type: "Report",
    category: "Financial",
    uploadDate: "2024-04-30",
    uploadedBy: "External Auditor",
    size: "3.2 MB",
    format: "PDF",
    isPublic: false,
    downloadCount: 25,
    description: "First quarter financial audit report",
    lastModified: "2024-05-01"
  },
  {
    id: 4,
    title: "Project Implementation Guidelines",
    type: "Guidelines",
    category: "Operations",
    uploadDate: "2024-03-20",
    uploadedBy: "SK Secretary",
    size: "1.5 MB",
    format: "PDF",
    isPublic: true,
    downloadCount: 134,
    description: "Step-by-step guidelines for implementing SK projects",
    lastModified: "2024-08-05"
  }
];

export const initialUsers = [
  {
    id: 1,
    username: "sk_chairman",
    name: "Maria Santos",
    role: "Chairman",
    email: "chairman@sk-barangay.gov.ph",
    department: "Executive",
    permissions: ["all"],
    status: "active",
    dateCreated: "2024-01-01",
    lastLogin: "2024-08-26"
  },
  {
    id: 2,
    username: "sk_secretary",
    name: "Juan Dela Cruz",
    role: "Secretary",
    email: "secretary@sk-barangay.gov.ph",
    department: "Administration",
    permissions: ["projects", "documents", "youth"],
    status: "active",
    dateCreated: "2024-01-01",
    lastLogin: "2024-08-25"
  },
  {
    id: 3,
    username: "sk_treasurer",
    name: "Ana Rodriguez",
    role: "Treasurer",
    email: "treasurer@sk-barangay.gov.ph",
    department: "Finance",
    permissions: ["budget", "documents", "reports"],
    status: "active",
    dateCreated: "2024-01-01",
    lastLogin: "2024-08-24"
  },
  {
    id: 4,
    username: "sk_auditor",
    name: "Carlos Mendoza",
    role: "Auditor",
    email: "auditor@sk-barangay.gov.ph",
    department: "Audit",
    permissions: ["audit", "reports", "transparency"],
    status: "active",
    dateCreated: "2024-01-15",
    lastLogin: "2024-08-23"
  }
];

export const auditLogs = [
  {
    id: 1,
    action: "Project Created",
    user: "SK Chairman",
    target: "Youth Skills Development Program",
    timestamp: "2024-08-26 14:30:00",
    details: "Created new project with budget allocation of ₱150,000",
    category: "Project Management"
  },
  {
    id: 2,
    action: "Document Uploaded",
    user: "SK Secretary",
    target: "Project Implementation Guidelines",
    timestamp: "2024-08-26 13:15:00",
    details: "Uploaded new implementation guidelines document",
    category: "Document Management"
  },
  {
    id: 3,
    action: "Budget Updated",
    user: "SK Treasurer",
    target: "Community Sports Festival",
    timestamp: "2024-08-26 11:45:00",
    details: "Updated budget allocation from ₱75,000 to ₱80,000",
    category: "Budget Management"
  },
  {
    id: 4,
    action: "User Login",
    user: "SK Auditor",
    target: "System Access",
    timestamp: "2024-08-26 09:20:00",
    details: "Successful login to admin portal",
    category: "System Access"
  },
  {
    id: 5,
    action: "Project Status Changed",
    user: "SK Chairman",
    target: "Environmental Awareness Campaign",
    timestamp: "2024-08-25 16:00:00",
    details: "Changed project status from 'ongoing' to 'completed'",
    category: "Project Management"
  }
];

export const events = [
  {
    id: 1,
    title: "Youth Leadership Summit 2024",
    date: "2024-09-15",
    time: "09:00 AM",
    location: "Barangay Hall",
    description: "Annual summit bringing together young leaders from different sectors",
    category: "Leadership",
    capacity: 100,
    registered: 78,
    status: "upcoming"
  },
  {
    id: 2,
    title: "Community Clean-up Drive",
    date: "2024-09-22",
    time: "06:00 AM",
    location: "Various Locations",
    description: "Monthly community clean-up initiative promoting environmental awareness",
    category: "Environment",
    capacity: 150,
    registered: 92,
    status: "upcoming"
  },
  {
    id: 3,
    title: "Skills Training Workshop",
    date: "2024-09-08",
    time: "02:00 PM",
    location: "SK Training Center",
    description: "Workshop on digital marketing and entrepreneurship for youth",
    category: "Skills Development",
    capacity: 50,
    registered: 45,
    status: "completed"
  },
  {
    id: 4,
    title: "Sports Tournament Finals",
    date: "2024-10-05",
    time: "03:00 PM",
    location: "Community Sports Complex",
    description: "Final matches of the annual inter-barangay sports tournament",
    category: "Sports",
    capacity: 200,
    registered: 156,
    status: "upcoming"
  }
];

export const youthProfiles = [
  {
    id: 1,
    name: "Sarah Johnson",
    age: 19,
    gender: "Female",
    address: "123 Mabini Street",
    education: "College Sophomore",
    skills: ["Leadership", "Communication", "Event Planning"],
    interests: ["Community Service", "Environment", "Technology"],
    participatedProjects: [1, 2, 3],
    dateRegistered: "2024-01-15",
    status: "active"
  },
  {
    id: 2,
    name: "Mark Rodriguez",
    age: 21,
    gender: "Male",
    address: "456 Rizal Avenue",
    education: "College Senior",
    skills: ["Programming", "Data Analysis", "Project Management"],
    interests: ["Technology", "Innovation", "Education"],
    participatedProjects: [1, 4],
    dateRegistered: "2024-02-01",
    status: "active"
  },
  {
    id: 3,
    name: "Lisa Chen",
    age: 18,
    gender: "Female",
    address: "789 Luna Street",
    education: "High School Graduate",
    skills: ["Arts", "Design", "Social Media"],
    interests: ["Creative Arts", "Digital Media", "Community Events"],
    participatedProjects: [2, 3],
    dateRegistered: "2024-03-10",
    status: "active"
  },
  {
    id: 4,
    name: "James Wilson",
    age: 20,
    gender: "Male",
    address: "321 Bonifacio Road",
    education: "College Junior",
    skills: ["Sports Coaching", "Team Building", "Health & Fitness"],
    interests: ["Sports", "Health", "Youth Development"],
    participatedProjects: [2],
    dateRegistered: "2024-04-05",
    status: "active"
  }
];

export const statistics = {
  totalProjects: initialProjects.length,
  activeProjects: initialProjects.filter(p => p.status === 'ongoing').length,
  totalBudget: initialProjects.reduce((sum, p) => sum + p.budget, 0),
  totalExpenses: initialProjects.reduce((sum, p) => sum + p.expenses, 0),
  totalYouth: youthProfiles.length,
  totalEvents: events.length,
  upcomingEvents: events.filter(e => e.status === 'upcoming').length,
  documentsPublic: initialDocuments.filter(d => d.isPublic).length
};