import React, { useState } from 'react';
import { 
  Menu, Bell, Users, LogOut, BarChart3, FolderOpen, DollarSign, 
  FileText, Eye, UserPlus, ClipboardList, Download, Settings 
} from 'lucide-react';
import { Button } from '../../components/ui/button';

// Import components
import Dashboard from './src/components/admin/Dashboard';
import ProjectManagement from './src/components/admin/ProjectManagement';
import BudgetMonitoring from './src/components/admin/BudgetMonitoring';
import DocumentManagement from './src/components/admin/DocumentManagement';
import YouthProfiling from './src/components/admin/YouthProfiling';
import PublicTransparencyControls from './src/components/admin/PublicTransparencyControls';
import UserAccounts from './src/components/admin/UserAccounts';
import AuditTrail from './src/components/admin/AuditTrail';
import PDFReports from './src/components/admin/PDFReports';
import SystemSettings from './src/components/admin/SystemSettings';
import LoginDialog from './src/components/shared/LoginDialog';
import PublicHome from './src/components/public/PublicHome';
import PublicProjects from './src/components/public/PublicProjects';
import PublicEvents from './src/components/public/PublicEvents';
import PublicAbout from './src/components/public/PublicAbout';
import PublicContact from './src/components/public/PublicContact';
import PublicYouthSummary from './src/components/public/PublicYouthSummary';

// Import data
import { 
  initialProjects, 
  initialDocuments, 
  initialUsers, 
  auditLogs, 
  events, 
  youthProfiles 
} from './src/data/mockData';

export default function SKBudgetSystem() {
  const [currentView, setCurrentView] = useState('home');
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [isPublicView, setIsPublicView] = useState(true);
  const [showLoginDialog, setShowLoginDialog] = useState(false);
  const [loginForm, setLoginForm] = useState({ username: '', password: '' });
  const [sidebarOpen, setSidebarOpen] = useState(true);

  // Constants
  const sidebarItems = [
    { icon: BarChart3, label: 'Dashboard', view: 'dashboard' },
    { icon: FolderOpen, label: 'Project Management', view: 'projects' },
    { icon: DollarSign, label: 'Budget Monitoring', view: 'budget' },
    { icon: FileText, label: 'Document Management', view: 'documents' },
    { icon: Users, label: 'Youth Profiling', view: 'youth' },
    { icon: Eye, label: 'Public Transparency Controls', view: 'transparency' },
    { icon: UserPlus, label: 'User Accounts', view: 'users' },
    { icon: ClipboardList, label: 'Audit Trail', view: 'audit' },
    { icon: Download, label: 'PDF Report Generator', view: 'reports' },
    { icon: Settings, label: 'System Settings', view: 'settings' }
  ];

  // State management
  const [projects, setProjects] = useState(initialProjects);
  const [documents, setDocuments] = useState(initialDocuments);
  const [users, setUsers] = useState(initialUsers);

  // Login functionality
  const handleLogin = () => {
    if (loginForm.username && loginForm.password) {
      setIsLoggedIn(true);
      setIsPublicView(false);
      setCurrentView('dashboard');
      setShowLoginDialog(false);
      setLoginForm({ username: '', password: '' });
    }
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    setIsPublicView(true);
    setCurrentView('home');
    setSidebarOpen(true);
  };

  // CRUD Operations
  const handleUpdateProject = (id: number, updates: any) => {
    setProjects(projects.map(p => p.id === id ? { ...p, ...updates, lastModified: new Date().toISOString().split('T')[0] } : p));
  };

  const handleDeleteProject = (id: number) => {
    setProjects(projects.filter(p => p.id !== id));
  };

  const handleAddProject = (project: any) => {
    setProjects([...projects, { 
      ...project, 
      id: Date.now(), 
      createdBy: 'Current User', 
      lastModified: new Date().toISOString().split('T')[0],
      expenses: 0,
      participants: 0,
      documents: []
    }]);
  };

  // Document CRUD Operations
  const handleUpdateDocument = (id: number, updates: any) => {
    setDocuments(documents.map(d => d.id === id ? { ...d, ...updates, lastModified: new Date().toISOString().split('T')[0] } : d));
  };

  const handleDeleteDocument = (id: number) => {
    setDocuments(documents.filter(d => d.id !== id));
  };

  const handleAddDocument = (document: any) => {
    setDocuments([...documents, { 
      ...document, 
      id: Date.now(), 
      uploadedBy: 'Current User', 
      uploadDate: new Date().toISOString().split('T')[0],
      lastModified: new Date().toISOString().split('T')[0],
      downloadCount: 0
    }]);
  };

  // User CRUD Operations
  const handleUpdateUser = (id: number, updates: any) => {
    setUsers(users.map(u => u.id === id ? { ...u, ...updates } : u));
  };

  const handleDeleteUser = (id: number) => {
    setUsers(users.filter(u => u.id !== id));
  };

  const handleAddUser = (user: any) => {
    setUsers([...users, { 
      ...user, 
      id: Date.now(),
      dateCreated: new Date().toISOString().split('T')[0],
      lastLogin: 'Never',
      status: 'active'
    }]);
  };

  // Render current view based on state
  const renderCurrentView = () => {
    if (isPublicView) {
      switch (currentView) {
        case 'home': 
          return <PublicHome 
            currentView={currentView} 
            setCurrentView={setCurrentView} 
            setShowLoginDialog={setShowLoginDialog} 
          />;
        case 'public-projects':
          return <PublicProjects 
            currentView={currentView} 
            setCurrentView={setCurrentView} 
            setShowLoginDialog={setShowLoginDialog}
            projects={projects}
          />;
        case 'events':
          return <PublicEvents 
            currentView={currentView} 
            setCurrentView={setCurrentView} 
            setShowLoginDialog={setShowLoginDialog}
            events={events}
          />;
        case 'about':
          return <PublicAbout 
            currentView={currentView} 
            setCurrentView={setCurrentView} 
            setShowLoginDialog={setShowLoginDialog}
          />;
        case 'contact':
          return <PublicContact 
            currentView={currentView} 
            setCurrentView={setCurrentView} 
            setShowLoginDialog={setShowLoginDialog}
          />;
        case 'youth-summary':
          return <PublicYouthSummary 
            currentView={currentView} 
            setCurrentView={setCurrentView} 
            setShowLoginDialog={setShowLoginDialog}
          />;
        default: 
          return <PublicHome 
            currentView={currentView} 
            setCurrentView={setCurrentView} 
            setShowLoginDialog={setShowLoginDialog} 
          />;
      }
    } else {
      switch (currentView) {
        case 'dashboard': return <Dashboard setCurrentView={setCurrentView} />;
        case 'projects': return <ProjectManagement 
          projects={projects}
          onUpdateProject={handleUpdateProject}
          onDeleteProject={handleDeleteProject}
          onAddProject={handleAddProject}
        />;
        case 'budget': return <BudgetMonitoring projects={projects} />;
        case 'documents': return <DocumentManagement 
          documents={documents}
          onUpdateDocument={handleUpdateDocument}
          onDeleteDocument={handleDeleteDocument}
          onAddDocument={handleAddDocument}
        />;
        case 'youth': return <YouthProfiling youthProfiles={youthProfiles} />;
        case 'transparency': return <PublicTransparencyControls 
          projects={projects}
          documents={documents}
        />;
        case 'users': return <UserAccounts 
          users={users}
          onUpdateUser={handleUpdateUser}
          onDeleteUser={handleDeleteUser}
          onAddUser={handleAddUser}
        />;
        case 'audit': return <AuditTrail auditLogs={auditLogs} />;
        case 'reports': return <PDFReports />;
        case 'settings': return <SystemSettings />;
        default: return <Dashboard setCurrentView={setCurrentView} />;
      }
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Admin Layout */}
      {!isPublicView && isLoggedIn && (
        <div className="flex h-screen">
          {/* Sidebar */}
          <div 
            className={`transition-all duration-300 ${sidebarOpen ? 'w-64' : 'w-16'} flex-shrink-0 border-r border-gray-200`}
            style={{ backgroundColor: '#2C3E50' }}
          >
            <div className="h-full flex flex-col">
              {/* Header */}
              <div className="p-4 border-b" style={{ borderColor: 'rgba(255, 255, 255, 0.1)' }}>
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full flex items-center justify-center" style={{ backgroundColor: '#3498DB' }}>
                    <span className="text-white font-bold text-sm">SK</span>
                  </div>
                  {sidebarOpen && (
                    <div>
                      <h2 className="text-white font-semibold">SK Budget Transparency System</h2>
                      <p className="text-gray-300 text-xs">Admin Panel</p>
                    </div>
                  )}
                </div>
              </div>

              {/* Navigation */}
              <nav className="flex-1 p-4">
                <ul className="space-y-1">
                  {sidebarItems.map((item, index) => (
                    <li key={index}>
                      <button
                        onClick={() => setCurrentView(item.view)}
                        className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg text-left transition-colors ${
                          currentView === item.view
                            ? 'text-white'
                            : 'text-gray-300 hover:text-white'
                        }`}
                        style={{
                          backgroundColor: currentView === item.view ? '#3498DB' : 'transparent'
                        }}
                        onMouseEnter={(e) => {
                          if (currentView !== item.view) {
                            e.currentTarget.style.backgroundColor = 'rgba(52, 152, 219, 0.1)';
                          }
                        }}
                        onMouseLeave={(e) => {
                          if (currentView !== item.view) {
                            e.currentTarget.style.backgroundColor = 'transparent';
                          }
                        }}
                      >
                        <item.icon className="w-5 h-5 flex-shrink-0" />
                        {sidebarOpen && <span className="text-sm">{item.label}</span>}
                      </button>
                    </li>
                  ))}
                </ul>
              </nav>

              {/* Footer */}
              <div className="p-4 border-t" style={{ borderColor: 'rgba(255, 255, 255, 0.1)' }}>
                <button
                  onClick={handleLogout}
                  className="w-full flex items-center gap-3 px-3 py-2 text-gray-300 hover:text-white rounded-lg transition-colors"
                  onMouseEnter={(e) => {
                    e.currentTarget.style.backgroundColor = 'rgba(52, 152, 219, 0.1)';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.backgroundColor = 'transparent';
                  }}
                >
                  <LogOut className="w-5 h-5" />
                  {sidebarOpen && <span className="text-sm">Logout</span>}
                </button>
              </div>
            </div>
          </div>

          {/* Main Content */}
          <div className="flex-1 flex flex-col overflow-hidden">
            {/* Top Bar */}
            <div className="bg-white border-b border-gray-200 px-6 py-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setSidebarOpen(!sidebarOpen)}
                    style={{ color: '#3498DB' }}
                  >
                    <Menu className="w-5 h-5" />
                  </Button>
                  <div>
                    <span className="text-sm text-gray-600">Admin Panel</span>
                    <span className="mx-2 text-gray-400">•</span>
                    <span className="text-sm" style={{ color: '#3498DB' }}>SK Budget System</span>
                    <span className="mx-2 text-gray-400">•</span>
                    <span className="text-sm text-gray-600">Dashboard</span>
                  </div>
                </div>
                
                <div className="flex items-center gap-4">
                  <Button variant="ghost" size="sm" style={{ color: '#3498DB' }}>
                    <Bell className="w-5 h-5" />
                  </Button>
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-full flex items-center justify-center" style={{ backgroundColor: '#3498DB' }}>
                      <Users className="w-4 h-4 text-white" />
                    </div>
                    <span className="text-sm font-medium text-gray-700">Admin User</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Content Area */}
            <div className="flex-1 overflow-auto">
              {renderCurrentView()}
            </div>
          </div>
        </div>
      )}

      {/* Public Layout */}
      {isPublicView && renderCurrentView()}

      {/* Login Dialog */}
      <LoginDialog
        open={showLoginDialog}
        onOpenChange={setShowLoginDialog}
        loginForm={loginForm}
        setLoginForm={setLoginForm}
        onLogin={handleLogin}
      />
    </div>
  );
}