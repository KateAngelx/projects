import React from 'react';
import SKBudgetSystem from './sk-system-projects/App';

export default function App() {
  return <SKBudgetSystem />;
}