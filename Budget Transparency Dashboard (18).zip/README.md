
  # Budget Transparency Dashboard

  This is a code bundle for Budget Transparency Dashboard. The original project is available at https://www.figma.com/design/wmTrhXjq1zYEtmyRrJYG68/Budget-Transparency-Dashboard.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  